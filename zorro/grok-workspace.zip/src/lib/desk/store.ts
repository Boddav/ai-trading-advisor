import { create } from "zustand";
import {
  DEFAULT_PROMPT,
  SPEED,
  START_EQUITY,
  type AgentId,
  type AgentState,
  type DecisionEvent,
  type EquityPoint,
  type FillEvent,
  type LogEvent,
  type NightEvent,
  type Phase,
  type Stats,
} from "./types";
import {
  applyEvent,
  decayHeat,
  generateSchedule,
  initialDraft,
  replay,
} from "./engine";

const STORAGE_KEY = "meridian-desk-v1";

interface Persisted {
  v: 1;
  seed: number;
  simTime: number;
  phase: Phase;
  prompt: string;
}

export interface DeskState {
  hydrated: boolean;
  phase: Phase;
  seed: number;
  prompt: string;
  simTime: number;
  displayEquity: number;
  equity: number;
  agents: Record<AgentId, AgentState>;
  decisions: DecisionEvent[];
  fills: FillEvent[];
  logs: LogEvent[];
  points: EquityPoint[];
  stats: Stats;
  currentDecision: DecisionEvent | null;
  schedule: NightEvent[];
  cursor: number;
  hydrate: () => void;
  setPrompt: (value: string) => void;
  start: () => void;
  pause: () => void;
  resume: () => void;
  reset: () => void;
  advance: (dtWall: number) => void;
}

function persist(state: DeskState) {
  if (typeof window === "undefined") return;
  const payload: Persisted = {
    v: 1,
    seed: state.seed,
    simTime: state.simTime,
    phase: state.phase === "boot" ? "boot" : state.phase,
    prompt: state.prompt,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch {
    /* ignore quota */
  }
}

function snapshotFrom(schedule: NightEvent[], simTime: number, extras: Partial<DeskState> = {}) {
  const draft = replay(schedule, simTime);
  return {
    simTime,
    equity: draft.equity,
    displayEquity: draft.equity,
    agents: draft.agents,
    decisions: draft.decisions,
    fills: draft.fills,
    logs: draft.logs,
    points: draft.points,
    stats: draft.stats,
    currentDecision: draft.currentDecision,
    cursor: (() => {
      const i = schedule.findIndex((e) => e.t > simTime);
      return i === -1 ? schedule.length : i;
    })(),
    ...extras,
  };
}

let persistAcc = 0;

export const useDeskStore = create<DeskState>((set, get) => ({
  hydrated: false,
  phase: "boot",
  seed: 1,
  prompt: DEFAULT_PROMPT,
  simTime: 0,
  displayEquity: START_EQUITY,
  ...initialDraft(),
  schedule: [],
  cursor: 0,

  hydrate: () => {
    if (typeof window === "undefined") {
      set({ hydrated: true });
      return;
    }
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Persisted;
        if (saved.v === 1 && saved.phase !== "boot" && saved.seed) {
          const schedule = generateSchedule(saved.seed);
          set({
            hydrated: true,
            seed: saved.seed,
            prompt: saved.prompt || DEFAULT_PROMPT,
            phase: saved.phase === "paused" ? "paused" : "live",
            schedule,
            ...snapshotFrom(schedule, saved.simTime),
          });
          return;
        }
      }
    } catch {
      /* fresh */
    }
    set({ hydrated: true });
  },

  setPrompt: (value) => set({ prompt: value }),

  start: () => {
    const seed = (Math.floor(Math.random() * 0x7fffffff) ^ Date.now()) >>> 0 || 1;
    const schedule = generateSchedule(seed);
    const next: Partial<DeskState> = {
      phase: "live",
      seed,
      schedule,
      ...snapshotFrom(schedule, 0),
      displayEquity: START_EQUITY,
    };
    set(next);
    persist(get());
  },

  pause: () => {
    set({ phase: "paused" });
    persist(get());
  },

  resume: () => {
    if (get().phase === "paused") {
      set({ phase: "live" });
      persist(get());
    }
  },

  reset: () => {
    const prompt = get().prompt;
    set({
      phase: "boot",
      seed: 1,
      prompt,
      simTime: 0,
      displayEquity: START_EQUITY,
      schedule: [],
      cursor: 0,
      ...initialDraft(),
    });
    persist(get());
  },

  advance: (dtWall: number) => {
    const s = get();
    if (s.phase !== "live" || dtWall <= 0) return;

    const simTime = s.simTime + dtWall * SPEED;
    let cursor = s.cursor < 0 ? 0 : s.cursor;
    const draft = {
      equity: s.equity,
      agents: s.agents,
      decisions: s.decisions,
      fills: s.fills,
      logs: s.logs,
      points: s.points,
      stats: s.stats,
      currentDecision: s.currentDecision,
    };

    const schedule = s.schedule;
    while (cursor < schedule.length && schedule[cursor].t <= simTime) {
      applyEvent(draft, schedule[cursor]);
      cursor += 1;
    }

    draft.agents = decayHeat(draft.agents, dtWall);

    const follow = 1 - Math.exp(-dtWall / 160);
    const displayEquity = s.displayEquity + (draft.equity - s.displayEquity) * follow;

    set({
      simTime,
      cursor,
      displayEquity,
      equity: draft.equity,
      agents: draft.agents,
      decisions: draft.decisions,
      fills: draft.fills,
      logs: draft.logs,
      points: draft.points,
      stats: draft.stats,
      currentDecision: draft.currentDecision,
    });

    persistAcc += dtWall;
    if (persistAcc > 1500) {
      persistAcc = 0;
      persist(get());
    }
  },
}));
