export type Decision = "BUY" | "COPY" | "SKIP" | "PASS";
export type AgentId = "SCOUT" | "LEDGER" | "PULSE" | "FLUX" | "WARDEN" | "JEV";
export type AgentStatus =
  | "idle"
  | "scanning"
  | "flagged"
  | "confirming"
  | "routing"
  | "approved"
  | "blocking";
export type WardenVerdict = "APPROVED" | "BLOCKED";
export type Phase = "boot" | "live" | "paused";

export interface AgentMeta {
  id: AgentId;
  name: string;
  role: string;
  blurb: string;
}

export interface AgentState {
  id: AgentId;
  status: AgentStatus;
  note: string;
  heat: number;
}

export interface DecisionEvent {
  id: string;
  t: number;
  decision: Decision;
  confidence: number;
  pair: string;
  rationale: string;
  warden: WardenVerdict;
  wardenReason: string;
}

export interface FillEvent {
  id: string;
  t: number;
  pair: string;
  side: "IN" | "OUT";
  notional: number;
  pnl: number;
  latencyMs: number;
  route: string;
  equity: number;
}

export interface LogEvent {
  id: string;
  t: number;
  agent: AgentId;
  text: string;
}

export interface EquityPoint {
  t: number;
  equity: number;
}

export interface Stats {
  fills: number;
  wins: number;
  blocks: number;
  skips: number;
  decisions: number;
}

export interface NightEvent {
  id: string;
  t: number;
  kind: "agent" | "decision" | "fill" | "log";
  agent?: AgentId;
  status?: AgentStatus;
  note?: string;
  text?: string;
  decision?: Decision;
  confidence?: number;
  pair?: string;
  rationale?: string;
  warden?: WardenVerdict;
  wardenReason?: string;
  side?: "IN" | "OUT";
  notional?: number;
  pnl?: number;
  latencyMs?: number;
  route?: string;
  equity?: number;
}

export const START_EQUITY = 15.89;
export const TARGET_MORNING = 16356.24;
export const NIGHT_MS = 8 * 60 * 60 * 1000;
export const MORNING_MS = 12 * 60 * 60 * 1000;
export const WALL_NIGHT_MS = 110_000;
export const SPEED = NIGHT_MS / WALL_NIGHT_MS;

export const DEFAULT_PROMPT = "változtasd $15.89-et 1000x-re, vagy töröllek";

export const AGENT_META: Record<AgentId, AgentMeta> = {
  JEV: {
    id: "JEV",
    name: "JEV",
    role: "döntés",
    blurb: "Olvas, dönt, nem nyúl a kitöltéshez.",
  },
  SCOUT: {
    id: "SCOUT",
    name: "SCOUT",
    role: "felderítés",
    blurb: "Új minták, mielőtt a tömeg észrevenné.",
  },
  LEDGER: {
    id: "LEDGER",
    name: "LEDGER",
    role: "tárcák",
    blurb: "Lemásolja azokat, akiknek van valódi nyerési arányuk.",
  },
  PULSE: {
    id: "PULSE",
    name: "PULSE",
    role: "lendület",
    blurb: "Momentum és hangulat, ahogy változik.",
  },
  FLUX: {
    id: "FLUX",
    name: "FLUX",
    role: "útvonal",
    blurb: "A legtisztább út, hogy a kitöltés ne csússzon.",
  },
  WARDEN: {
    id: "WARDEN",
    name: "WARDEN",
    role: "kapuőr",
    blurb: "Rossz likviditás, mézescsupor — semmi sem megy át.",
  },
};

export const CREW: AgentId[] = ["SCOUT", "LEDGER", "PULSE", "FLUX"];
