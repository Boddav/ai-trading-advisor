export function formatUsd(value: number, digits = 2): string {
  const sign = value < 0 ? "-" : "";
  const abs = Math.abs(value);
  const formatted = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(abs);
  return `${sign}$${formatted}`;
}

export function formatUsdCompact(value: number): string {
  const sign = value < 0 ? "-" : "";
  const abs = Math.abs(value);
  if (abs >= 1000) {
    return `${sign}$${new Intl.NumberFormat("en-US", {
      maximumFractionDigits: 1,
      minimumFractionDigits: 1,
    }).format(abs)}`;
  }
  return formatUsd(value);
}

export function formatPct(value: number): string {
  const sign = value > 0 ? "+" : value < 0 ? "" : "";
  return `${sign}${new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 2,
    minimumFractionDigits: 2,
  }).format(value)}%`;
}

export function formatClock(simMs: number): string {
  const total = Math.max(0, Math.floor(simMs / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatMs(ms: number): string {
  return `${ms} ms`;
}

export function formatBps(n: number): string {
  return `${n} bps`;
}

export function multipleOf(start: number, now: number): string {
  if (start <= 0) return "—";
  const x = now / start;
  return `${x.toFixed(x >= 100 ? 0 : x >= 10 ? 1 : 2)}x`;
}
