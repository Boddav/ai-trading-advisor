import {
  AGENT_META,
  MORNING_MS,
  NIGHT_MS,
  SPEED,
  START_EQUITY,
  TARGET_MORNING,
  type AgentId,
  type AgentState,
  type AgentStatus,
  type Decision,
  type DecisionEvent,
  type EquityPoint,
  type FillEvent,
  type LogEvent,
  type NightEvent,
  type Stats,
  type WardenVerdict,
} from "./types";

export interface DeskDraft {
  equity: number;
  agents: Record<AgentId, AgentState>;
  decisions: DecisionEvent[];
  fills: FillEvent[];
  logs: LogEvent[];
  points: EquityPoint[];
  stats: Stats;
  currentDecision: DecisionEvent | null;
}

const PAIRS = [
  "VELD/SOL",
  "NYX/USDC",
  "KOS/SOL",
  "RILL/USDC",
  "MIRA/SOL",
  "QEN/USDC",
  "TORR/SOL",
  "BRIN/USDC",
  "AUR/SOL",
  "LUX/USDC",
  "ORBIT/SOL",
  "KITE/USDC",
  "FEN/SOL",
  "WISP/USDC",
  "HARB/SOL",
  "NOLL/USDC",
  "PRAX/SOL",
  "JUTE/USDC",
  "VELA/SOL",
  "DUSK/USDC",
];

const ROUTES = [
  "Axis / North",
  "Harbor split 60/40",
  "Nexus-2 bundle",
  "Well hop A→B",
  "Kite single-pool",
  "R1 priority",
  "Drift lane",
  "Quiet book",
];

const SCOUT_HIT = [
  "új 1m minta a {pair} chartján",
  "abszorpciós gyertya, a tömeg még nem látja",
  "ismétlődő breaker-struktúra {pair}-en",
  "likviditási üreg nyílt, 3. alkalom",
  "eltérés a 5m VWAP-tól, tiszta setup",
];

const SCOUT_MISS = [
  "zaj a {pair} 1m-en, nincs ismétlődés",
  "minta túl friss — egyetlen előfordulás",
  "árnyék a felső kanócon, nem tiszta",
];

const LEDGER_HIT = [
  "{n} tárca lépett be 90s alatt",
  "cluster winrate {pct}% — valódi, nem szerencse",
  "ugyanaz a funding-tárca, mint tegnap éjjel",
  "smart money 4 hoppal a poolban",
];

const LEDGER_MISS = [
  "nincs belépés a watchlisten",
  "a cluster winrate {pct}% — nem elég",
  "tárcák kifelé lépnek, nem befelé",
];

const PULSE_HIT = [
  "momentum {sig}σ a 15m-en",
  "sentiment még nem árazta be",
  "funding átfordult, volume követ",
  "lendület épül, hangulat lemarad",
];

const PULSE_MISS = [
  "volume spike, gyenge follow-through",
  "lendület kifulladt a {pair} 5m-en",
  "hangulat ellentmond a flow-nak",
];

const FLUX_HIT = [
  "útvonal {route}, {bps} bps",
  "split 60/40, várható csúszás {bps} bps",
  "egyetlen pool, tiszta könyv",
  "priority bundle, kitöltés {lat} ms",
];

const WARDEN_OK = [
  "likviditás rendben",
  "nincs mézescsupor",
  "mintált contract, tulajdonos lemondva",
  "top-10 koncentráció 31%",
  "eladás-szimuláció tiszta",
];

const WARDEN_NO = [
  "mézescsupor gyanú — eladás-szimuláció elbukott",
  "likviditás vékony, 2% book impact",
  "tulajdonos mintable, 12 perce",
  "92% top-holder koncentráció",
  "router blacklist egyezés",
];

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rand: () => number, list: T[]): T {
  return list[Math.floor(rand() * list.length)] as T;
}

function fill(template: string, vars: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_, k: string) => String(vars[k] ?? ""));
}

function curve(progress: number): number {
  if (progress <= 0.1) return START_EQUITY;
  const x = Math.min(1, (progress - 0.1) / 0.9);
  const eased = x ** 1.22;
  return START_EQUITY * (TARGET_MORNING / START_EQUITY) ** eased;
}

function emptyAgents(): Record<AgentId, AgentState> {
  const agents = {} as Record<AgentId, AgentState>;
  (Object.keys(AGENT_META) as AgentId[]).forEach((id) => {
    agents[id] = { id, status: "idle", note: "", heat: 0 };
  });
  return agents;
}

export function initialDraft(): DeskDraft {
  return {
    equity: START_EQUITY,
    agents: emptyAgents(),
    decisions: [],
    fills: [],
    logs: [],
    points: [{ t: 0, equity: START_EQUITY }],
    stats: { fills: 0, wins: 0, blocks: 0, skips: 0, decisions: 0 },
    currentDecision: null,
  };
}

const CAP = { decisions: 80, fills: 80, logs: 140, points: 180 };

function pushCap<T>(arr: T[], item: T, cap: number): T[] {
  const next = arr.length >= cap ? arr.slice(arr.length - cap + 1) : arr.slice();
  next.push(item);
  return next;
}

export function applyEvent(state: DeskDraft, event: NightEvent): void {
  if (event.kind === "agent" && event.agent) {
    const prev = state.agents[event.agent];
    state.agents = {
      ...state.agents,
      [event.agent]: {
        ...prev,
        status: event.status ?? prev.status,
        note: event.note ?? prev.note,
        heat: 1,
      },
    };
    return;
  }

  if (event.kind === "log" && event.agent && event.text) {
    state.logs = pushCap(
      state.logs,
      { id: event.id, t: event.t, agent: event.agent, text: event.text },
      CAP.logs,
    );
    return;
  }

  if (event.kind === "decision" && event.decision && event.pair) {
    const item: DecisionEvent = {
      id: event.id,
      t: event.t,
      decision: event.decision,
      confidence: event.confidence ?? 0,
      pair: event.pair,
      rationale: event.rationale ?? "",
      warden: event.warden ?? "APPROVED",
      wardenReason: event.wardenReason ?? "",
    };
    state.decisions = pushCap(state.decisions, item, CAP.decisions);
    state.currentDecision = item;
    state.stats = {
      ...state.stats,
      decisions: state.stats.decisions + 1,
      skips:
        state.stats.skips + (item.decision === "SKIP" || item.decision === "PASS" ? 1 : 0),
      blocks: state.stats.blocks + (item.warden === "BLOCKED" ? 1 : 0),
    };
    return;
  }

  if (event.kind === "fill" && event.pair) {
    const equity = event.equity ?? state.equity;
    const pnl = event.pnl ?? 0;
    const fillItem: FillEvent = {
      id: event.id,
      t: event.t,
      pair: event.pair,
      side: event.side ?? "IN",
      notional: event.notional ?? 0,
      pnl,
      latencyMs: event.latencyMs ?? 2,
      route: event.route ?? "",
      equity,
    };
    state.fills = pushCap(state.fills, fillItem, CAP.fills);
    state.equity = equity;
    state.points = pushCap(state.points, { t: event.t, equity }, CAP.points);
    state.stats = {
      ...state.stats,
      fills: state.stats.fills + 1,
      wins: state.stats.wins + (pnl > 0 ? 1 : 0),
    };
  }
}

export function replay(schedule: NightEvent[], simTime: number): DeskDraft {
  const state = initialDraft();
  for (const event of schedule) {
    if (event.t > simTime) break;
    applyEvent(state, event);
  }
  return state;
}

export function generateSchedule(seed: number): NightEvent[] {
  const rand = mulberry32(seed);
  const events: NightEvent[] = [];
  let n = 0;
  const emit = (partial: Omit<NightEvent, "id">) => {
    n += 1;
    events.push({ id: `e${n}`, ...partial });
  };

  const wall = (ms: number) => ms * SPEED;

  emit({
    t: 0,
    kind: "log",
    agent: "JEV",
    text: "online. cél: 1000x. kezdő: $15.89. kezek le a billentyűzetről.",
  });
  (["SCOUT", "LEDGER", "PULSE", "FLUX", "WARDEN", "JEV"] as AgentId[]).forEach((agent, i) => {
    emit({
      t: wall(80 * i),
      kind: "agent",
      agent,
      status: "scanning",
      note: "figyel",
    });
  });
  emit({
    t: wall(400),
    kind: "log",
    agent: "WARDEN",
    text: "kapu zárva, amíg a jelek össze nem állnak.",
  });

  const watchNotes: Array<{ agent: AgentId; text: string }> = [
    { agent: "SCOUT", text: "szalag üres. mintára várok." },
    { agent: "LEDGER", text: "12 tárca a watchlisten. nincs belépés." },
    { agent: "PULSE", text: "hangulat semleges. nincs él." },
    { agent: "FLUX", text: "útvonalak melegek, nincs mit tölteni." },
    { agent: "JEV", text: "nincs kitöltés. nincs mozgás. figyelek." },
  ];
  watchNotes.forEach((note, i) => {
    emit({
      t: wall(1800 + i * 1400),
      kind: "log",
      agent: note.agent,
      text: note.text,
    });
  });

  // Opening cinematic — the first real fill, 2ms.
  const T = wall(10_000);
  const openPair = "VELD/SOL";
  emit({
    t: T,
    kind: "agent",
    agent: "SCOUT",
    status: "flagged",
    note: fill(SCOUT_HIT[0], { pair: openPair }),
  });
  emit({
    t: T,
    kind: "log",
    agent: "SCOUT",
    text: `minta összeállt — ${openPair} 1m.`,
  });
  emit({
    t: T + wall(1100),
    kind: "agent",
    agent: "LEDGER",
    status: "confirming",
    note: fill(LEDGER_HIT[0], { n: 3, pct: 71 }),
  });
  emit({
    t: T + wall(1100),
    kind: "log",
    agent: "LEDGER",
    text: "három tárca már benne van. 71% realized win.",
  });
  emit({
    t: T + wall(1900),
    kind: "agent",
    agent: "PULSE",
    status: "confirming",
    note: fill(PULSE_HIT[3], {}),
  });
  emit({
    t: T + wall(1900),
    kind: "log",
    agent: "PULSE",
    text: "lendület 2.4σ. hangulat még lemarad.",
  });
  emit({
    t: T + wall(2500),
    kind: "agent",
    agent: "JEV",
    status: "flagged",
    note: "BUY · 91.4%",
  });
  emit({
    t: T + wall(2500),
    kind: "decision",
    decision: "BUY",
    confidence: 0.914,
    pair: openPair,
    rationale: "SCOUT minta + LEDGER cluster + PULSE lemaradás",
    warden: "APPROVED",
    wardenReason: "likviditás rendben, nincs mézescsupor",
  });
  emit({
    t: T + wall(2500),
    kind: "log",
    agent: "JEV",
    text: "BUY 91.4% — VELD/SOL",
  });
  emit({
    t: T + wall(2720),
    kind: "agent",
    agent: "WARDEN",
    status: "approved",
    note: "jóváhagyva",
  });
  emit({
    t: T + wall(2720),
    kind: "log",
    agent: "WARDEN",
    text: "jóváhagyva. likviditás tiszta. nincs mézescsupor.",
  });
  emit({
    t: T + wall(2880),
    kind: "agent",
    agent: "FLUX",
    status: "routing",
    note: fill(FLUX_HIT[3], { lat: 2 }),
  });
  const firstEquity = 38.07;
  emit({
    t: T + wall(2882),
    kind: "fill",
    pair: openPair,
    side: "IN",
    notional: 15.89,
    pnl: firstEquity - START_EQUITY,
    latencyMs: 2,
    route: "Quiet book",
    equity: firstEquity,
  });
  emit({
    t: T + wall(2882),
    kind: "log",
    agent: "FLUX",
    text: "kitöltve 2 ms. első fill. nincs input tőled.",
  });
  emit({
    t: T + wall(3200),
    kind: "log",
    agent: "JEV",
    text: "egy kereskedés táplálja a következőt.",
  });

  let t = T + wall(4200);
  let equity = firstEquity;

  const end = MORNING_MS;
  while (t < end) {
    const progress = Math.min(1, t / NIGHT_MS);
    const burst = rand() < 0.38 && t < NIGHT_MS ? 2 + Math.floor(rand() * 3) : 1;

    for (let b = 0; b < burst; b += 1) {
      const pair = pick(rand, PAIRS);
      const roll = rand();
      let kind: "fill" | "skip" | "pass" | "block";
      if (t > NIGHT_MS) {
        kind = roll < 0.55 ? "fill" : roll < 0.72 ? "skip" : roll < 0.88 ? "pass" : "block";
      } else if (roll < 0.62) kind = "fill";
      else if (roll < 0.76) kind = "skip";
      else if (roll < 0.88) kind = "pass";
      else kind = "block";

      const scoutNote = fill(kind === "skip" ? pick(rand, SCOUT_MISS) : pick(rand, SCOUT_HIT), {
        pair,
      });
      emit({
        t,
        kind: "agent",
        agent: "SCOUT",
        status: kind === "skip" ? "scanning" : "flagged",
        note: scoutNote,
      });
      emit({ t, kind: "log", agent: "SCOUT", text: scoutNote });

      const ledgerDelay = wall(80 + rand() * 90);
      const ledgerHit = kind === "fill" || kind === "block" || kind === "pass";
      const ledgerNote = fill(ledgerHit ? pick(rand, LEDGER_HIT) : pick(rand, LEDGER_MISS), {
        n: 2 + Math.floor(rand() * 6),
        pct: 48 + Math.floor(rand() * 36),
      });
      emit({
        t: t + ledgerDelay,
        kind: "agent",
        agent: "LEDGER",
        status: ledgerHit ? "confirming" : "scanning",
        note: ledgerNote,
      });
      emit({
        t: t + ledgerDelay,
        kind: "log",
        agent: "LEDGER",
        text: ledgerNote,
      });

      const pulseDelay = ledgerDelay + wall(60 + rand() * 80);
      const pulseHit = kind === "fill" || kind === "block";
      const pulseNote = fill(pulseHit ? pick(rand, PULSE_HIT) : pick(rand, PULSE_MISS), {
        pair,
        sig: (1.6 + rand() * 2.8).toFixed(1),
      });
      emit({
        t: t + pulseDelay,
        kind: "agent",
        agent: "PULSE",
        status: pulseHit ? "confirming" : "scanning",
        note: pulseNote,
      });
      emit({ t: t + pulseDelay, kind: "log", agent: "PULSE", text: pulseNote });

      const decideAt = t + pulseDelay + wall(50 + rand() * 60);
      let decision: Decision;
      let warden: WardenVerdict = "APPROVED";
      let wardenReason = pick(rand, WARDEN_OK);
      let confidence: number;

      if (kind === "fill") {
        decision = rand() < 0.55 ? "BUY" : "COPY";
        confidence = 0.78 + rand() * 0.19;
      } else if (kind === "skip") {
        decision = "SKIP";
        confidence = 0.54 + rand() * 0.2;
      } else if (kind === "pass") {
        decision = "PASS";
        confidence = 0.5 + rand() * 0.18;
      } else {
        decision = rand() < 0.5 ? "BUY" : "COPY";
        confidence = 0.7 + rand() * 0.18;
        warden = "BLOCKED";
        wardenReason = pick(rand, WARDEN_NO);
      }

      const rationale =
        kind === "fill"
          ? `${decision === "COPY" ? "LEDGER cluster" : "SCOUT minta"} + PULSE megerősítés`
          : kind === "block"
            ? "jelek megvannak, WARDEN nem enged"
            : kind === "skip"
              ? "minta túl friss vagy zajos"
              : "LEDGER nem erősít, aszimmetria kevés";

      emit({
        t: decideAt,
        kind: "agent",
        agent: "JEV",
        status: "flagged",
        note: `${decision} · ${(confidence * 100).toFixed(1)}%`,
      });
      emit({
        t: decideAt,
        kind: "decision",
        decision,
        confidence,
        pair,
        rationale,
        warden,
        wardenReason,
      });
      emit({
        t: decideAt,
        kind: "log",
        agent: "JEV",
        text: `${decision} ${(confidence * 100).toFixed(1)}% — ${pair}`,
      });

      const wardenAt = decideAt + wall(40 + rand() * 40);
      emit({
        t: wardenAt,
        kind: "agent",
        agent: "WARDEN",
        status: warden === "BLOCKED" ? "blocking" : "approved",
        note: warden === "BLOCKED" ? "blokkolva" : "jóváhagyva",
      });
      emit({
        t: wardenAt,
        kind: "log",
        agent: "WARDEN",
        text: `${warden === "BLOCKED" ? "BLOKKOLVA" : "jóváhagyva"} — ${wardenReason}`,
      });

      if (kind === "fill") {
        const fluxAt = wardenAt + wall(20 + rand() * 30);
        const latency = rand() < 0.15 ? 2 : 1 + Math.floor(rand() * 8);
        const route = pick(rand, ROUTES);
        const bps = 4 + Math.floor(rand() * 14);
        const fluxNote = fill(pick(rand, FLUX_HIT), { route, bps, lat: latency });
        emit({
          t: fluxAt,
          kind: "agent",
          agent: "FLUX",
          status: "routing",
          note: fluxNote,
        });

        const p = Math.min(1, fluxAt / NIGHT_MS);
        let nextEquity: number;
        if (t >= NIGHT_MS) {
          const drift = 1 + (rand() - 0.38) * 0.035;
          nextEquity = Math.max(equity * drift, TARGET_MORNING * 0.96);
        } else {
          const target = curve(Math.min(0.995, p + 0.012));
          const lose = rand() < 0.16;
          if (lose) {
            nextEquity = equity * (0.965 + rand() * 0.02);
          } else {
            nextEquity = Math.max(target, equity * 1.02);
          }
        }

        if (fluxAt > NIGHT_MS * 0.97 && fluxAt <= NIGHT_MS && nextEquity < TARGET_MORNING) {
          nextEquity = TARGET_MORNING;
        }

        const pnl = nextEquity - equity;
        const notional = Math.min(equity * (0.55 + rand() * 0.4), equity);
        emit({
          t: fluxAt + 2,
          kind: "fill",
          pair,
          side: pnl >= 0 ? "IN" : "OUT",
          notional,
          pnl,
          latencyMs: latency,
          route,
          equity: nextEquity,
        });
        emit({
          t: fluxAt + 2,
          kind: "log",
          agent: "FLUX",
          text: `kitöltve ${latency} ms · ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)} · ${route}`,
        });
        equity = nextEquity;
        t = fluxAt + wall(180 + rand() * 220);
      } else {
        t = wardenAt + wall(220 + rand() * 260);
      }
    }

    t += wall(900 + rand() * 1600);
  }

  events.sort((a, b) => a.t - b.t || a.id.localeCompare(b.id));

  let lastNightFill: NightEvent | undefined;
  for (const event of events) {
    if (event.kind === "fill" && event.t <= NIGHT_MS) lastNightFill = event;
  }
  if (lastNightFill && typeof lastNightFill.equity === "number") {
    const delta = TARGET_MORNING - lastNightFill.equity;
    lastNightFill.pnl = (lastNightFill.pnl ?? 0) + delta;
    lastNightFill.equity = TARGET_MORNING;
    let passed = false;
    for (const event of events) {
      if (event === lastNightFill) {
        passed = true;
        continue;
      }
      if (passed && event.kind === "fill" && typeof event.equity === "number") {
        event.equity += delta;
      }
    }
  }

  return events;
}

export function decayHeat(agents: Record<AgentId, AgentState>, dtWall: number) {
  const k = Math.exp(-dtWall / 900);
  let changed = false;
  const next = { ...agents };
  (Object.keys(next) as AgentId[]).forEach((id) => {
    const a = next[id];
    const heat = a.heat * k;
    if (Math.abs(heat - a.heat) > 0.004) {
      next[id] = { ...a, heat: heat < 0.02 ? 0 : heat };
      changed = true;
    }
  });
  return changed ? next : agents;
}
