import { createServerFn } from "@tanstack/react-start";
import {
  clampRails,
  DEFAULT_RAILS,
  SOL_MINT,
  SOL_SYMBOLS,
  STABLE_MINTS,
  STABLE_SYMBOLS,
  USDC_MINT,
  type LiveRails,
  type MarketCandidate,
  type QuotePreview,
} from "./types";

const RAYDIUM_POOLS =
  "https://api-v3.raydium.io/pools/info/list?poolType=all&poolSortField=volume24h&sortType=desc&pageSize=40&page=1";
const JUP_QUOTE = "https://lite-api.jup.ag/swap/v1/quote";
const JUP_SWAP = "https://lite-api.jup.ag/swap/v1/swap";
const RPCS = [
  "https://solana-rpc.publicnode.com",
  "https://api.mainnet-beta.solana.com",
];

async function getJson(url: string, init?: RequestInit, timeoutMs = 8000): Promise<unknown> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      signal: ctrl.signal,
      headers: { accept: "application/json", ...(init?.headers ?? {}) },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function rpc(method: string, params: unknown[]): Promise<unknown> {
  let last = "RPC hiba";
  for (const url of RPCS) {
    try {
      const body = await getJson(
        url,
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
        },
        7000,
      );
      const parsed = body as { result?: unknown; error?: { message?: string } };
      if (parsed.error) throw new Error(parsed.error.message ?? "rpc error");
      return parsed.result;
    } catch (err) {
      last = err instanceof Error ? err.message : "rpc error";
    }
  }
  throw new Error(last);
}

function asNum(v: unknown): number {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function isSolSymbol(sym: string) {
  return SOL_SYMBOLS.has(sym.toUpperCase());
}
function isStableSymbol(sym: string) {
  return STABLE_SYMBOLS.has(sym.toUpperCase());
}
function isStableMint(mint: string) {
  return STABLE_MINTS.has(mint) || mint === SOL_MINT;
}

interface RayMint {
  address?: string;
  symbol?: string;
  name?: string;
  decimals?: number;
}
interface RayPool {
  id?: string;
  type?: string;
  tvl?: number;
  price?: number;
  openTime?: number | string;
  mintA?: RayMint;
  mintB?: RayMint;
  day?: { volume?: number; apr?: number; feeApr?: number; priceMin?: number; priceMax?: number };
}

function mapPool(p: RayPool): MarketCandidate | null {
  const a = p.mintA;
  const b = p.mintB;
  if (!a?.address || !b?.address || !p.id) return null;
  const aSol = isSolSymbol(a.symbol ?? "") || a.address === SOL_MINT;
  const bSol = isSolSymbol(b.symbol ?? "") || b.address === SOL_MINT;
  const aSt = isStableSymbol(a.symbol ?? "") || STABLE_MINTS.has(a.address);
  const bSt = isStableSymbol(b.symbol ?? "") || STABLE_MINTS.has(b.address);
  if ((aSol || aSt) && (bSol || bSt)) return null;

  let base = a;
  let quote = b;
  let quoteMint = b.address;
  if (aSol || aSt) {
    base = b;
    quote = a;
    quoteMint = a.address;
  } else if (!(bSol || bSt)) {
    return null;
  }
  if (!base.address || isStableMint(base.address)) return null;

  const tvlUsd = asNum(p.tvl);
  const volume24h = asNum(p.day?.volume);
  const priceMin = asNum(p.day?.priceMin);
  const priceMax = asNum(p.day?.priceMax);
  const rangePct = priceMin > 0 ? ((priceMax - priceMin) / priceMin) * 100 : 0;
  const price = asNum(p.price);
  const nearHigh = priceMax > 0 ? clamp(price / priceMax, 0, 1) : 0.5;
  const open = asNum(p.openTime);
  const ageHours = open > 1_000_000_000 ? Math.max(0, (Date.now() / 1000 - open) / 3600) : 24 * 365;

  return {
    poolId: p.id,
    pair: `${base.symbol ?? "TOKEN"}/${quote.symbol === "WSOL" ? "SOL" : (quote.symbol ?? "USDC")}`,
    mint: base.address,
    mintDecimals: Math.min(18, Math.max(0, Math.round(asNum(base.decimals) || 6))),
    quoteMint,
    quoteSymbol: quote.symbol === "WSOL" ? "SOL" : (quote.symbol ?? "USDC"),
    symbol: base.symbol ?? "TOKEN",
    name: base.name ?? base.symbol ?? "token",
    tvlUsd,
    volume24h,
    turnover: tvlUsd > 0 ? volume24h / tvlUsd : 0,
    priceUsd: 0,
    rangePct,
    nearHigh,
    ageHours,
    feeApr: asNum(p.day?.feeApr ?? p.day?.apr),
    dex: p.type === "Concentrated" ? "Raydium CLMM" : "Raydium",
  };
}

function clamp(n: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, n));
}

async function solPriceUsd(): Promise<number> {
  try {
    const quote = (await getJson(
      `${JUP_QUOTE}?inputMint=${SOL_MINT}&outputMint=${USDC_MINT}&amount=1000000000&slippageBps=50`,
      undefined,
      6000,
    )) as { outAmount?: string };
    const n = asNum(quote.outAmount) / 10 ** 6;
    if (n > 10 && n < 10_000) return n;
  } catch {
    /* fall through */
  }
  try {
    const body = (await getJson(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd",
      undefined,
      5000,
    )) as { solana?: { usd?: number } };
    const n = asNum(body.solana?.usd);
    if (n > 0) return n;
  } catch {
    /* fall through */
  }
  return 0;
}

export const scanMarket = createServerFn({ method: "POST" })
  .validator((input: { minLiqUsd?: number; minAgeHours?: number }) => input)
  .handler(async ({ data }) => {
    const minLiq = data.minLiqUsd ?? DEFAULT_RAILS.minLiqUsd;
    const minAge = data.minAgeHours ?? DEFAULT_RAILS.minAgeHours;
    const raw = (await getJson(RAYDIUM_POOLS, undefined, 9000)) as {
      success?: boolean;
      data?: { data?: RayPool[] };
    };
    const pools = raw.data?.data ?? [];
    const solPrice = await solPriceUsd();
    const mapped: MarketCandidate[] = [];
    const seenMint = new Set<string>();
    for (const pool of pools) {
      const c = mapPool(pool);
      if (!c) continue;
      if (c.tvlUsd < minLiq * 0.6) continue;
      if (c.ageHours < Math.min(1, minAge * 0.25)) continue;
      if (seenMint.has(c.mint)) continue;
      seenMint.add(c.mint);
      if (c.quoteMint === USDC_MINT || c.quoteSymbol === "USDC") {
        c.priceUsd = asNum(pool.price);
      } else if (solPrice > 0) {
        c.priceUsd = asNum(pool.price) > 0 ? solPrice / asNum(pool.price) : 0;
      }
      mapped.push(c);
      if (mapped.length >= 16) break;
    }
    mapped.sort((a, b) => b.volume24h - a.volume24h);
    return { solPrice, candidates: mapped, at: Date.now() };
  });

export const quoteRoute = createServerFn({ method: "POST" })
  .validator((input: { inputMint: string; outputMint: string; amount: string; slippageBps: number }) => input)
  .handler(async ({ data }): Promise<QuotePreview> => {
    const params = new URLSearchParams({
      inputMint: data.inputMint,
      outputMint: data.outputMint,
      amount: data.amount,
      slippageBps: String(data.slippageBps),
      swapMode: "ExactIn",
    });
    const quote = (await getJson(`${JUP_QUOTE}?${params.toString()}`, undefined, 8000)) as {
      inputMint?: string;
      outputMint?: string;
      inAmount?: string;
      outAmount?: string;
      priceImpactPct?: string | number;
      routePlan?: Array<{ swapInfo?: { label?: string }; percent?: number }>;
      error?: string;
    };
    if (!quote?.outAmount) throw new Error(quote?.error || "Nincs Jupiter-útvonal.");
    const labels = (quote.routePlan ?? [])
      .map((hop) => hop.swapInfo?.label)
      .filter((x): x is string => Boolean(x));
    const unique = [...new Set(labels)];
    return {
      inputMint: quote.inputMint ?? data.inputMint,
      outputMint: quote.outputMint ?? data.outputMint,
      inAmount: quote.inAmount ?? data.amount,
      outAmount: quote.outAmount,
      priceImpactPct: Math.abs(asNum(quote.priceImpactPct)) * (Math.abs(asNum(quote.priceImpactPct)) <= 1 ? 100 : 1),
      route: unique.slice(0, 3).join(" → ") || "Jupiter",
    };
  });

export const buildSwap = createServerFn({ method: "POST" })
  .validator(
    (input: {
      inputMint: string;
      outputMint: string;
      amount: string;
      slippageBps: number;
      userPublicKey: string;
    }) => input,
  )
  .handler(async ({ data }) => {
    const params = new URLSearchParams({
      inputMint: data.inputMint,
      outputMint: data.outputMint,
      amount: data.amount,
      slippageBps: String(data.slippageBps),
      swapMode: "ExactIn",
    });
    const quote = await getJson(`${JUP_QUOTE}?${params.toString()}`, undefined, 8000);
    const swap = (await getJson(
      JUP_SWAP,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          quoteResponse: quote,
          userPublicKey: data.userPublicKey,
          wrapAndUnwrapSol: true,
          dynamicComputeUnitLimit: true,
          dynamicSlippage: true,
          prioritizationFeeLamports: {
            priorityLevelWithMaxLamports: {
              maxLamports: 400_000,
              priorityLevel: "high",
            },
          },
        }),
      },
      10_000,
    )) as { swapTransaction?: string; error?: string };
    if (!swap.swapTransaction) throw new Error(swap.error || "A Jupiter nem épített tranzakciót.");
    return { swapTransaction: swap.swapTransaction };
  });

export const readBalances = createServerFn({ method: "POST" })
  .validator((input: { pubkey: string }) => input)
  .handler(async ({ data }) => {
    const pubkey = data.pubkey.trim();
    if (pubkey.length < 32) throw new Error("Érvénytelen cím.");
    const lamports = asNum(await rpc("getBalance", [pubkey]));
    const parsed = (await rpc("getTokenAccountsByOwner", [
      pubkey,
      { mint: USDC_MINT },
      { encoding: "jsonParsed" },
    ])) as {
      value?: Array<{
        account?: { data?: { parsed?: { info?: { tokenAmount?: { uiAmount?: number } } } } };
      }>;
    };
    const usdc = (parsed.value ?? []).reduce((sum, acc) => {
      return sum + asNum(acc.account?.data?.parsed?.info?.tokenAmount?.uiAmount);
    }, 0);
    const solPrice = await solPriceUsd();
    return {
      sol: lamports / 1e9,
      usdc,
      solPrice,
    };
  });

export const interpretPrompt = createServerFn({ method: "POST" })
  .validator((input: { prompt: string }) => input)
  .handler(async ({ data }): Promise<{ rails: LiveRails; note: string; stance: string }> => {
    const fallback = {
      rails: DEFAULT_RAILS,
      stance: "balanced",
      note: "Alap sínek. A WARDEN nem kapcsolható ki.",
    };
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return fallback;
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 280,
          temperature: 0,
          messages: [
            {
              role: "system",
              content:
                "You configure risk rails for a live Solana desk. Never disable WARDEN. Never chase 1000x. JSON only.",
            },
            {
              role: "user",
              content: `Operator prompt: ${data.prompt.slice(0, 500)}
Return JSON: {"stance":"defensive"|"balanced"|"aggressive","sizePct":2-20,"dailyLossPct":5-20,"slippageBps":30-200,"minLiqUsd":25000-2000000,"minAgeHours":1-168,"maxImpactPct":0.3-4,"maxHourlyTrades":1-12,"note":"one Hungarian sentence"}
If they demand huge returns, stay defensive and say so in note.`,
            },
          ],
        }),
      });
      if (!res.ok) return fallback;
      const body = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const text = body.choices?.[0]?.message?.content ?? "";
      const match = text.match(/\{[\s\S]*\}/);
      if (!match) return fallback;
      const parsed = JSON.parse(match[0]) as Partial<LiveRails> & { stance?: string; note?: string };
      return {
        rails: clampRails(parsed),
        stance: parsed.stance === "aggressive" || parsed.stance === "defensive" ? parsed.stance : "balanced",
        note: (parsed.note ?? fallback.note).slice(0, 220),
      };
    } catch {
      return fallback;
    }
  });
