import { create } from "zustand";
import { decayHeat, initialDraft } from "@/lib/desk/engine";
import type { AgentId, AgentState, DecisionEvent, FillEvent, LogEvent } from "@/lib/desk/types";
import { scanMarket, quoteRoute, buildSwap, readBalances, interpretPrompt } from "./api";
import { evaluateCandidate, emptyLiveAgents, emptyLiveStats, hourlyFillCount, killedEquity, pickCandidate, sizeInSol } from "./engine";
import {
  clampRails,
  DEFAULT_RAILS,
  SOL_MINT,
  TICKET_TTL_MS,
  type LivePhase,
  type LiveRails,
  type LiveTicket,
  type MarketCandidate,
  type Position,
  type QuotePreview,
} from "./types";
import { connectWallet, detectWallets, disconnectWallet, signAndSendSwap, type SolanaProvider } from "./wallet";

const STORAGE_KEY = "meridian-live-v1";

interface Persisted {
  v: 1;
  prompt: string;
  rails: LiveRails;
  startEquity: number;
  fills: FillEvent[];
  positions: Position[];
  pubkey: string | null;
}

export interface LiveState {
  hydrated: boolean;
  phase: LivePhase;
  prompt: string;
  rails: LiveRails;
  stance: string;
  stanceNote: string;
  walletName: string | null;
  pubkey: string | null;
  sol: number;
  usdc: number;
  solPrice: number;
  startEquity: number;
  equity: number;
  displayEquity: number;
  startedAt: number;
  clockMs: number;
  agents: Record<AgentId, AgentState>;
  decisions: DecisionEvent[];
  fills: FillEvent[];
  logs: LogEvent[];
  points: { t: number; equity: number }[];
  stats: ReturnType<typeof emptyLiveStats>;
  currentDecision: DecisionEvent | null;
  ticket: LiveTicket | null;
  positions: Position[];
  candidates: MarketCandidate[];
  seen: string[];
  busy: boolean;
  error: string | null;
  hydrate: () => void;
  setPrompt: (value: string) => void;
  setRails: (partial: Partial<LiveRails>) => void;
  beginArm: () => void;
  cancelArm: () => void;
  connect: (walletName?: string) => Promise<void>;
  refreshBalances: () => Promise<void>;
  interpret: () => Promise<void>;
  arm: () => Promise<void>;
  pause: () => void;
  resume: () => void;
  kill: () => void;
  reset: () => void;
  decay: (dt: number) => void;
  tickClock: () => void;
  cycle: () => Promise<void>;
  signTicket: () => Promise<void>;
  dismissTicket: () => void;
}

let providerRef: SolanaProvider | null = null;
let logN = 0;

function nid(prefix: string) {
  logN += 1;
  return `${prefix}${logN}`;
}

function pushCap<T>(arr: T[], item: T, cap: number): T[] {
  const next = arr.length >= cap ? arr.slice(arr.length - cap + 1) : arr.slice();
  next.push(item);
  return next;
}

function persist(state: LiveState) {
  if (typeof window === "undefined") return;
  const payload: Persisted = {
    v: 1,
    prompt: state.prompt,
    rails: state.rails,
    startEquity: state.startEquity,
    fills: state.fills.slice(-40),
    positions: state.positions,
    pubkey: state.pubkey,
  };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  } catch {
    /* ignore */
  }
}

function equityOf(sol: number, usdc: number, solPrice: number, positions: Position[]): number {
  const marks = positions.reduce((s, p) => s + p.markUsd, 0);
  return sol * solPrice + usdc + marks;
}

function blank(): Pick<
  LiveState,
  | "phase"
  | "stance"
  | "stanceNote"
  | "walletName"
  | "pubkey"
  | "sol"
  | "usdc"
  | "solPrice"
  | "startEquity"
  | "equity"
  | "displayEquity"
  | "startedAt"
  | "clockMs"
  | "agents"
  | "decisions"
  | "fills"
  | "logs"
  | "points"
  | "stats"
  | "currentDecision"
  | "ticket"
  | "positions"
  | "candidates"
  | "seen"
  | "busy"
  | "error"
> {
  const draft = initialDraft();
  return {
    phase: "off",
    stance: "balanced",
    stanceNote: "",
    walletName: null,
    pubkey: null,
    sol: 0,
    usdc: 0,
    solPrice: 0,
    startEquity: 0,
    equity: 0,
    displayEquity: 0,
    startedAt: 0,
    clockMs: 0,
    agents: emptyLiveAgents(),
    decisions: [],
    fills: [],
    logs: draft.logs,
    points: [{ t: 0, equity: 0 }],
    stats: emptyLiveStats(),
    currentDecision: null,
    ticket: null,
    positions: [],
    candidates: [],
    seen: [],
    busy: false,
    error: null,
  };
}

function appendLog(logs: LogEvent[], clockMs: number, agent: AgentId, text: string): LogEvent[] {
  return pushCap(logs, { id: nid("l"), t: clockMs, agent, text }, 140);
}

export const useLiveStore = create<LiveState>((set, get) => ({
  hydrated: false,
  prompt: "",
  rails: DEFAULT_RAILS,
  ...blank(),

  hydrate: () => {
    if (typeof window === "undefined") {
      set({ hydrated: true });
      return;
    }
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as Persisted;
        if (saved.v === 1) {
          set({
            hydrated: true,
            prompt: saved.prompt || get().prompt,
            rails: clampRails(saved.rails ?? {}),
            fills: saved.fills ?? [],
            positions: saved.positions ?? [],
            startEquity: saved.startEquity ?? 0,
          });
          return;
        }
      }
    } catch {
      /* fresh */
    }
    set({ hydrated: true });
  },

  setPrompt: (value) => set({ prompt: value }),
  setRails: (partial) => set({ rails: clampRails({ ...get().rails, ...partial }) }),

  beginArm: () => {
    set({ phase: "arming", error: null });
  },

  cancelArm: () => {
    void disconnectWallet(providerRef);
    providerRef = null;
    set({ ...blank(), phase: "off" });
  },

  connect: async (walletName) => {
    const wallets = detectWallets();
    const pick = walletName ? wallets.find((w) => w.name === walletName) : wallets[0];
    if (!pick) {
      set({ error: "Nincs Solana-tárca a böngészőben." });
      return;
    }
    set({ busy: true, error: null });
    try {
      const pubkey = await connectWallet(pick.provider);
      providerRef = pick.provider;
      set({ pubkey, walletName: pick.name });
      await get().refreshBalances();
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "A csatlakozás megszakadt." });
    } finally {
      set({ busy: false });
    }
  },

  refreshBalances: async () => {
    const pubkey = get().pubkey;
    if (!pubkey) return;
    try {
      const bal = await readBalances({ data: { pubkey } });
      const solPrice = bal.solPrice || get().solPrice;
      const equity = equityOf(bal.sol, bal.usdc, solPrice, get().positions);
      set({
        sol: bal.sol,
        usdc: bal.usdc,
        solPrice,
        equity,
        displayEquity: get().displayEquity > 0 ? get().displayEquity : equity,
      });
    } catch (err) {
      set({ error: err instanceof Error ? err.message : "Az egyenleg nem olvasható." });
    }
  },

  interpret: async () => {
    set({ busy: true, error: null });
    try {
      const res = await interpretPrompt({ data: { prompt: get().prompt } });
      set({ rails: res.rails, stance: res.stance, stanceNote: res.note });
    } catch {
      set({ stanceNote: "Alap sínek. A WARDEN nem kapcsolható ki." });
    } finally {
      set({ busy: false });
    }
  },

  arm: async () => {
    const s = get();
    if (!s.pubkey) {
      set({ error: "Előbb csatlakoztasd a tárcát." });
      return;
    }
    const equity = equityOf(s.sol, s.usdc, s.solPrice, s.positions);
    if (equity < 2) {
      set({ error: "Éleshez legalább ~$2 SOL/USDC kell a tárcában." });
      return;
    }
    const now = Date.now();
    const agents = emptyLiveAgents();
    (Object.keys(agents) as AgentId[]).forEach((id) => {
      agents[id] = { ...agents[id], status: "scanning", note: "figyel", heat: 0.4 };
    });
    set({
      phase: "live",
      startEquity: equity,
      equity,
      displayEquity: equity,
      startedAt: now,
      clockMs: 0,
      agents,
      decisions: [],
      logs: [
        {
          id: nid("l"),
          t: 0,
          agent: "JEV",
          text: "éles. a tőke a tárcádban marad. kitöltés csak aláírás után.",
        },
        {
          id: nid("l"),
          t: 0,
          agent: "WARDEN",
          text: s.stanceNote || "sínek élnek. gyanús útvonalon semmi sem megy át.",
        },
      ],
      points: [{ t: 0, equity }],
      stats: emptyLiveStats(),
      currentDecision: null,
      ticket: null,
      seen: [],
      error: null,
    });
    persist(get());
  },

  pause: () => {
    if (get().phase === "live") set({ phase: "paused" });
    persist(get());
  },
  resume: () => {
    if (get().phase === "paused") set({ phase: "live" });
  },
  kill: () => {
    set({
      phase: "killed",
      ticket: null,
      logs: appendLog(get().logs, get().clockMs, "WARDEN", "kill switch. nincs új ticket."),
    });
    persist(get());
  },
  reset: () => {
    void disconnectWallet(providerRef);
    providerRef = null;
    const prompt = get().prompt;
    set({ ...blank(), prompt, hydrated: true, rails: DEFAULT_RAILS });
    persist(get());
  },

  decay: (dt) => {
    const s = get();
    if (s.phase !== "live" && s.phase !== "paused") return;
    const agents = decayHeat(s.agents, dt);
    const follow = 1 - Math.exp(-dt / 280);
    const displayEquity = s.displayEquity + (s.equity - s.displayEquity) * follow;
    if (agents !== s.agents || Math.abs(displayEquity - s.displayEquity) > 0.002) {
      set({ agents, displayEquity });
    }
  },

  tickClock: () => {
    const s = get();
    if (s.phase !== "live" && s.phase !== "paused") return;
    const clockMs = Math.max(0, Date.now() - s.startedAt);
    const ticket = s.ticket;
    if (ticket && ticket.status === "pending" && Date.now() - ticket.t > TICKET_TTL_MS) {
      set({
        clockMs,
        ticket: { ...ticket, status: "expired", error: "A quote lejárt." },
        logs: appendLog(s.logs, clockMs, "FLUX", "ticket lejárt — új quote kell."),
      });
      return;
    }
    set({ clockMs });
  },

  cycle: async () => {
    const s = get();
    if (s.phase !== "live" || s.busy || s.ticket?.status === "pending" || s.ticket?.status === "signing") return;
    if (killedEquity(s.startEquity, s.equity, s.rails.dailyLossPct)) {
      get().kill();
      set({
        logs: appendLog(get().logs, get().clockMs, "WARDEN", "napi veszteséglimit. session zárva."),
      });
      return;
    }
    if (hourlyFillCount(s.fills, Date.now()) >= s.rails.maxHourlyTrades) {
      set({
        logs: appendLog(s.logs, s.clockMs, "WARDEN", "óránkénti fill limit. várok."),
      });
      return;
    }
    set({ busy: true, error: null });
    const clock = () => get().clockMs;
    const log = (agent: AgentId, text: string) => {
      set({ logs: appendLog(get().logs, clock(), agent, text) });
    };
    const heat = (id: AgentId, status: AgentState["status"], note: string) => {
      const agents = { ...get().agents, [id]: { ...get().agents[id], status, note, heat: 1 } };
      set({ agents });
    };
    try {
      heat("SCOUT", "scanning", "szalag");
      const scan = await scanMarket({
        data: { minLiqUsd: s.rails.minLiqUsd, minAgeHours: s.rails.minAgeHours },
      });
      const held = new Set(get().positions.map((p) => p.mint));
      const seen = new Set(get().seen);
      const cand = pickCandidate(scan.candidates, seen, held);
      set({
        candidates: scan.candidates,
        solPrice: scan.solPrice || get().solPrice,
      });
      if (!cand) {
        log("SCOUT", "nincs új, tiszta könyv a síneken belül.");
        heat("SCOUT", "scanning", "nincs tiszta minta");
        return;
      }
      set({ seen: [...get().seen, cand.poolId].slice(-48) });
      heat("SCOUT", "flagged", `${cand.pair} · TVL $${Math.round(cand.tvlUsd).toLocaleString("en-US")}`);
      log("SCOUT", `minta: ${cand.pair} · 24h vol $${Math.round(cand.volume24h).toLocaleString("en-US")}`);

      await wait(280);
      heat("LEDGER", "confirming", "pool-flow");
      log("LEDGER", `flow ${cand.turnover.toFixed(2)}× TVL · nem tárcamásolás élesben`);

      await wait(240);
      heat("PULSE", "confirming", "sáv");
      log("PULSE", `sáv ${cand.rangePct.toFixed(1)}% · csúcshoz ${(cand.nearHigh * 100).toFixed(0)}%`);

      const solSpend = sizeInSol(get().sol, get().rails.sizePct);
      const lamports = Math.floor(solSpend * 1e9);
      let quote: QuotePreview | null = null;
      if (lamports >= 1_000_000) {
        try {
          quote = await quoteRoute({
            data: {
              inputMint: SOL_MINT,
              outputMint: cand.mint,
              amount: String(lamports),
              slippageBps: get().rails.slippageBps,
            },
          });
          heat("FLUX", "routing", quote.route);
        } catch (err) {
          heat("FLUX", "scanning", "nincs tiszta út");
          log("FLUX", err instanceof Error ? err.message : "útvonal hiba");
        }
      } else {
        log("FLUX", "túl kicsi a méret a síneken — nincs quote.");
      }

      const ev = evaluateCandidate(cand, get().rails, quote);
      const decision: DecisionEvent = {
        id: nid("d"),
        t: clock(),
        decision: ev.decision,
        confidence: ev.confidence,
        pair: cand.pair,
        rationale: ev.rationale,
        warden: ev.warden,
        wardenReason: ev.wardenReason,
      };
      heat("JEV", "flagged", `${ev.decision} · ${(ev.confidence * 100).toFixed(1)}%`);
      log("JEV", `${ev.decision} ${(ev.confidence * 100).toFixed(1)}% — ${cand.pair}`);
      set({
        currentDecision: decision,
        decisions: pushCap(get().decisions, decision, 80),
        stats: {
          ...get().stats,
          decisions: get().stats.decisions + 1,
          skips: get().stats.skips + (ev.decision === "SKIP" || ev.decision === "PASS" ? 1 : 0),
          blocks: get().stats.blocks + (ev.warden === "BLOCKED" ? 1 : 0),
        },
      });

      await wait(200);
      if (ev.warden === "BLOCKED") {
        heat("WARDEN", "blocking", "blokkolva");
        log("WARDEN", `BLOKKOLVA — ${ev.wardenReason}`);
        return;
      }
      heat("WARDEN", "approved", "jóváhagyva");
      log("WARDEN", `jóváhagyva — ${ev.wardenReason}`);

      if ((ev.decision === "BUY" || ev.decision === "COPY") && quote) {
        const notional = (lamports / 1e9) * (get().solPrice || 0);
        const ticket: LiveTicket = {
          id: nid("t"),
          side: "IN",
          pair: cand.pair,
          mint: cand.mint,
          mintDecimals: cand.mintDecimals,
          inputMint: SOL_MINT,
          outputMint: cand.mint,
          notionalUsd: notional,
          amountIn: quote.inAmount,
          expectedOut: quote.outAmount,
          impactPct: quote.priceImpactPct,
          route: quote.route,
          decision: ev.decision,
          confidence: ev.confidence,
          rationale: ev.rationale,
          wardenReason: ev.wardenReason,
          status: "pending",
          t: Date.now(),
        };
        set({ ticket });
        log("FLUX", `ticket készen — ${cand.pair}. aláírás a tárcádban.`);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "ciklus hiba";
      set({ error: message, logs: appendLog(get().logs, clock(), "JEV", message) });
    } finally {
      set({ busy: false });
    }
  },

  signTicket: async () => {
    const s = get();
    const ticket = s.ticket;
    const pubkey = s.pubkey;
    if (!ticket || ticket.status === "signing" || ticket.status === "sent") return;
    if (!providerRef || !pubkey) {
      set({ error: "A tárca nincs csatlakoztatva." });
      return;
    }
    set({ ticket: { ...ticket, status: "signing" }, busy: true, error: null });
    try {
      const built = await buildSwap({
        data: {
          inputMint: ticket.inputMint,
          outputMint: ticket.outputMint,
          amount: ticket.amountIn,
          slippageBps: s.rails.slippageBps,
          userPublicKey: pubkey,
        },
      });
      const signature = await signAndSendSwap(providerRef, built.swapTransaction);
      const clockMs = get().clockMs;
      const fill: FillEvent = {
        id: nid("f"),
        t: clockMs,
        pair: ticket.pair,
        side: ticket.side,
        notional: ticket.notionalUsd,
        pnl: 0,
        latencyMs: Math.max(1, Date.now() - ticket.t),
        route: ticket.route,
        equity: get().equity,
      };
      const outUi = Number(ticket.expectedOut) / 10 ** ticket.mintDecimals;
      const positions = pushCap(
        get().positions.filter((p) => p.mint !== ticket.mint),
        {
          mint: ticket.mint,
          symbol: ticket.pair.split("/")[0] ?? ticket.pair,
          pair: ticket.pair,
          decimals: ticket.mintDecimals,
          amount: outUi,
          costUsd: ticket.notionalUsd,
          markUsd: ticket.notionalUsd,
        },
        12,
      );
      set({
        ticket: { ...ticket, status: "sent", signature },
        fills: pushCap(get().fills, fill, 80),
        positions,
        stats: { ...get().stats, fills: get().stats.fills + 1 },
        logs: appendLog(
          get().logs,
          clockMs,
          "FLUX",
          `láncra ment ${signature.slice(0, 8)}…${signature.slice(-6)}`,
        ),
        points: pushCap(get().points, { t: clockMs, equity: get().equity }, 180),
      });
      persist(get());
      await get().refreshBalances();
    } catch (err) {
      const message = err instanceof Error ? err.message : "az aláírás megszakadt";
      set({
        ticket: { ...ticket, status: "failed", error: message },
        error: message,
        logs: appendLog(get().logs, get().clockMs, "FLUX", message),
      });
    } finally {
      set({ busy: false });
    }
  },

  dismissTicket: () => {
    const ticket = get().ticket;
    if (!ticket) return;
    set({
      ticket: null,
      logs: appendLog(get().logs, get().clockMs, "JEV", "ticket elengedve. nincs aláírás."),
    });
  },
}));

function wait(ms: number) {
  return new Promise<void>((resolve) => window.setTimeout(resolve, ms));
}
