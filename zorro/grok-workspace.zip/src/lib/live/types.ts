import type { AgentId, AgentState, Decision, DecisionEvent, FillEvent, LogEvent, EquityPoint, Stats, WardenVerdict } from "@/lib/desk/types";

export const SOL_MINT = "So11111111111111111111111111111111111111112";
export const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
export const SOL_DECIMALS = 9;
export const USDC_DECIMALS = 6;
export const FEE_BUFFER_SOL = 0.02;
export const TICKET_TTL_MS = 45_000;
export const CYCLE_MS = 14_000;

export const STABLE_MINTS = new Set([
  USDC_MINT,
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11MCCe8BenwNYB", // USDT
  "USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB",
  "2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo", // PYUSD
]);

export const STABLE_SYMBOLS = new Set(["USDC", "USDT", "USD1", "PYUSD", "USDS", "DAI"]);
export const SOL_SYMBOLS = new Set(["SOL", "WSOL"]);

export interface LiveRails {
  sizePct: number;
  dailyLossPct: number;
  slippageBps: number;
  minLiqUsd: number;
  minAgeHours: number;
  maxImpactPct: number;
  maxHourlyTrades: number;
}

export const DEFAULT_RAILS: LiveRails = {
  sizePct: 6,
  dailyLossPct: 10,
  slippageBps: 80,
  minLiqUsd: 80_000,
  minAgeHours: 24,
  maxImpactPct: 1.5,
  maxHourlyTrades: 6,
};

export interface MarketCandidate {
  poolId: string;
  pair: string;
  mint: string;
  mintDecimals: number;
  quoteMint: string;
  quoteSymbol: string;
  symbol: string;
  name: string;
  tvlUsd: number;
  volume24h: number;
  turnover: number;
  priceUsd: number;
  rangePct: number;
  nearHigh: number;
  ageHours: number;
  feeApr: number;
  dex: string;
}

export interface QuotePreview {
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  priceImpactPct: number;
  route: string;
}

export interface EvalResult {
  decision: Decision;
  confidence: number;
  rationale: string;
  warden: WardenVerdict;
  wardenReason: string;
  scoutNote: string;
  ledgerNote: string;
  pulseNote: string;
  fluxNote: string;
}

export type TicketStatus = "pending" | "signing" | "sent" | "failed" | "expired";

export interface LiveTicket {
  id: string;
  side: "IN" | "OUT";
  pair: string;
  mint: string;
  mintDecimals: number;
  inputMint: string;
  outputMint: string;
  notionalUsd: number;
  amountIn: string;
  expectedOut: string;
  impactPct: number;
  route: string;
  decision: Decision;
  confidence: number;
  rationale: string;
  wardenReason: string;
  status: TicketStatus;
  error?: string;
  signature?: string;
  t: number;
}

export interface Position {
  mint: string;
  symbol: string;
  pair: string;
  decimals: number;
  amount: number;
  costUsd: number;
  markUsd: number;
}

export interface WalletSnap {
  pubkey: string;
  walletName: string;
  sol: number;
  usdc: number;
  solPrice: number;
}

export type LivePhase = "off" | "arming" | "live" | "paused" | "killed";

export interface LiveDraft {
  equity: number;
  startEquity: number;
  agents: Record<AgentId, AgentState>;
  decisions: DecisionEvent[];
  fills: FillEvent[];
  logs: LogEvent[];
  points: EquityPoint[];
  stats: Stats;
  currentDecision: DecisionEvent | null;
}

export function clampRails(input: Partial<LiveRails>): LiveRails {
  const n = (v: number | undefined, lo: number, hi: number, fallback: number) => {
    const x = Number(v);
    if (!Number.isFinite(x)) return fallback;
    return Math.min(hi, Math.max(lo, x));
  };
  return {
    sizePct: n(input.sizePct, 2, 20, DEFAULT_RAILS.sizePct),
    dailyLossPct: n(input.dailyLossPct, 5, 20, DEFAULT_RAILS.dailyLossPct),
    slippageBps: n(input.slippageBps, 30, 200, DEFAULT_RAILS.slippageBps),
    minLiqUsd: n(input.minLiqUsd, 25_000, 2_000_000, DEFAULT_RAILS.minLiqUsd),
    minAgeHours: n(input.minAgeHours, 1, 168, DEFAULT_RAILS.minAgeHours),
    maxImpactPct: n(input.maxImpactPct, 0.3, 4, DEFAULT_RAILS.maxImpactPct),
    maxHourlyTrades: n(input.maxHourlyTrades, 1, 12, DEFAULT_RAILS.maxHourlyTrades),
  };
}
