import { SOL_MINT, USDC_MINT } from "./types";

export interface InjectedWallet {
  name: string;
  provider: SolanaProvider;
}

export interface SolanaProvider {
  isPhantom?: boolean;
  isSolflare?: boolean;
  isBackpack?: boolean;
  publicKey?: { toString(): string } | null;
  connect: (opts?: { onlyIfTrusted?: boolean }) => Promise<{ publicKey: { toString(): string } }>;
  disconnect?: () => Promise<void>;
  signAndSendTransaction: (tx: unknown) => Promise<{ signature: string }>;
  on?: (event: string, cb: (...args: unknown[]) => void) => void;
  off?: (event: string, cb: (...args: unknown[]) => void) => void;
}

declare global {
  interface Window {
    solana?: SolanaProvider;
    phantom?: { solana?: SolanaProvider };
    solflare?: SolanaProvider;
    backpack?: { solana?: SolanaProvider };
  }
}

export function isEmbeddedPreview(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function detectWallets(): InjectedWallet[] {
  if (typeof window === "undefined") return [];
  const found: InjectedWallet[] = [];
  const phantom = window.phantom?.solana ?? (window.solana?.isPhantom ? window.solana : undefined);
  const solflare = window.solflare;
  const backpack = window.backpack?.solana;
  if (phantom) found.push({ name: "Phantom", provider: phantom });
  if (solflare) found.push({ name: "Solflare", provider: solflare });
  if (backpack) found.push({ name: "Backpack", provider: backpack });
  if (found.length === 0 && window.solana) found.push({ name: "Solana", provider: window.solana });
  return found;
}

export async function connectWallet(provider: SolanaProvider): Promise<string> {
  const res = await provider.connect();
  const key = res?.publicKey?.toString() ?? provider.publicKey?.toString();
  if (!key) throw new Error("A tárca nem adott címet.");
  return key;
}

export async function disconnectWallet(provider: SolanaProvider | null) {
  try {
    await provider?.disconnect?.();
  } catch {
    /* ignore */
  }
}

function b64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

export async function signAndSendSwap(provider: SolanaProvider, swapTransaction: string): Promise<string> {
  const { VersionedTransaction } = await import("@solana/web3.js");
  const tx = VersionedTransaction.deserialize(b64ToBytes(swapTransaction));
  const res = await provider.signAndSendTransaction(tx);
  const sig = typeof res === "string" ? res : res?.signature;
  if (!sig) throw new Error("A tárca nem küldött aláírást.");
  return sig;
}

export { SOL_MINT, USDC_MINT };
