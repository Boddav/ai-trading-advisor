import { AGENT_META, type AgentId, type AgentState, type Decision, type Stats } from "@/lib/desk/types";
import { FEE_BUFFER_SOL, type EvalResult, type LiveRails, type MarketCandidate, type QuotePreview } from "./types";

function clamp01(n: number) {
  if (!Number.isFinite(n)) return 0;
  return Math.min(1, Math.max(0, n));
}

function usd(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1000) return `$${(n / 1000).toFixed(0)}k`;
  return `$${n.toFixed(0)}`;
}

export function emptyLiveAgents(): Record<AgentId, AgentState> {
  const agents = {} as Record<AgentId, AgentState>;
  (Object.keys(AGENT_META) as AgentId[]).forEach((id) => {
    agents[id] = { id, status: "idle", note: "", heat: 0 };
  });
  return agents;
}

export function emptyLiveStats(): Stats {
  return { fills: 0, wins: 0, blocks: 0, skips: 0, decisions: 0 };
}

export function evaluateCandidate(
  c: MarketCandidate,
  rails: LiveRails,
  quote: QuotePreview | null,
): EvalResult {
  const turnover = c.turnover;
  const scout =
    (c.ageHours < 72 && c.ageHours >= rails.minAgeHours ? 0.22 : 0.08) +
    (turnover > 1.2 ? 0.34 : turnover > 0.45 ? 0.2 : 0.06) +
    (c.volume24h > 1_000_000 ? 0.22 : c.volume24h > 250_000 ? 0.12 : 0.04) +
    (c.nearHigh > 0.7 ? 0.16 : 0.04);

  const ledger =
    (turnover > 0.8 ? 0.38 : turnover > 0.35 ? 0.2 : 0.06) +
    (c.tvlUsd > 500_000 ? 0.28 : c.tvlUsd > 150_000 ? 0.16 : 0.05) +
    (c.feeApr > 40 ? 0.2 : c.feeApr > 15 ? 0.1 : 0.04) +
    (c.volume24h > 2_000_000 ? 0.14 : 0.04);

  const pulse =
    (c.nearHigh > 0.82 ? 0.36 : c.nearHigh > 0.55 ? 0.2 : c.nearHigh < 0.25 ? 0.04 : 0.12) +
    (c.rangePct > 12 ? 0.28 : c.rangePct > 5 ? 0.16 : 0.06) +
    (turnover > 0.6 ? 0.22 : 0.08) +
    (c.volume24h > 800_000 ? 0.14 : 0.06);

  const scoutScore = clamp01(scout);
  const ledgerScore = clamp01(ledger);
  const pulseScore = clamp01(pulse);

  const impact = quote?.priceImpactPct ?? 0;
  const reasons: string[] = [];
  if (c.tvlUsd < rails.minLiqUsd) reasons.push(`likviditás ${usd(c.tvlUsd)} a ${usd(rails.minLiqUsd)} küszöb alatt`);
  if (c.ageHours < rails.minAgeHours) reasons.push(`pár túl friss (${c.ageHours.toFixed(0)} óra)`);
  if (c.tvlUsd > 0 && c.volume24h / c.tvlUsd > 25) reasons.push("volumen/TVL szélsőséges — vékony könyv gyanú");
  if (impact > rails.maxImpactPct) reasons.push(`árhatás ${impact.toFixed(2)}% a ${rails.maxImpactPct}% limit felett`);
  if (c.priceUsd <= 0) reasons.push("nincs megbízható ár");

  const blocked = reasons.length > 0;
  const wardenReason = blocked ? reasons[0] : "likviditás, kor és útvonal rendben";

  const fluxOk = Boolean(quote) && impact <= rails.maxImpactPct;
  const fluxNote = quote
    ? `${quote.route}, hatás ${impact.toFixed(2)}%`
    : "útvonalra várok";

  let decision: Decision;
  if (scoutScore < 0.28) decision = "SKIP";
  else if (ledgerScore < 0.28) decision = "PASS";
  else if (ledgerScore >= scoutScore) decision = "COPY";
  else decision = "BUY";

  const confidence = clamp01(
    0.34 * scoutScore + 0.3 * ledgerScore + 0.24 * pulseScore + 0.12 * (fluxOk ? 1 : 0.35),
  );

  const rationale =
    decision === "SKIP"
      ? "SCOUT: a minta nem elég tiszta ehhez a poolhoz"
      : decision === "PASS"
        ? "LEDGER: a flow nem erős, aszimmetria kevés"
        : decision === "COPY"
          ? "LEDGER flow + PULSE — megállapodott könyv, nem vad mintázás"
          : "SCOUT minta + PULSE közeli csúcs — belépés csak WARDEN után";

  return {
    decision,
    confidence,
    rationale,
    warden: blocked ? "BLOCKED" : "APPROVED",
    wardenReason,
    scoutNote: turnover > 0.45
      ? `forgalom/TVL ${turnover.toFixed(2)} · ${c.pair}`
      : `gyenge forgalom a ${c.pair} könyvön`,
    ledgerNote: `TVL ${usd(c.tvlUsd)} · 24h ${usd(c.volume24h)} · díj APR ${c.feeApr.toFixed(0)}%`,
    pulseNote: `24h sáv ${c.rangePct.toFixed(1)}% · a csúcshoz ${(c.nearHigh * 100).toFixed(0)}%`,
    fluxNote,
  };
}

export function pickCandidate(
  list: MarketCandidate[],
  seen: Set<string>,
  heldMints: Set<string>,
): MarketCandidate | null {
  const fresh = list.filter((c) => !seen.has(c.poolId) && !heldMints.has(c.mint));
  const pool = fresh.length > 0 ? fresh : list.filter((c) => !heldMints.has(c.mint));
  if (pool.length === 0) return null;
  return pool[0] ?? null;
}

export function sizeInSol(solBalance: number, sizePct: number): number {
  const spendable = Math.max(0, solBalance - FEE_BUFFER_SOL);
  return Math.max(0, spendable * (sizePct / 100));
}

export function killedEquity(start: number, now: number, dailyLossPct: number): boolean {
  if (start <= 0) return false;
  return now <= start * (1 - dailyLossPct / 100);
}

export function hourlyFillCount(fills: { t: number }[], now: number): number {
  const cut = now - 60 * 60 * 1000;
  return fills.filter((f) => f.t >= cut).length;
}
