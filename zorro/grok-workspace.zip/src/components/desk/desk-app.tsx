import { useEffect } from "react";
import { BootScreen } from "@/components/desk/boot-screen";
import { DeskShell } from "@/components/desk/desk-shell";
import { LiveArm } from "@/components/desk/live-arm";
import { LiveShell } from "@/components/desk/live-shell";
import { useDeskStore } from "@/lib/desk/store";
import { useLiveStore } from "@/lib/live/store";

export function DeskApp() {
  const paperHydrated = useDeskStore((s) => s.hydrated);
  const paperPhase = useDeskStore((s) => s.phase);
  const liveHydrated = useLiveStore((s) => s.hydrated);
  const livePhase = useLiveStore((s) => s.phase);
  const hydratePaper = useDeskStore((s) => s.hydrate);
  const hydrateLive = useLiveStore((s) => s.hydrate);

  useEffect(() => {
    hydratePaper();
    hydrateLive();
  }, [hydratePaper, hydrateLive]);

  if (!paperHydrated || !liveHydrated) return <BootScreen />;
  if (livePhase === "arming") return <LiveArm />;
  if (livePhase === "live" || livePhase === "paused" || livePhase === "killed") return <LiveShell />;
  if (paperPhase === "boot") return <BootScreen />;
  return <DeskShell />;
}