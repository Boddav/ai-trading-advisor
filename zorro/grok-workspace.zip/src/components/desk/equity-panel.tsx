import { START_EQUITY } from "@/lib/desk/types";
import { formatPct, formatUsd, multipleOf } from "@/lib/desk/format";
import { useDeskStore } from "@/lib/desk/store";
import { cn } from "@/lib/utils";

export function EquityPanel({
  startEquity,
  display,
  equity,
  points,
}: {
  startEquity?: number;
  display?: number;
  equity?: number;
  points?: { t: number; equity: number }[];
} = {}) {
  const paperDisplay = useDeskStore((s) => s.displayEquity);
  const paperEquity = useDeskStore((s) => s.equity);
  const paperPoints = useDeskStore((s) => s.points);
  const start = startEquity ?? START_EQUITY;
  const shown = display ?? paperDisplay;
  const eq = equity ?? paperEquity;
  const series = points ?? paperPoints;
  const rising = shown >= start - 0.001;
  const pct = start > 0 ? (shown / start - 1) * 100 : 0;
  const multiple = multipleOf(start, shown);

  return (
    <section className="flex h-full flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] sm:p-5">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">Egyenleg</p>
        <p className="font-mono text-xs tabular-nums text-muted">
          {formatUsd(start)} → {multiple}
        </p>
      </div>
      <p
        className={cn(
          "mt-3 font-mono text-4xl font-medium tracking-tight tabular-nums sm:text-5xl",
          rising ? "text-up" : "text-down",
        )}
      >
        {formatUsd(shown)}
      </p>
      <p className={cn("mt-1 font-mono text-sm tabular-nums", pct >= 0 ? "text-up" : "text-down")}>
        {formatPct(pct)}
      </p>
      <div className="mt-5 min-h-0 flex-1">
        <EquityChart points={series} current={eq} start={start} />
      </div>
    </section>
  );
}

function EquityChart({
  points,
  current,
  start,
}: {
  points: { t: number; equity: number }[];
  current: number;
  start: number;
}) {
  const series =
    points.length > 0
      ? points
      : [
          { t: 0, equity: start },
          { t: 1, equity: start },
        ];
  const last = series[series.length - 1];
  const drawn =
    last && Math.abs(last.equity - current) > 0.01
      ? [...series, { t: last.t + 1, equity: current }]
      : series;

  const w = 640;
  const h = 220;
  const padX = 8;
  const padY = 12;
  const min = Math.min(start, ...drawn.map((p) => p.equity));
  const max = Math.max(start * 1.05, ...drawn.map((p) => p.equity));
  const span = Math.max(max - min, 0.01);
  const t0 = drawn[0].t;
  const t1 = Math.max(drawn[drawn.length - 1].t, t0 + 1);

  const xOf = (t: number) => padX + ((t - t0) / (t1 - t0)) * (w - padX * 2);
  const yOf = (v: number) => padY + (1 - (v - min) / span) * (h - padY * 2);

  const d = drawn
    .map((p, i) => `${i === 0 ? "M" : "L"} ${xOf(p.t).toFixed(1)} ${yOf(p.equity).toFixed(1)}`)
    .join(" ");
  const area = `${d} L ${xOf(drawn[drawn.length - 1].t).toFixed(1)} ${h - padY} L ${xOf(drawn[0].t).toFixed(1)} ${h - padY} Z`;
  const up = current >= start;

  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className={cn("h-40 w-full sm:h-48 xl:h-full xl:min-h-44", up ? "text-up" : "text-down")}
      role="img"
      aria-label="Egyenleggörbe"
    >
      <line
        x1={padX}
        x2={w - padX}
        y1={yOf(start)}
        y2={yOf(start)}
        stroke="currentColor"
        strokeOpacity="0.2"
        strokeDasharray="3 5"
      />
      <path d={area} fill="currentColor" fillOpacity="0.12" />
      <path d={d} fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinejoin="round" />
    </svg>
  );
}
