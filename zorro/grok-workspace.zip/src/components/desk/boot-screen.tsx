import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MeridianMark } from "@/components/desk/mark";
import { DEFAULT_PROMPT, START_EQUITY } from "@/lib/desk/types";
import { formatUsd } from "@/lib/desk/format";
import { useDeskStore } from "@/lib/desk/store";
import { useLiveStore } from "@/lib/live/store";

export function BootScreen() {
  const prompt = useDeskStore((s) => s.prompt);
  const setPrompt = useDeskStore((s) => s.setPrompt);
  const start = useDeskStore((s) => s.start);
  const beginArm = useLiveStore((s) => s.beginArm);
  const setLivePrompt = useLiveStore((s) => s.setPrompt);
  const interpret = useLiveStore((s) => s.interpret);
  const [focused, setFocused] = useState(false);

  const resolved = () => {
    const value = prompt.trim() || DEFAULT_PROMPT;
    if (!prompt.trim()) setPrompt(DEFAULT_PROMPT);
    return value;
  };

  return (
    <main className="relative min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-3xl flex-col justify-center px-5 py-10 sm:px-8">
        <div className="stagger-in flex flex-col gap-8">
          <div className="flex items-center gap-3 text-muted">
            <MeridianMark className="size-7" />
            <span className="text-xs font-medium tracking-[0.22em] uppercase">
              Meridian Desk
            </span>
          </div>

          <div className="flex flex-col gap-4">
            <h1 className="max-w-xl text-3xl font-medium leading-tight tracking-[-0.03em] text-fg sm:text-4xl">
              Egyetlen prompt. Négy ügynök. Egy kapuőr.
            </h1>
            <p className="max-w-lg text-base leading-relaxed text-muted">
              A JEV nem nyúl a kereskedésekhez. Olvassa a piacot, kiad egy döntést,
              és semmi sem hajtódik végre, amíg a WARDEN jóvá nem hagyja.
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <div className="flex items-baseline justify-between gap-3">
              <label htmlFor="jev-prompt" className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">
                Prompt a JEV-nek
              </label>
              <span className="font-mono text-xs tabular-nums text-muted">
                papír {formatUsd(START_EQUITY)}
              </span>
            </div>
            <div
              className={`rounded-2xl bg-surface p-2 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] transition-[box-shadow] duration-150 ${
                focused ? "shadow-[0_0_0_1px_rgba(244,244,245,0.22)]" : ""
              }`}
            >
              <div className="flex items-start gap-3 rounded-xl bg-elevated px-4 py-4">
                <span className="mt-0.5 font-mono text-sm text-subtle" aria-hidden>
                  {">"}
                </span>
                <textarea
                  id="jev-prompt"
                  rows={2}
                  value={prompt}
                  onFocus={() => setFocused(true)}
                  onBlur={() => setFocused(false)}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-14 w-full resize-none bg-transparent font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-subtle"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Button
                size="lg"
                className="w-full sm:w-auto"
                onClick={() => {
                  resolved();
                  start();
                }}
              >
                Papír session
              </Button>
              <Button
                size="lg"
                variant="ghost"
                className="w-full sm:w-auto"
                onClick={() => {
                  const value = resolved();
                  setLivePrompt(value);
                  beginArm();
                  void interpret();
                }}
              >
                Éles tőke
              </Button>
            </div>
            <p className="text-sm text-subtle">
              Papír: scriptelt éjszaka, $15.89-ről. Éles: Solana-tárca, Jupiter-swap,
              minden fill aláírás. Nincs 1000x ígéret.
            </p>
          </div>

          <ul className="grid grid-cols-1 gap-3 pt-4 sm:grid-cols-2">
            {[
              ["SCOUT", "Elkapja az új mintákat, mielőtt a tömeg észrevenné."],
              ["LEDGER", "Tárcákat figyel, valódi nyerési aránnyal másol."],
              ["PULSE", "Lendületet és hangulatot követ, ahogy változik."],
              ["FLUX", "A legtisztább útvonalat találja, a kitöltés ne csússzon."],
            ].map(([name, blurb]) => (
              <li
                key={name}
                className="rounded-xl bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(244,244,245,0.07)]"
              >
                <p className="font-mono text-xs tracking-[0.14em] text-fg">{name}</p>
                <p className="mt-1 text-sm leading-snug text-muted">{blurb}</p>
              </li>
            ))}
          </ul>
          <p className="text-sm text-subtle">
            A WARDEN az egész alján ül. Rossz likviditás, mézescsupor, bármi gyanús —
            blokkol, és semmi sem történik.
          </p>
        </div>
      </div>
    </main>
  );
}