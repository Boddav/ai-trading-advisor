import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { MeridianMark } from "@/components/desk/mark";
import { formatUsd } from "@/lib/desk/format";
import { detectWallets, isEmbeddedPreview } from "@/lib/live/wallet";
import { useLiveStore } from "@/lib/live/store";
import { DEFAULT_RAILS } from "@/lib/live/types";
import { cn } from "@/lib/utils";

const ACKS = [
  { id: "paper", label: "Az éjszakai 1000x papír volt, nem valós eredmény." },
  { id: "loss", label: "Elveszíthetem a teljes tételt. Nincs hozamígéret." },
  { id: "sign", label: "Minden kitöltést a saját tárcámban írok alá." },
  { id: "advice", label: "Ez eszköz, nem pénzügyi tanács." },
] as const;

export function LiveArm() {
  const prompt = useLiveStore((s) => s.prompt);
  const rails = useLiveStore((s) => s.rails);
  const setRails = useLiveStore((s) => s.setRails);
  const pubkey = useLiveStore((s) => s.pubkey);
  const walletName = useLiveStore((s) => s.walletName);
  const sol = useLiveStore((s) => s.sol);
  const usdc = useLiveStore((s) => s.usdc);
  const solPrice = useLiveStore((s) => s.solPrice);
  const stance = useLiveStore((s) => s.stance);
  const stanceNote = useLiveStore((s) => s.stanceNote);
  const busy = useLiveStore((s) => s.busy);
  const error = useLiveStore((s) => s.error);
  const connect = useLiveStore((s) => s.connect);
  const cancelArm = useLiveStore((s) => s.cancelArm);
  const arm = useLiveStore((s) => s.arm);
  const refreshBalances = useLiveStore((s) => s.refreshBalances);

  const [acks, setAcks] = useState<Record<string, boolean>>({});
  const [phrase, setPhrase] = useState("");
  const [wallets, setWallets] = useState(() => (typeof window === "undefined" ? [] : detectWallets()));
  const embedded = typeof window !== "undefined" && isEmbeddedPreview();
  const equity = sol * solPrice + usdc;
  const ready =
    Boolean(pubkey) &&
    ACKS.every((a) => acks[a.id]) &&
    phrase.trim().toUpperCase() === "ÉLES" &&
    equity >= 2;

  useEffect(() => {
    const id = window.setInterval(() => setWallets(detectWallets()), 1500);
    return () => window.clearInterval(id);
  }, []);

  return (
    <main className="relative min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-3xl flex-col justify-center px-5 py-10 sm:px-8">
        <div className="stagger-in flex flex-col gap-8">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-muted">
              <MeridianMark className="size-7" />
              <span className="text-xs font-medium tracking-[0.22em] uppercase">Éles tőke</span>
            </div>
            <Button variant="quiet" onClick={cancelArm}>
              Vissza
            </Button>
          </div>

          <div className="flex flex-col gap-3">
            <h1 className="max-w-xl text-3xl font-medium leading-tight tracking-[-0.03em] sm:text-4xl">
              A tőke a tárcádban marad. A JEV csak dönt.
            </h1>
            <p className="max-w-lg text-base leading-relaxed text-muted">
              Az éjszakai $15.89 → $16 356 scriptelt papír-session volt. Élesben a SCOUT
              valódi Raydium-könyveket olvas, a FLUX Jupiter-útvonalat épít, a WARDEN
              síneken tart, és semmi nem megy a láncra, amíg a tárcádban alá nem írod.
            </p>
          </div>

          <section className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)] sm:p-5">
            <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">Tárca</p>
            {pubkey ? (
              <div className="mt-3 flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="font-mono text-sm text-fg">
                    {walletName} · {pubkey.slice(0, 4)}…{pubkey.slice(-4)}
                  </p>
                  <p className="mt-1 font-mono text-xs tabular-nums text-muted">
                    {sol.toFixed(4)} SOL · {usdc.toFixed(2)} USDC · {formatUsd(equity)}
                  </p>
                </div>
                <Button variant="ghost" disabled={busy} onClick={() => void refreshBalances()}>
                  Frissít
                </Button>
              </div>
            ) : (
              <div className="mt-3 flex flex-col gap-3">
                {wallets.length === 0 ? (
                  <p className="text-sm leading-relaxed text-muted">
                    Nincs Phantom, Solflare vagy Backpack ezen a lapon.
                    {embedded
                      ? " A preview-keretben a bővítmény gyakran rejtve marad — nyisd meg az appot a saját böngésződben."
                      : " Telepíts egy Solana-tárcát, majd töltsd újra."}
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {wallets.map((w) => (
                      <Button key={w.name} disabled={busy} onClick={() => void connect(w.name)}>
                        {w.name} csatlakozás
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </section>

          <section className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)] sm:p-5">
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">Sínek</p>
              <p className="font-mono text-[11px] uppercase tracking-wide text-muted">{stance}</p>
            </div>
            {stanceNote ? <p className="mt-2 text-sm leading-snug text-muted">{stanceNote}</p> : null}
            <p className="mt-2 font-mono text-[11px] text-subtle">{prompt}</p>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Rail
                label="méret / fill"
                suffix="%"
                min={2}
                max={20}
                step={1}
                value={rails.sizePct}
                onChange={(sizePct) => setRails({ sizePct })}
              />
              <Rail
                label="napi veszteség"
                suffix="%"
                min={5}
                max={20}
                step={1}
                value={rails.dailyLossPct}
                onChange={(dailyLossPct) => setRails({ dailyLossPct })}
              />
              <Rail
                label="csúszás"
                suffix=" bps"
                min={30}
                max={200}
                step={10}
                value={rails.slippageBps}
                onChange={(slippageBps) => setRails({ slippageBps })}
              />
              <Rail
                label="min. likviditás"
                suffix=""
                min={25_000}
                max={500_000}
                step={5_000}
                value={rails.minLiqUsd}
                format={(n) => `$${Math.round(n / 1000)}k`}
                onChange={(minLiqUsd) => setRails({ minLiqUsd })}
              />
            </div>
            <p className="mt-3 text-[11px] leading-snug text-subtle">
              A méret 20%-ban van plafonozva. A WARDEN, a napi limit és az aláírás nem kapcsolható ki.
              Alap: {DEFAULT_RAILS.sizePct}% / fill.
            </p>
          </section>

          <section className="flex flex-col gap-3">
            {ACKS.map((ack) => (
              <label key={ack.id} className="flex min-h-11 items-start gap-3 py-1 text-sm leading-snug text-muted">
                <input
                  type="checkbox"
                  className="mt-1 size-4 accent-fg"
                  checked={Boolean(acks[ack.id])}
                  onChange={(e) => setAcks((prev) => ({ ...prev, [ack.id]: e.target.checked }))}
                />
                <span>{ack.label}</span>
              </label>
            ))}
            <div className="mt-1">
              <label htmlFor="armed-phrase" className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">
                Írd be: ÉLES
              </label>
              <input
                id="armed-phrase"
                value={phrase}
                onChange={(e) => setPhrase(e.target.value)}
                className="mt-2 h-11 w-full rounded-lg bg-surface px-3 font-mono text-sm text-fg shadow-[0_0_0_1px_var(--color-border)] outline-none"
                autoComplete="off"
                spellCheck={false}
              />
            </div>
          </section>

          {error ? <p className="text-sm text-down">{error}</p> : null}

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button size="lg" className="w-full sm:w-auto" disabled={!ready || busy} onClick={() => void arm()}>
              Éles session
            </Button>
            <p className="text-sm text-subtle">
              {pubkey ? "A következő fill a tárcádban fog megjelenni." : "Tárca nélkül nincs éles mód."}
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}

function Rail({
  label,
  value,
  min,
  max,
  step,
  suffix,
  format,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix: string;
  format?: (n: number) => string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="flex flex-col gap-2">
      <span className="flex items-baseline justify-between gap-2">
        <span className="text-[11px] tracking-[0.14em] uppercase text-subtle">{label}</span>
        <span className="font-mono text-xs tabular-nums text-fg">
          {format ? format(value) : `${value}${suffix}`}
        </span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={cn("h-11 w-full accent-fg")}
      />
    </label>
  );
}
