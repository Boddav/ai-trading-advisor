import { Button } from "@/components/ui/button";
import { formatUsd } from "@/lib/desk/format";
import type { LiveTicket } from "@/lib/live/types";
import { cn } from "@/lib/utils";

export function TicketCard({
  ticket,
  busy,
  onSign,
  onDismiss,
}: {
  ticket: LiveTicket;
  busy: boolean;
  onSign: () => void;
  onDismiss: () => void;
}) {
  const pending = ticket.status === "pending";
  const signing = ticket.status === "signing";
  const sent = ticket.status === "sent";
  const failed = ticket.status === "failed" || ticket.status === "expired";

  return (
    <section className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-warden)_40%,transparent)] sm:p-5">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-warden">Ticket</p>
        <p className="font-mono text-[10px] tracking-[0.14em] uppercase text-subtle">{ticket.status}</p>
      </div>
      <div className="mt-3 flex flex-wrap items-baseline gap-3">
        <p className="font-mono text-2xl font-medium tracking-tight text-fg">{ticket.decision}</p>
        <p className="font-mono text-sm tabular-nums text-muted">{(ticket.confidence * 100).toFixed(1)}%</p>
        <p className="font-mono text-sm text-fg">{ticket.pair}</p>
      </div>
      <p className="mt-1 text-sm leading-snug text-muted">{ticket.rationale}</p>
      <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
        <Stat label="méret" value={formatUsd(ticket.notionalUsd)} />
        <Stat label="hatás" value={`${ticket.impactPct.toFixed(2)}%`} />
        <Stat label="út" value={ticket.route} />
        <Stat label="WARDEN" value="enged" />
      </dl>
      {ticket.error ? <p className="mt-3 text-sm text-down">{ticket.error}</p> : null}
      {sent && ticket.signature ? (
        <p className="mt-3 truncate font-mono text-[11px] text-up">
          {ticket.signature.slice(0, 12)}…{ticket.signature.slice(-8)}
        </p>
      ) : null}
      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <Button
          className="w-full sm:w-auto"
          disabled={!pending || busy}
          onClick={onSign}
        >
          {signing ? "Aláírás a tárcában…" : "Aláírás a tárcában"}
        </Button>
        <Button variant="ghost" className="w-full sm:w-auto" disabled={signing} onClick={onDismiss}>
          {failed || sent ? "Bezár" : "Elenged"}
        </Button>
      </div>
      <p className={cn("mt-3 text-[11px] leading-snug text-subtle")}>
        A tranzakció a te tárcádban jelenik meg. Nincs nálunk kulcs, nincs automatikus aláírás.
      </p>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-elevated px-3 py-2">
      <p className="text-[10px] tracking-[0.14em] uppercase text-subtle">{label}</p>
      <p className="mt-0.5 truncate font-mono text-xs text-fg">{value}</p>
    </div>
  );
}
