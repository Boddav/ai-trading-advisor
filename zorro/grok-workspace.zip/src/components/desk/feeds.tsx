import { useEffect, useRef, useState } from "react";
import type { Decision, DecisionEvent, FillEvent, LogEvent } from "@/lib/desk/types";
import { formatClock, formatUsd } from "@/lib/desk/format";
import { useDeskStore } from "@/lib/desk/store";
import { cn } from "@/lib/utils";

type Tab = "jev" | "tape" | "log";

export function Feeds({
  current,
  decisions,
  fills,
  logs,
}: {
  current?: DecisionEvent | null;
  decisions?: DecisionEvent[];
  fills?: FillEvent[];
  logs?: LogEvent[];
} = {}) {
  const [tab, setTab] = useState<Tab>("jev");

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-2">
      <div className="flex gap-1 rounded-xl bg-surface p-1 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] lg:hidden">
        {(
          [
            ["jev", "JEV"],
            ["tape", "Szalag"],
            ["log", "Log"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={cn(
              "h-10 flex-1 rounded-lg text-xs font-medium tracking-wide transition-colors duration-150",
              tab === id ? "bg-elevated text-fg" : "text-muted",
            )}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="grid min-h-0 flex-1 grid-cols-1 gap-2 lg:grid-cols-5">
        <div className={cn("min-h-0 lg:col-span-2", tab === "jev" ? "block" : "hidden lg:block")}>
          <JevPanel current={current} decisions={decisions} />
        </div>
        <div className={cn("min-h-0 lg:col-span-1", tab === "tape" ? "block" : "hidden lg:block")}>
          <TapePanel fills={fills} />
        </div>
        <div className={cn("min-h-0 lg:col-span-2", tab === "log" ? "block" : "hidden lg:block")}>
          <LogPanel logs={logs} />
        </div>
      </div>
    </div>
  );
}

function JevPanel({
  current,
  decisions,
}: {
  current?: DecisionEvent | null;
  decisions?: DecisionEvent[];
}) {
  const storeCurrent = useDeskStore((s) => s.currentDecision);
  const storeDecisions = useDeskStore((s) => s.decisions);
  const item = current === undefined ? storeCurrent : current;
  const list = decisions ?? storeDecisions;
  const recent = list.slice(-12).reverse();

  return (
    <section className="flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]">
      <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">JEV</p>
      {item ? <CurrentDecision item={item} /> : <IdleDecision />}
      <ul className="mt-4 min-h-0 flex-1 space-y-2 overflow-y-auto">
        {recent.map((row) => (
          <li key={row.id} className="flex items-baseline justify-between gap-3">
            <span className="flex items-baseline gap-2">
              <DecisionTag decision={row.decision} blocked={row.warden === "BLOCKED"} />
              <span className="font-mono text-xs text-muted">{row.pair}</span>
            </span>
            <span className="font-mono text-[11px] tabular-nums text-subtle">
              {(row.confidence * 100).toFixed(1)}%
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function IdleDecision() {
  return (
    <div className="mt-3">
      <p className="font-mono text-3xl font-medium tracking-tight text-muted">—</p>
      <p className="mt-1 text-sm text-subtle">nincs kitöltés, nincs mozgás. figyeli a szalagot.</p>
    </div>
  );
}

function CurrentDecision({ item }: { item: DecisionEvent }) {
  const blocked = item.warden === "BLOCKED";
  return (
    <div className="mt-3">
      <div className="flex items-baseline gap-3">
        <p className={cn("font-mono text-3xl font-medium tracking-tight", tone(item.decision, blocked))}>
          {blocked ? "HOLD" : item.decision}
        </p>
        <p className="font-mono text-sm tabular-nums text-muted">
          {(item.confidence * 100).toFixed(1)}%
        </p>
      </div>
      <p className="mt-1 font-mono text-sm text-fg">{item.pair}</p>
      <p className="mt-1 text-sm leading-snug text-muted">{item.rationale}</p>
      <p className={cn("mt-2 text-xs", blocked ? "text-warden" : "text-subtle")}>
        WARDEN · {blocked ? "BLOKKOLVA" : "JÓVÁHAGYVA"} — {item.wardenReason}
      </p>
    </div>
  );
}

function tone(decision: Decision, blocked: boolean) {
  if (blocked) return "text-warden";
  if (decision === "BUY" || decision === "COPY") return "text-up";
  return "text-muted";
}

function DecisionTag({ decision, blocked }: { decision: Decision; blocked: boolean }) {
  return (
    <span className={cn("font-mono text-[11px] tracking-wide", tone(decision, blocked))}>
      {blocked ? "BLOCK" : decision}
    </span>
  );
}

function TapePanel({ fills }: { fills?: FillEvent[] }) {
  const storeFills = useDeskStore((s) => s.fills);
  const rows = (fills ?? storeFills).slice(-24).reverse();

  return (
    <section className="flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]">
      <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">Szalag</p>
      <ul className="mt-3 min-h-0 flex-1 space-y-2 overflow-y-auto">
        {rows.length === 0 ? (
          <li className="text-sm text-subtle">még nincs kitöltés</li>
        ) : (
          rows.map((row) => <FillRow key={row.id} fill={row} />)
        )}
      </ul>
    </section>
  );
}

function FillRow({ fill }: { fill: FillEvent }) {
  const up = fill.pnl >= 0;
  return (
    <li className="flex items-baseline justify-between gap-2">
      <span className="min-w-0">
        <span className="block truncate font-mono text-xs text-fg">{fill.pair}</span>
        <span className="block font-mono text-[10px] text-subtle">
          {fill.latencyMs} ms · {fill.route}
        </span>
      </span>
      <span className={cn("shrink-0 font-mono text-xs tabular-nums", up ? "text-up" : "text-down")}>
        {fill.pnl === 0 ? formatUsd(fill.notional) : `${up ? "+" : ""}${formatUsd(fill.pnl)}`}
      </span>
    </li>
  );
}

function LogPanel({ logs }: { logs?: LogEvent[] }) {
  const storeLogs = useDeskStore((s) => s.logs);
  const lines = logs ?? storeLogs;
  const scroller = useRef<HTMLUListElement>(null);
  const stick = useRef(true);

  useEffect(() => {
    const el = scroller.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [lines.length]);

  return (
    <section className="flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]">
      <p className="text-xs font-medium tracking-[0.16em] uppercase text-subtle">Terminál</p>
      <ul
        ref={scroller}
        onScroll={(e) => {
          const el = e.currentTarget;
          stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
        }}
        className="mt-3 min-h-0 flex-1 space-y-1 overflow-y-auto font-mono text-[11px] leading-relaxed"
      >
        {lines.length === 0 ? (
          <li className="text-subtle">várakozás a JEV-re…</li>
        ) : (
          lines.map((line) => <LogLine key={line.id} line={line} />)
        )}
      </ul>
    </section>
  );
}

function LogLine({ line }: { line: LogEvent }) {
  return (
    <li className="flex gap-2 text-muted">
      <span className="shrink-0 tabular-nums text-subtle">{formatClock(line.t)}</span>
      <span className="w-14 shrink-0 tracking-wide text-fg">{line.agent}</span>
      <span className="min-w-0">{line.text}</span>
    </li>
  );
}
