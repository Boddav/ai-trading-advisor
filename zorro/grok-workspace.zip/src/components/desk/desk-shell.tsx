import { useEffect } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MeridianMark } from "@/components/desk/mark";
import { EquityPanel } from "@/components/desk/equity-panel";
import { AgentGrid } from "@/components/desk/agent-grid";
import { Feeds } from "@/components/desk/feeds";
import { NIGHT_MS } from "@/lib/desk/types";
import { formatClock } from "@/lib/desk/format";
import { useDeskStore } from "@/lib/desk/store";
import { useLiveStore } from "@/lib/live/store";
import { cn } from "@/lib/utils";

export function DeskShell() {
  const phase = useDeskStore((s) => s.phase);
  const simTime = useDeskStore((s) => s.simTime);
  const stats = useDeskStore((s) => s.stats);
  const prompt = useDeskStore((s) => s.prompt);
  const pause = useDeskStore((s) => s.pause);
  const resume = useDeskStore((s) => s.resume);
  const reset = useDeskStore((s) => s.reset);
  const advance = useDeskStore((s) => s.advance);
  const beginArm = useLiveStore((s) => s.beginArm);
  const setLivePrompt = useLiveStore((s) => s.setPrompt);
  const interpret = useLiveStore((s) => s.interpret);

  useEffect(() => {
    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = Math.min(now - last, 80);
      last = now;
      if (dt > 0) advance(dt);
    }, 50);
    return () => window.clearInterval(id);
  }, [advance]);

  const live = phase === "live";
  const night = simTime < NIGHT_MS;
  const winRate = stats.fills > 0 ? Math.round((stats.wins / stats.fills) * 100) : 0;

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2.5">
          <MeridianMark className="size-6" />
          <div>
            <p className="text-sm font-medium tracking-tight">Meridian Desk</p>
            <p className="font-mono text-[10px] tracking-[0.14em] uppercase text-subtle">
              papír session
            </p>
          </div>
        </div>

        <div className="ml-auto flex flex-wrap items-center gap-2 sm:gap-3">
          <span className="font-mono text-xs tabular-nums text-fg">{formatClock(simTime)}</span>
          <span className="hidden font-mono text-[10px] tracking-[0.14em] uppercase text-subtle sm:inline">
            {night ? "éj" : "reggel"}
          </span>
          <Stat label="fill" value={String(stats.fills)} />
          <Stat label="win" value={stats.fills ? `${winRate}%` : "—"} />
          <span className="flex items-center gap-1.5 pl-1">
            <span
              className={cn("size-1.5 rounded-full bg-live", live && "live-dot")}
              aria-hidden
            />
            <span className="font-mono text-[10px] tracking-[0.14em] uppercase text-muted">
              {live ? "élő" : "szünet"}
            </span>
          </span>
          <Button
            variant="ghost"
            className="h-11 px-3 text-xs"
            onClick={() => {
              setLivePrompt(prompt);
              beginArm();
              void interpret();
            }}
          >
            Éles tőke
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={live ? "Szünet" : "Folytatás"}
            onClick={() => (live ? pause() : resume())}
          >
            {live ? <Pause className="size-4" /> : <Play className="size-4" />}
          </Button>
          <Button variant="quiet" size="icon" aria-label="Új session" onClick={reset}>
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </header>

      <p className="truncate border-b border-border px-4 py-2 font-mono text-[11px] text-muted sm:px-5">
        <span className="text-subtle">{">"}</span> {prompt}
      </p>

      <main className="mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-3 p-3 sm:p-4">
        <div className="grid grid-cols-1 gap-3 xl:grid-cols-5 xl:items-stretch">
          <div className="xl:col-span-2">
            <EquityPanel />
          </div>
          <div className="flex min-h-0 flex-col xl:col-span-3">
            <Feeds />
          </div>
        </div>
        <AgentGrid />
        <p className="pb-2 text-center text-[11px] text-subtle">
          Szimulált papír-session. Nem valós kereskedés, nem pénzügyi tanácsadás.
        </p>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="hidden items-baseline gap-1.5 sm:flex">
      <span className="text-[10px] tracking-[0.14em] uppercase text-subtle">{label}</span>
      <span className="font-mono text-xs tabular-nums text-fg">{value}</span>
    </div>
  );
}