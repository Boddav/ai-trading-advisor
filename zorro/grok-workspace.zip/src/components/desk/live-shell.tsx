import { useEffect, useRef } from "react";
import { Pause, Play, RotateCcw, ShieldOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AgentGrid } from "@/components/desk/agent-grid";
import { EquityPanel } from "@/components/desk/equity-panel";
import { Feeds } from "@/components/desk/feeds";
import { MeridianMark } from "@/components/desk/mark";
import { TicketCard } from "@/components/desk/ticket-card";
import { formatClock } from "@/lib/desk/format";
import { CYCLE_MS } from "@/lib/live/types";
import { useLiveStore } from "@/lib/live/store";
import { cn } from "@/lib/utils";

export function LiveShell() {
  const phase = useLiveStore((s) => s.phase);
  const clockMs = useLiveStore((s) => s.clockMs);
  const stats = useLiveStore((s) => s.stats);
  const prompt = useLiveStore((s) => s.prompt);
  const pubkey = useLiveStore((s) => s.pubkey);
  const walletName = useLiveStore((s) => s.walletName);
  const ticket = useLiveStore((s) => s.ticket);
  const busy = useLiveStore((s) => s.busy);
  const error = useLiveStore((s) => s.error);
  const pause = useLiveStore((s) => s.pause);
  const resume = useLiveStore((s) => s.resume);
  const reset = useLiveStore((s) => s.reset);
  const kill = useLiveStore((s) => s.kill);
  const decay = useLiveStore((s) => s.decay);
  const tickClock = useLiveStore((s) => s.tickClock);
  const cycle = useLiveStore((s) => s.cycle);
  const signTicket = useLiveStore((s) => s.signTicket);
  const dismissTicket = useLiveStore((s) => s.dismissTicket);
  const agents = useLiveStore((s) => s.agents);
  const displayEquity = useLiveStore((s) => s.displayEquity);
  const equity = useLiveStore((s) => s.equity);
  const startEquity = useLiveStore((s) => s.startEquity);
  const points = useLiveStore((s) => s.points);
  const currentDecision = useLiveStore((s) => s.currentDecision);
  const decisions = useLiveStore((s) => s.decisions);
  const fills = useLiveStore((s) => s.fills);
  const logs = useLiveStore((s) => s.logs);

  const live = phase === "live";
  const cycling = useRef(false);

  useEffect(() => {
    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = Math.min(now - last, 80);
      last = now;
      tickClock();
      if (dt > 0) decay(dt);
    }, 50);
    return () => window.clearInterval(id);
  }, [decay, tickClock]);

  useEffect(() => {
    if (!live) return;
    let stopped = false;
    const run = async () => {
      if (stopped || cycling.current) return;
      cycling.current = true;
      try {
        await cycle();
      } finally {
        cycling.current = false;
      }
    };
    void run();
    const id = window.setInterval(() => {
      void run();
    }, CYCLE_MS);
    return () => {
      stopped = true;
      window.clearInterval(id);
    };
  }, [live, cycle]);

  const winRate = stats.fills > 0 ? Math.round((stats.wins / stats.fills) * 100) : 0;
  const showTicket = ticket && ticket.status !== "sent";

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-3 sm:px-5">
        <div className="flex items-center gap-2.5">
          <MeridianMark className="size-6" />
          <div>
            <p className="text-sm font-medium tracking-tight">Meridian Desk</p>
            <p className="font-mono text-[10px] tracking-[0.14em] uppercase text-warden">éles tőke</p>
          </div>
        </div>
        <div className="ml-auto flex flex-wrap items-center gap-2 sm:gap-3">
          <span className="font-mono text-xs tabular-nums text-fg">{formatClock(clockMs)}</span>
          {pubkey ? (
            <span className="hidden font-mono text-[10px] tracking-[0.14em] uppercase text-subtle sm:inline">
              {walletName} {pubkey.slice(0, 4)}…{pubkey.slice(-4)}
            </span>
          ) : null}
          <Stat label="fill" value={String(stats.fills)} />
          <Stat label="win" value={stats.fills ? `${winRate}%` : "—"} />
          <span className="flex items-center gap-1.5 pl-1">
            <span
              className={cn("size-1.5 rounded-full", live ? "bg-live live-dot" : "bg-warden")}
              aria-hidden
            />
            <span className="font-mono text-[10px] tracking-[0.14em] uppercase text-muted">
              {phase === "killed" ? "zárva" : live ? "éles" : "szünet"}
            </span>
          </span>
          <Button
            variant="ghost"
            size="icon"
            aria-label={live ? "Szünet" : "Folytatás"}
            disabled={phase === "killed"}
            onClick={() => (live ? pause() : resume())}
          >
            {live ? <Pause className="size-4" /> : <Play className="size-4" />}
          </Button>
          <Button variant="quiet" size="icon" aria-label="Kill switch" onClick={kill}>
            <ShieldOff className="size-4" />
          </Button>
          <Button variant="quiet" size="icon" aria-label="Kilépés" onClick={reset}>
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </header>

      <p className="truncate border-b border-border px-4 py-2 font-mono text-[11px] text-muted sm:px-5">
        <span className="text-subtle">{">"}</span> {prompt}
      </p>

      <main className="mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-3 p-3 sm:p-4">
        {showTicket ? (
          <TicketCard
            ticket={ticket}
            busy={busy}
            onSign={() => void signTicket()}
            onDismiss={dismissTicket}
          />
        ) : null}
        {error && !showTicket ? <p className="text-sm text-down">{error}</p> : null}
        <div className="grid grid-cols-1 gap-3 xl:grid-cols-5 xl:items-stretch">
          <div className="xl:col-span-2">
            <EquityPanel
              startEquity={startEquity}
              display={displayEquity}
              equity={equity}
              points={points}
            />
          </div>
          <div className="flex min-h-0 flex-col xl:col-span-3">
            <Feeds
              current={currentDecision}
              decisions={decisions}
              fills={fills}
              logs={logs}
            />
          </div>
        </div>
        <AgentGrid agents={agents} stats={stats} />
        <p className="pb-2 text-center text-[11px] text-subtle">
          Éles Solana-session. Jupiter-swap, tárca-aláírás. Nem pénzügyi tanács. A tőke elveszhet.
        </p>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="hidden items-baseline gap-1.5 sm:flex">
      <span className="text-[10px] tracking-[0.14em] uppercase text-subtle">{label}</span>
      <span className="font-mono text-xs tabular-nums text-fg">{value}</span>
    </div>
  );
}
