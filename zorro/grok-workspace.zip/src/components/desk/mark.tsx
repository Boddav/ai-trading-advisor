import { cn } from "@/lib/utils";

export function MeridianMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-fg", className)}
      fill="none"
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="12.25" stroke="currentColor" strokeWidth="1.4" />
      <path d="M16 3.2v25.6" stroke="currentColor" strokeWidth="1.4" />
      <path d="M6.2 16h19.6" stroke="currentColor" strokeWidth="1" opacity="0.45" />
      <circle cx="16" cy="16" r="1.7" fill="currentColor" />
    </svg>
  );
}
