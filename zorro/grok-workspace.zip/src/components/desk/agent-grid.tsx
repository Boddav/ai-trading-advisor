import { Radar, Wallet, Activity, Spline, Shield } from "lucide-react";
import { AGENT_META, CREW, type AgentId, type AgentState, type Stats } from "@/lib/desk/types";
import { useDeskStore } from "@/lib/desk/store";
import { cn } from "@/lib/utils";

const ICONS: Record<Exclude<AgentId, "JEV" | "WARDEN">, typeof Radar> = {
  SCOUT: Radar,
  LEDGER: Wallet,
  PULSE: Activity,
  FLUX: Spline,
};

const STATUS_LABEL: Record<AgentState["status"], string> = {
  idle: "vár",
  scanning: "figyel",
  flagged: "jelez",
  confirming: "erősít",
  routing: "útvonal",
  approved: "enged",
  blocking: "fogja",
};

export function AgentGrid({
  agents,
  stats,
}: {
  agents?: Record<AgentId, AgentState>;
  stats?: Stats;
} = {}) {
  const storeAgents = useDeskStore((s) => s.agents);
  const storeStats = useDeskStore((s) => s.stats);
  const map = agents ?? storeAgents;
  const st = stats ?? storeStats;

  return (
    <div className="flex flex-col gap-2">
      <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
        {CREW.map((id) => (map[id] ? <AgentCard key={id} agent={map[id]} /> : null))}
      </div>
      {map.WARDEN ? <WardenBar agent={map.WARDEN} blocks={st.blocks} /> : null}
    </div>
  );
}

function AgentCard({ agent }: { agent: AgentState }) {
  const meta = AGENT_META[agent.id];
  const Icon = ICONS[agent.id as Exclude<AgentId, "JEV" | "WARDEN">];
  const live = agent.heat > 0.18 && agent.status !== "idle";

  return (
    <article className="flex flex-col rounded-xl bg-surface p-3 shadow-[0_0_0_1px_var(--color-border)]">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className="size-3.5 text-muted" strokeWidth={1.75} />
          <h3 className="font-mono text-[11px] tracking-[0.14em] text-fg">{meta.name}</h3>
        </div>
        <span
          className={cn(
            "font-mono text-[10px] tracking-wide uppercase",
            live ? "text-fg" : "text-subtle",
          )}
        >
          {STATUS_LABEL[agent.status]}
        </span>
      </div>
      <p className="mt-2 line-clamp-2 min-h-9 text-xs leading-snug text-muted">
        {agent.note || meta.blurb}
      </p>
      <div className="mt-3 h-0.5 overflow-hidden rounded-full bg-elevated">
        <div
          className="h-full origin-left bg-accent transition-transform duration-150 ease-out"
          style={{ transform: `scaleX(${Math.max(agent.heat, 0.06)})` }}
        />
      </div>
    </article>
  );
}

function WardenBar({ agent, blocks }: { agent: AgentState; blocks: number }) {
  const blocking = agent.status === "blocking";
  const approved = agent.status === "approved";
  return (
    <article
      className={cn(
        "flex flex-col gap-2 rounded-xl bg-surface px-4 py-3 shadow-[0_0_0_1px_var(--color-border)] sm:flex-row sm:items-center sm:justify-between",
        blocking && "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-warden)_45%,transparent)]",
      )}
    >
      <div className="flex min-w-0 items-center gap-3">
        <Shield className="size-4 shrink-0 text-warden" strokeWidth={1.75} />
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <h3 className="font-mono text-[11px] tracking-[0.14em] text-fg">WARDEN</h3>
            <span
              className={cn(
                "font-mono text-[10px] uppercase",
                blocking ? "text-warden" : approved ? "text-up" : "text-subtle",
              )}
            >
              {STATUS_LABEL[agent.status]}
            </span>
          </div>
          <p className="truncate text-xs text-muted">
            {agent.note || "semmi sem hajtódik végre jóváhagyás nélkül"}
          </p>
        </div>
      </div>
      <p className="shrink-0 font-mono text-[11px] tabular-nums tracking-wide text-subtle">
        {blocks} blokk
      </p>
    </article>
  );
}
