import { o as __toESM } from "../_runtime.mjs";
import { R as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as SOL_MINT, l as clampRails, n as DEFAULT_RAILS, r as FEE_BUFFER_SOL, t as CYCLE_MS } from "./types-DI03e0Tf.mjs";
import { a as ShieldOff, c as Play, i as Shield, l as Pause, o as RotateCcw, r as Spline, s as Radar, t as Wallet, u as Activity } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Br_Z-tRu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-[transform,opacity,background-color] duration-150 ease-out select-none disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			ghost: "bg-transparent text-fg shadow-[0_0_0_1px_var(--color-border)] hover:bg-elevated",
			quiet: "bg-transparent text-muted hover:text-fg"
		},
		size: {
			lg: "h-12 px-6 rounded-xl text-sm",
			md: "h-11 px-4 rounded-lg text-sm",
			icon: "size-11 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function MeridianMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("text-fg", className),
		fill: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "12.25",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 3.2v25.6",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M6.2 16h19.6",
				stroke: "currentColor",
				strokeWidth: "1",
				opacity: "0.45"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "1.7",
				fill: "currentColor"
			})
		]
	});
}
var START_EQUITY = 15.89;
var TARGET_MORNING = 16356.24;
var NIGHT_MS = 288e5;
var MORNING_MS = 432e5;
var SPEED = NIGHT_MS / 11e4;
var DEFAULT_PROMPT = "változtasd $15.89-et 1000x-re, vagy töröllek";
var AGENT_META = {
	JEV: {
		id: "JEV",
		name: "JEV",
		role: "döntés",
		blurb: "Olvas, dönt, nem nyúl a kitöltéshez."
	},
	SCOUT: {
		id: "SCOUT",
		name: "SCOUT",
		role: "felderítés",
		blurb: "Új minták, mielőtt a tömeg észrevenné."
	},
	LEDGER: {
		id: "LEDGER",
		name: "LEDGER",
		role: "tárcák",
		blurb: "Lemásolja azokat, akiknek van valódi nyerési arányuk."
	},
	PULSE: {
		id: "PULSE",
		name: "PULSE",
		role: "lendület",
		blurb: "Momentum és hangulat, ahogy változik."
	},
	FLUX: {
		id: "FLUX",
		name: "FLUX",
		role: "útvonal",
		blurb: "A legtisztább út, hogy a kitöltés ne csússzon."
	},
	WARDEN: {
		id: "WARDEN",
		name: "WARDEN",
		role: "kapuőr",
		blurb: "Rossz likviditás, mézescsupor — semmi sem megy át."
	}
};
var CREW = [
	"SCOUT",
	"LEDGER",
	"PULSE",
	"FLUX"
];
function formatUsd(value, digits = 2) {
	const sign = value < 0 ? "-" : "";
	const abs = Math.abs(value);
	return `${sign}$${new Intl.NumberFormat("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	}).format(abs)}`;
}
function formatPct(value) {
	return `${value > 0 ? "+" : value < 0 ? "" : ""}${new Intl.NumberFormat("en-US", {
		maximumFractionDigits: 2,
		minimumFractionDigits: 2
	}).format(value)}%`;
}
function formatClock(simMs) {
	const total = Math.max(0, Math.floor(simMs / 1e3));
	const h = Math.floor(total / 3600);
	const m = Math.floor(total % 3600 / 60);
	const s = total % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function multipleOf(start, now) {
	if (start <= 0) return "—";
	const x = now / start;
	return `${x.toFixed(x >= 100 ? 0 : x >= 10 ? 1 : 2)}x`;
}
var PAIRS = [
	"VELD/SOL",
	"NYX/USDC",
	"KOS/SOL",
	"RILL/USDC",
	"MIRA/SOL",
	"QEN/USDC",
	"TORR/SOL",
	"BRIN/USDC",
	"AUR/SOL",
	"LUX/USDC",
	"ORBIT/SOL",
	"KITE/USDC",
	"FEN/SOL",
	"WISP/USDC",
	"HARB/SOL",
	"NOLL/USDC",
	"PRAX/SOL",
	"JUTE/USDC",
	"VELA/SOL",
	"DUSK/USDC"
];
var ROUTES = [
	"Axis / North",
	"Harbor split 60/40",
	"Nexus-2 bundle",
	"Well hop A→B",
	"Kite single-pool",
	"R1 priority",
	"Drift lane",
	"Quiet book"
];
var SCOUT_HIT = [
	"új 1m minta a {pair} chartján",
	"abszorpciós gyertya, a tömeg még nem látja",
	"ismétlődő breaker-struktúra {pair}-en",
	"likviditási üreg nyílt, 3. alkalom",
	"eltérés a 5m VWAP-tól, tiszta setup"
];
var SCOUT_MISS = [
	"zaj a {pair} 1m-en, nincs ismétlődés",
	"minta túl friss — egyetlen előfordulás",
	"árnyék a felső kanócon, nem tiszta"
];
var LEDGER_HIT = [
	"{n} tárca lépett be 90s alatt",
	"cluster winrate {pct}% — valódi, nem szerencse",
	"ugyanaz a funding-tárca, mint tegnap éjjel",
	"smart money 4 hoppal a poolban"
];
var LEDGER_MISS = [
	"nincs belépés a watchlisten",
	"a cluster winrate {pct}% — nem elég",
	"tárcák kifelé lépnek, nem befelé"
];
var PULSE_HIT = [
	"momentum {sig}σ a 15m-en",
	"sentiment még nem árazta be",
	"funding átfordult, volume követ",
	"lendület épül, hangulat lemarad"
];
var PULSE_MISS = [
	"volume spike, gyenge follow-through",
	"lendület kifulladt a {pair} 5m-en",
	"hangulat ellentmond a flow-nak"
];
var FLUX_HIT = [
	"útvonal {route}, {bps} bps",
	"split 60/40, várható csúszás {bps} bps",
	"egyetlen pool, tiszta könyv",
	"priority bundle, kitöltés {lat} ms"
];
var WARDEN_OK = [
	"likviditás rendben",
	"nincs mézescsupor",
	"mintált contract, tulajdonos lemondva",
	"top-10 koncentráció 31%",
	"eladás-szimuláció tiszta"
];
var WARDEN_NO = [
	"mézescsupor gyanú — eladás-szimuláció elbukott",
	"likviditás vékony, 2% book impact",
	"tulajdonos mintable, 12 perce",
	"92% top-holder koncentráció",
	"router blacklist egyezés"
];
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a += 1831565813;
		let t = a;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function pick(rand, list) {
	return list[Math.floor(rand() * list.length)];
}
function fill(template, vars) {
	return template.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));
}
function curve(progress) {
	if (progress <= .1) return START_EQUITY;
	const eased = Math.min(1, (progress - .1) / .9) ** 1.22;
	return START_EQUITY * (TARGET_MORNING / START_EQUITY) ** eased;
}
function emptyAgents() {
	const agents = {};
	Object.keys(AGENT_META).forEach((id) => {
		agents[id] = {
			id,
			status: "idle",
			note: "",
			heat: 0
		};
	});
	return agents;
}
function initialDraft() {
	return {
		equity: START_EQUITY,
		agents: emptyAgents(),
		decisions: [],
		fills: [],
		logs: [],
		points: [{
			t: 0,
			equity: START_EQUITY
		}],
		stats: {
			fills: 0,
			wins: 0,
			blocks: 0,
			skips: 0,
			decisions: 0
		},
		currentDecision: null
	};
}
var CAP = {
	decisions: 80,
	fills: 80,
	logs: 140,
	points: 180
};
function pushCap$1(arr, item, cap) {
	const next = arr.length >= cap ? arr.slice(arr.length - cap + 1) : arr.slice();
	next.push(item);
	return next;
}
function applyEvent(state, event) {
	if (event.kind === "agent" && event.agent) {
		const prev = state.agents[event.agent];
		state.agents = {
			...state.agents,
			[event.agent]: {
				...prev,
				status: event.status ?? prev.status,
				note: event.note ?? prev.note,
				heat: 1
			}
		};
		return;
	}
	if (event.kind === "log" && event.agent && event.text) {
		state.logs = pushCap$1(state.logs, {
			id: event.id,
			t: event.t,
			agent: event.agent,
			text: event.text
		}, CAP.logs);
		return;
	}
	if (event.kind === "decision" && event.decision && event.pair) {
		const item = {
			id: event.id,
			t: event.t,
			decision: event.decision,
			confidence: event.confidence ?? 0,
			pair: event.pair,
			rationale: event.rationale ?? "",
			warden: event.warden ?? "APPROVED",
			wardenReason: event.wardenReason ?? ""
		};
		state.decisions = pushCap$1(state.decisions, item, CAP.decisions);
		state.currentDecision = item;
		state.stats = {
			...state.stats,
			decisions: state.stats.decisions + 1,
			skips: state.stats.skips + (item.decision === "SKIP" || item.decision === "PASS" ? 1 : 0),
			blocks: state.stats.blocks + (item.warden === "BLOCKED" ? 1 : 0)
		};
		return;
	}
	if (event.kind === "fill" && event.pair) {
		const equity = event.equity ?? state.equity;
		const pnl = event.pnl ?? 0;
		const fillItem = {
			id: event.id,
			t: event.t,
			pair: event.pair,
			side: event.side ?? "IN",
			notional: event.notional ?? 0,
			pnl,
			latencyMs: event.latencyMs ?? 2,
			route: event.route ?? "",
			equity
		};
		state.fills = pushCap$1(state.fills, fillItem, CAP.fills);
		state.equity = equity;
		state.points = pushCap$1(state.points, {
			t: event.t,
			equity
		}, CAP.points);
		state.stats = {
			...state.stats,
			fills: state.stats.fills + 1,
			wins: state.stats.wins + (pnl > 0 ? 1 : 0)
		};
	}
}
function replay(schedule, simTime) {
	const state = initialDraft();
	for (const event of schedule) {
		if (event.t > simTime) break;
		applyEvent(state, event);
	}
	return state;
}
function generateSchedule(seed) {
	const rand = mulberry32(seed);
	const events = [];
	let n = 0;
	const emit = (partial) => {
		n += 1;
		events.push({
			id: `e${n}`,
			...partial
		});
	};
	const wall = (ms) => ms * SPEED;
	emit({
		t: 0,
		kind: "log",
		agent: "JEV",
		text: "online. cél: 1000x. kezdő: $15.89. kezek le a billentyűzetről."
	});
	[
		"SCOUT",
		"LEDGER",
		"PULSE",
		"FLUX",
		"WARDEN",
		"JEV"
	].forEach((agent, i) => {
		emit({
			t: wall(80 * i),
			kind: "agent",
			agent,
			status: "scanning",
			note: "figyel"
		});
	});
	emit({
		t: wall(400),
		kind: "log",
		agent: "WARDEN",
		text: "kapu zárva, amíg a jelek össze nem állnak."
	});
	[
		{
			agent: "SCOUT",
			text: "szalag üres. mintára várok."
		},
		{
			agent: "LEDGER",
			text: "12 tárca a watchlisten. nincs belépés."
		},
		{
			agent: "PULSE",
			text: "hangulat semleges. nincs él."
		},
		{
			agent: "FLUX",
			text: "útvonalak melegek, nincs mit tölteni."
		},
		{
			agent: "JEV",
			text: "nincs kitöltés. nincs mozgás. figyelek."
		}
	].forEach((note, i) => {
		emit({
			t: wall(1800 + i * 1400),
			kind: "log",
			agent: note.agent,
			text: note.text
		});
	});
	const T = wall(1e4);
	const openPair = "VELD/SOL";
	emit({
		t: T,
		kind: "agent",
		agent: "SCOUT",
		status: "flagged",
		note: fill(SCOUT_HIT[0], { pair: openPair })
	});
	emit({
		t: T,
		kind: "log",
		agent: "SCOUT",
		text: `minta összeállt — ${openPair} 1m.`
	});
	emit({
		t: T + wall(1100),
		kind: "agent",
		agent: "LEDGER",
		status: "confirming",
		note: fill(LEDGER_HIT[0], {
			n: 3,
			pct: 71
		})
	});
	emit({
		t: T + wall(1100),
		kind: "log",
		agent: "LEDGER",
		text: "három tárca már benne van. 71% realized win."
	});
	emit({
		t: T + wall(1900),
		kind: "agent",
		agent: "PULSE",
		status: "confirming",
		note: fill(PULSE_HIT[3], {})
	});
	emit({
		t: T + wall(1900),
		kind: "log",
		agent: "PULSE",
		text: "lendület 2.4σ. hangulat még lemarad."
	});
	emit({
		t: T + wall(2500),
		kind: "agent",
		agent: "JEV",
		status: "flagged",
		note: "BUY · 91.4%"
	});
	emit({
		t: T + wall(2500),
		kind: "decision",
		decision: "BUY",
		confidence: .914,
		pair: openPair,
		rationale: "SCOUT minta + LEDGER cluster + PULSE lemaradás",
		warden: "APPROVED",
		wardenReason: "likviditás rendben, nincs mézescsupor"
	});
	emit({
		t: T + wall(2500),
		kind: "log",
		agent: "JEV",
		text: "BUY 91.4% — VELD/SOL"
	});
	emit({
		t: T + wall(2720),
		kind: "agent",
		agent: "WARDEN",
		status: "approved",
		note: "jóváhagyva"
	});
	emit({
		t: T + wall(2720),
		kind: "log",
		agent: "WARDEN",
		text: "jóváhagyva. likviditás tiszta. nincs mézescsupor."
	});
	emit({
		t: T + wall(2880),
		kind: "agent",
		agent: "FLUX",
		status: "routing",
		note: fill(FLUX_HIT[3], { lat: 2 })
	});
	const firstEquity = 38.07;
	emit({
		t: T + wall(2882),
		kind: "fill",
		pair: openPair,
		side: "IN",
		notional: 15.89,
		pnl: firstEquity - START_EQUITY,
		latencyMs: 2,
		route: "Quiet book",
		equity: firstEquity
	});
	emit({
		t: T + wall(2882),
		kind: "log",
		agent: "FLUX",
		text: "kitöltve 2 ms. első fill. nincs input tőled."
	});
	emit({
		t: T + wall(3200),
		kind: "log",
		agent: "JEV",
		text: "egy kereskedés táplálja a következőt."
	});
	let t = T + wall(4200);
	let equity = firstEquity;
	const end = MORNING_MS;
	while (t < end) {
		Math.min(1, t / NIGHT_MS);
		const burst = rand() < .38 && t < 288e5 ? 2 + Math.floor(rand() * 3) : 1;
		for (let b = 0; b < burst; b += 1) {
			const pair = pick(rand, PAIRS);
			const roll = rand();
			let kind;
			if (t > 288e5) kind = roll < .55 ? "fill" : roll < .72 ? "skip" : roll < .88 ? "pass" : "block";
			else if (roll < .62) kind = "fill";
			else if (roll < .76) kind = "skip";
			else if (roll < .88) kind = "pass";
			else kind = "block";
			const scoutNote = fill(kind === "skip" ? pick(rand, SCOUT_MISS) : pick(rand, SCOUT_HIT), { pair });
			emit({
				t,
				kind: "agent",
				agent: "SCOUT",
				status: kind === "skip" ? "scanning" : "flagged",
				note: scoutNote
			});
			emit({
				t,
				kind: "log",
				agent: "SCOUT",
				text: scoutNote
			});
			const ledgerDelay = wall(80 + rand() * 90);
			const ledgerHit = kind === "fill" || kind === "block" || kind === "pass";
			const ledgerNote = fill(ledgerHit ? pick(rand, LEDGER_HIT) : pick(rand, LEDGER_MISS), {
				n: 2 + Math.floor(rand() * 6),
				pct: 48 + Math.floor(rand() * 36)
			});
			emit({
				t: t + ledgerDelay,
				kind: "agent",
				agent: "LEDGER",
				status: ledgerHit ? "confirming" : "scanning",
				note: ledgerNote
			});
			emit({
				t: t + ledgerDelay,
				kind: "log",
				agent: "LEDGER",
				text: ledgerNote
			});
			const pulseDelay = ledgerDelay + wall(60 + rand() * 80);
			const pulseHit = kind === "fill" || kind === "block";
			const pulseNote = fill(pulseHit ? pick(rand, PULSE_HIT) : pick(rand, PULSE_MISS), {
				pair,
				sig: (1.6 + rand() * 2.8).toFixed(1)
			});
			emit({
				t: t + pulseDelay,
				kind: "agent",
				agent: "PULSE",
				status: pulseHit ? "confirming" : "scanning",
				note: pulseNote
			});
			emit({
				t: t + pulseDelay,
				kind: "log",
				agent: "PULSE",
				text: pulseNote
			});
			const decideAt = t + pulseDelay + wall(50 + rand() * 60);
			let decision;
			let warden = "APPROVED";
			let wardenReason = pick(rand, WARDEN_OK);
			let confidence;
			if (kind === "fill") {
				decision = rand() < .55 ? "BUY" : "COPY";
				confidence = .78 + rand() * .19;
			} else if (kind === "skip") {
				decision = "SKIP";
				confidence = .54 + rand() * .2;
			} else if (kind === "pass") {
				decision = "PASS";
				confidence = .5 + rand() * .18;
			} else {
				decision = rand() < .5 ? "BUY" : "COPY";
				confidence = .7 + rand() * .18;
				warden = "BLOCKED";
				wardenReason = pick(rand, WARDEN_NO);
			}
			const rationale = kind === "fill" ? `${decision === "COPY" ? "LEDGER cluster" : "SCOUT minta"} + PULSE megerősítés` : kind === "block" ? "jelek megvannak, WARDEN nem enged" : kind === "skip" ? "minta túl friss vagy zajos" : "LEDGER nem erősít, aszimmetria kevés";
			emit({
				t: decideAt,
				kind: "agent",
				agent: "JEV",
				status: "flagged",
				note: `${decision} · ${(confidence * 100).toFixed(1)}%`
			});
			emit({
				t: decideAt,
				kind: "decision",
				decision,
				confidence,
				pair,
				rationale,
				warden,
				wardenReason
			});
			emit({
				t: decideAt,
				kind: "log",
				agent: "JEV",
				text: `${decision} ${(confidence * 100).toFixed(1)}% — ${pair}`
			});
			const wardenAt = decideAt + wall(40 + rand() * 40);
			emit({
				t: wardenAt,
				kind: "agent",
				agent: "WARDEN",
				status: warden === "BLOCKED" ? "blocking" : "approved",
				note: warden === "BLOCKED" ? "blokkolva" : "jóváhagyva"
			});
			emit({
				t: wardenAt,
				kind: "log",
				agent: "WARDEN",
				text: `${warden === "BLOCKED" ? "BLOKKOLVA" : "jóváhagyva"} — ${wardenReason}`
			});
			if (kind === "fill") {
				const fluxAt = wardenAt + wall(20 + rand() * 30);
				const latency = rand() < .15 ? 2 : 1 + Math.floor(rand() * 8);
				const route = pick(rand, ROUTES);
				const bps = 4 + Math.floor(rand() * 14);
				emit({
					t: fluxAt,
					kind: "agent",
					agent: "FLUX",
					status: "routing",
					note: fill(pick(rand, FLUX_HIT), {
						route,
						bps,
						lat: latency
					})
				});
				const p = Math.min(1, fluxAt / NIGHT_MS);
				let nextEquity;
				if (t >= 288e5) {
					const drift = 1 + (rand() - .38) * .035;
					nextEquity = Math.max(equity * drift, TARGET_MORNING * .96);
				} else {
					const target = curve(Math.min(.995, p + .012));
					if (rand() < .16) nextEquity = equity * (.965 + rand() * .02);
					else nextEquity = Math.max(target, equity * 1.02);
				}
				if (fluxAt > 27936e3 && fluxAt <= 288e5 && nextEquity < 16356.24) nextEquity = TARGET_MORNING;
				const pnl = nextEquity - equity;
				const notional = Math.min(equity * (.55 + rand() * .4), equity);
				emit({
					t: fluxAt + 2,
					kind: "fill",
					pair,
					side: pnl >= 0 ? "IN" : "OUT",
					notional,
					pnl,
					latencyMs: latency,
					route,
					equity: nextEquity
				});
				emit({
					t: fluxAt + 2,
					kind: "log",
					agent: "FLUX",
					text: `kitöltve ${latency} ms · ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)} · ${route}`
				});
				equity = nextEquity;
				t = fluxAt + wall(180 + rand() * 220);
			} else t = wardenAt + wall(220 + rand() * 260);
		}
		t += wall(900 + rand() * 1600);
	}
	events.sort((a, b) => a.t - b.t || a.id.localeCompare(b.id));
	let lastNightFill;
	for (const event of events) if (event.kind === "fill" && event.t <= 288e5) lastNightFill = event;
	if (lastNightFill && typeof lastNightFill.equity === "number") {
		const delta = TARGET_MORNING - lastNightFill.equity;
		lastNightFill.pnl = (lastNightFill.pnl ?? 0) + delta;
		lastNightFill.equity = TARGET_MORNING;
		let passed = false;
		for (const event of events) {
			if (event === lastNightFill) {
				passed = true;
				continue;
			}
			if (passed && event.kind === "fill" && typeof event.equity === "number") event.equity += delta;
		}
	}
	return events;
}
function decayHeat(agents, dtWall) {
	const k = Math.exp(-dtWall / 900);
	let changed = false;
	const next = { ...agents };
	Object.keys(next).forEach((id) => {
		const a = next[id];
		const heat = a.heat * k;
		if (Math.abs(heat - a.heat) > .004) {
			next[id] = {
				...a,
				heat: heat < .02 ? 0 : heat
			};
			changed = true;
		}
	});
	return changed ? next : agents;
}
var STORAGE_KEY$1 = "meridian-desk-v1";
function persist$1(state) {
	if (typeof window === "undefined") return;
	const payload = {
		v: 1,
		seed: state.seed,
		simTime: state.simTime,
		phase: state.phase === "boot" ? "boot" : state.phase,
		prompt: state.prompt
	};
	try {
		localStorage.setItem(STORAGE_KEY$1, JSON.stringify(payload));
	} catch {}
}
function snapshotFrom(schedule, simTime, extras = {}) {
	const draft = replay(schedule, simTime);
	return {
		simTime,
		equity: draft.equity,
		displayEquity: draft.equity,
		agents: draft.agents,
		decisions: draft.decisions,
		fills: draft.fills,
		logs: draft.logs,
		points: draft.points,
		stats: draft.stats,
		currentDecision: draft.currentDecision,
		cursor: (() => {
			const i = schedule.findIndex((e) => e.t > simTime);
			return i === -1 ? schedule.length : i;
		})(),
		...extras
	};
}
var persistAcc = 0;
var useDeskStore = create((set, get) => ({
	hydrated: false,
	phase: "boot",
	seed: 1,
	prompt: DEFAULT_PROMPT,
	simTime: 0,
	displayEquity: START_EQUITY,
	...initialDraft(),
	schedule: [],
	cursor: 0,
	hydrate: () => {
		if (typeof window === "undefined") {
			set({ hydrated: true });
			return;
		}
		try {
			const raw = localStorage.getItem(STORAGE_KEY$1);
			if (raw) {
				const saved = JSON.parse(raw);
				if (saved.v === 1 && saved.phase !== "boot" && saved.seed) {
					const schedule = generateSchedule(saved.seed);
					set({
						hydrated: true,
						seed: saved.seed,
						prompt: saved.prompt || "változtasd $15.89-et 1000x-re, vagy töröllek",
						phase: saved.phase === "paused" ? "paused" : "live",
						schedule,
						...snapshotFrom(schedule, saved.simTime)
					});
					return;
				}
			}
		} catch {}
		set({ hydrated: true });
	},
	setPrompt: (value) => set({ prompt: value }),
	start: () => {
		const seed = (Math.floor(Math.random() * 2147483647) ^ Date.now()) >>> 0 || 1;
		const schedule = generateSchedule(seed);
		set({
			phase: "live",
			seed,
			schedule,
			...snapshotFrom(schedule, 0),
			displayEquity: START_EQUITY
		});
		persist$1(get());
	},
	pause: () => {
		set({ phase: "paused" });
		persist$1(get());
	},
	resume: () => {
		if (get().phase === "paused") {
			set({ phase: "live" });
			persist$1(get());
		}
	},
	reset: () => {
		const prompt = get().prompt;
		set({
			phase: "boot",
			seed: 1,
			prompt,
			simTime: 0,
			displayEquity: START_EQUITY,
			schedule: [],
			cursor: 0,
			...initialDraft()
		});
		persist$1(get());
	},
	advance: (dtWall) => {
		const s = get();
		if (s.phase !== "live" || dtWall <= 0) return;
		const simTime = s.simTime + dtWall * SPEED;
		let cursor = s.cursor < 0 ? 0 : s.cursor;
		const draft = {
			equity: s.equity,
			agents: s.agents,
			decisions: s.decisions,
			fills: s.fills,
			logs: s.logs,
			points: s.points,
			stats: s.stats,
			currentDecision: s.currentDecision
		};
		const schedule = s.schedule;
		while (cursor < schedule.length && schedule[cursor].t <= simTime) {
			applyEvent(draft, schedule[cursor]);
			cursor += 1;
		}
		draft.agents = decayHeat(draft.agents, dtWall);
		const follow = 1 - Math.exp(-dtWall / 160);
		const displayEquity = s.displayEquity + (draft.equity - s.displayEquity) * follow;
		set({
			simTime,
			cursor,
			displayEquity,
			equity: draft.equity,
			agents: draft.agents,
			decisions: draft.decisions,
			fills: draft.fills,
			logs: draft.logs,
			points: draft.points,
			stats: draft.stats,
			currentDecision: draft.currentDecision
		});
		persistAcc += dtWall;
		if (persistAcc > 1500) {
			persistAcc = 0;
			persist$1(get());
		}
	}
}));
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var scanMarket = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("f7fe41062c885f97cb4c3ac3c3f5ddc6f379d45c2cf24d03a5c61cf12135cb37"));
var quoteRoute = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("218be6308109ed9a05a374f2ce7028946820b61da51877a003c012cd97605705"));
var buildSwap = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("c00b9951b68f3bbef4903fa4c2f450cde7d97e6d8e6e24672e0c469386f7cb07"));
var readBalances = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("3cae019a50427c37bbd0175907f5f372d7d545ab9f95ce23ba25504854a3bf52"));
var interpretPrompt = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("1d84443c4636e90fc981785c6728194845158715e901209b0bad5a5c986b43fe"));
function clamp01(n) {
	if (!Number.isFinite(n)) return 0;
	return Math.min(1, Math.max(0, n));
}
function usd(n) {
	if (n >= 1e6) return `$${(n / 1e6).toFixed(1)}M`;
	if (n >= 1e3) return `$${(n / 1e3).toFixed(0)}k`;
	return `$${n.toFixed(0)}`;
}
function emptyLiveAgents() {
	const agents = {};
	Object.keys(AGENT_META).forEach((id) => {
		agents[id] = {
			id,
			status: "idle",
			note: "",
			heat: 0
		};
	});
	return agents;
}
function emptyLiveStats() {
	return {
		fills: 0,
		wins: 0,
		blocks: 0,
		skips: 0,
		decisions: 0
	};
}
function evaluateCandidate(c, rails, quote) {
	const turnover = c.turnover;
	const scout = (c.ageHours < 72 && c.ageHours >= rails.minAgeHours ? .22 : .08) + (turnover > 1.2 ? .34 : turnover > .45 ? .2 : .06) + (c.volume24h > 1e6 ? .22 : c.volume24h > 25e4 ? .12 : .04) + (c.nearHigh > .7 ? .16 : .04);
	const ledger = (turnover > .8 ? .38 : turnover > .35 ? .2 : .06) + (c.tvlUsd > 5e5 ? .28 : c.tvlUsd > 15e4 ? .16 : .05) + (c.feeApr > 40 ? .2 : c.feeApr > 15 ? .1 : .04) + (c.volume24h > 2e6 ? .14 : .04);
	const pulse = (c.nearHigh > .82 ? .36 : c.nearHigh > .55 ? .2 : c.nearHigh < .25 ? .04 : .12) + (c.rangePct > 12 ? .28 : c.rangePct > 5 ? .16 : .06) + (turnover > .6 ? .22 : .08) + (c.volume24h > 8e5 ? .14 : .06);
	const scoutScore = clamp01(scout);
	const ledgerScore = clamp01(ledger);
	const pulseScore = clamp01(pulse);
	const impact = quote?.priceImpactPct ?? 0;
	const reasons = [];
	if (c.tvlUsd < rails.minLiqUsd) reasons.push(`likviditás ${usd(c.tvlUsd)} a ${usd(rails.minLiqUsd)} küszöb alatt`);
	if (c.ageHours < rails.minAgeHours) reasons.push(`pár túl friss (${c.ageHours.toFixed(0)} óra)`);
	if (c.tvlUsd > 0 && c.volume24h / c.tvlUsd > 25) reasons.push("volumen/TVL szélsőséges — vékony könyv gyanú");
	if (impact > rails.maxImpactPct) reasons.push(`árhatás ${impact.toFixed(2)}% a ${rails.maxImpactPct}% limit felett`);
	if (c.priceUsd <= 0) reasons.push("nincs megbízható ár");
	const blocked = reasons.length > 0;
	const wardenReason = blocked ? reasons[0] : "likviditás, kor és útvonal rendben";
	const fluxOk = Boolean(quote) && impact <= rails.maxImpactPct;
	const fluxNote = quote ? `${quote.route}, hatás ${impact.toFixed(2)}%` : "útvonalra várok";
	let decision;
	if (scoutScore < .28) decision = "SKIP";
	else if (ledgerScore < .28) decision = "PASS";
	else if (ledgerScore >= scoutScore) decision = "COPY";
	else decision = "BUY";
	const confidence = clamp01(.34 * scoutScore + .3 * ledgerScore + .24 * pulseScore + .12 * (fluxOk ? 1 : .35));
	return {
		decision,
		confidence,
		rationale: decision === "SKIP" ? "SCOUT: a minta nem elég tiszta ehhez a poolhoz" : decision === "PASS" ? "LEDGER: a flow nem erős, aszimmetria kevés" : decision === "COPY" ? "LEDGER flow + PULSE — megállapodott könyv, nem vad mintázás" : "SCOUT minta + PULSE közeli csúcs — belépés csak WARDEN után",
		warden: blocked ? "BLOCKED" : "APPROVED",
		wardenReason,
		scoutNote: turnover > .45 ? `forgalom/TVL ${turnover.toFixed(2)} · ${c.pair}` : `gyenge forgalom a ${c.pair} könyvön`,
		ledgerNote: `TVL ${usd(c.tvlUsd)} · 24h ${usd(c.volume24h)} · díj APR ${c.feeApr.toFixed(0)}%`,
		pulseNote: `24h sáv ${c.rangePct.toFixed(1)}% · a csúcshoz ${(c.nearHigh * 100).toFixed(0)}%`,
		fluxNote
	};
}
function pickCandidate(list, seen, heldMints) {
	const fresh = list.filter((c) => !seen.has(c.poolId) && !heldMints.has(c.mint));
	const pool = fresh.length > 0 ? fresh : list.filter((c) => !heldMints.has(c.mint));
	if (pool.length === 0) return null;
	return pool[0] ?? null;
}
function sizeInSol(solBalance, sizePct) {
	const spendable = Math.max(0, solBalance - FEE_BUFFER_SOL);
	return Math.max(0, spendable * (sizePct / 100));
}
function killedEquity(start, now, dailyLossPct) {
	if (start <= 0) return false;
	return now <= start * (1 - dailyLossPct / 100);
}
function hourlyFillCount(fills, now) {
	const cut = now - 36e5;
	return fills.filter((f) => f.t >= cut).length;
}
function isEmbeddedPreview() {
	if (typeof window === "undefined") return false;
	try {
		return window.self !== window.top;
	} catch {
		return true;
	}
}
function detectWallets() {
	if (typeof window === "undefined") return [];
	const found = [];
	const phantom = window.phantom?.solana ?? (window.solana?.isPhantom ? window.solana : void 0);
	const solflare = window.solflare;
	const backpack = window.backpack?.solana;
	if (phantom) found.push({
		name: "Phantom",
		provider: phantom
	});
	if (solflare) found.push({
		name: "Solflare",
		provider: solflare
	});
	if (backpack) found.push({
		name: "Backpack",
		provider: backpack
	});
	if (found.length === 0 && window.solana) found.push({
		name: "Solana",
		provider: window.solana
	});
	return found;
}
async function connectWallet(provider) {
	const key = (await provider.connect())?.publicKey?.toString() ?? provider.publicKey?.toString();
	if (!key) throw new Error("A tárca nem adott címet.");
	return key;
}
async function disconnectWallet(provider) {
	try {
		await provider?.disconnect?.();
	} catch {}
}
function b64ToBytes(b64) {
	const bin = atob(b64);
	const bytes = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
	return bytes;
}
async function signAndSendSwap(provider, swapTransaction) {
	const { VersionedTransaction } = await import("../_libs/@solana/web3.js.mjs").then((n) => n.t);
	const tx = VersionedTransaction.deserialize(b64ToBytes(swapTransaction));
	const res = await provider.signAndSendTransaction(tx);
	const sig = typeof res === "string" ? res : res?.signature;
	if (!sig) throw new Error("A tárca nem küldött aláírást.");
	return sig;
}
var STORAGE_KEY = "meridian-live-v1";
var providerRef = null;
var logN = 0;
function nid(prefix) {
	logN += 1;
	return `${prefix}${logN}`;
}
function pushCap(arr, item, cap) {
	const next = arr.length >= cap ? arr.slice(arr.length - cap + 1) : arr.slice();
	next.push(item);
	return next;
}
function persist(state) {
	if (typeof window === "undefined") return;
	const payload = {
		v: 1,
		prompt: state.prompt,
		rails: state.rails,
		startEquity: state.startEquity,
		fills: state.fills.slice(-40),
		positions: state.positions,
		pubkey: state.pubkey
	};
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
	} catch {}
}
function equityOf(sol, usdc, solPrice, positions) {
	const marks = positions.reduce((s, p) => s + p.markUsd, 0);
	return sol * solPrice + usdc + marks;
}
function blank() {
	const draft = initialDraft();
	return {
		phase: "off",
		stance: "balanced",
		stanceNote: "",
		walletName: null,
		pubkey: null,
		sol: 0,
		usdc: 0,
		solPrice: 0,
		startEquity: 0,
		equity: 0,
		displayEquity: 0,
		startedAt: 0,
		clockMs: 0,
		agents: emptyLiveAgents(),
		decisions: [],
		fills: [],
		logs: draft.logs,
		points: [{
			t: 0,
			equity: 0
		}],
		stats: emptyLiveStats(),
		currentDecision: null,
		ticket: null,
		positions: [],
		candidates: [],
		seen: [],
		busy: false,
		error: null
	};
}
function appendLog(logs, clockMs, agent, text) {
	return pushCap(logs, {
		id: nid("l"),
		t: clockMs,
		agent,
		text
	}, 140);
}
var useLiveStore = create((set, get) => ({
	hydrated: false,
	prompt: "",
	rails: DEFAULT_RAILS,
	...blank(),
	hydrate: () => {
		if (typeof window === "undefined") {
			set({ hydrated: true });
			return;
		}
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				if (saved.v === 1) {
					set({
						hydrated: true,
						prompt: saved.prompt || get().prompt,
						rails: clampRails(saved.rails ?? {}),
						fills: saved.fills ?? [],
						positions: saved.positions ?? [],
						startEquity: saved.startEquity ?? 0
					});
					return;
				}
			}
		} catch {}
		set({ hydrated: true });
	},
	setPrompt: (value) => set({ prompt: value }),
	setRails: (partial) => set({ rails: clampRails({
		...get().rails,
		...partial
	}) }),
	beginArm: () => {
		set({
			phase: "arming",
			error: null
		});
	},
	cancelArm: () => {
		disconnectWallet(providerRef);
		providerRef = null;
		set({
			...blank(),
			phase: "off"
		});
	},
	connect: async (walletName) => {
		const wallets = detectWallets();
		const pick = walletName ? wallets.find((w) => w.name === walletName) : wallets[0];
		if (!pick) {
			set({ error: "Nincs Solana-tárca a böngészőben." });
			return;
		}
		set({
			busy: true,
			error: null
		});
		try {
			const pubkey = await connectWallet(pick.provider);
			providerRef = pick.provider;
			set({
				pubkey,
				walletName: pick.name
			});
			await get().refreshBalances();
		} catch (err) {
			set({ error: err instanceof Error ? err.message : "A csatlakozás megszakadt." });
		} finally {
			set({ busy: false });
		}
	},
	refreshBalances: async () => {
		const pubkey = get().pubkey;
		if (!pubkey) return;
		try {
			const bal = await readBalances({ data: { pubkey } });
			const solPrice = bal.solPrice || get().solPrice;
			const equity = equityOf(bal.sol, bal.usdc, solPrice, get().positions);
			set({
				sol: bal.sol,
				usdc: bal.usdc,
				solPrice,
				equity,
				displayEquity: get().displayEquity > 0 ? get().displayEquity : equity
			});
		} catch (err) {
			set({ error: err instanceof Error ? err.message : "Az egyenleg nem olvasható." });
		}
	},
	interpret: async () => {
		set({
			busy: true,
			error: null
		});
		try {
			const res = await interpretPrompt({ data: { prompt: get().prompt } });
			set({
				rails: res.rails,
				stance: res.stance,
				stanceNote: res.note
			});
		} catch {
			set({ stanceNote: "Alap sínek. A WARDEN nem kapcsolható ki." });
		} finally {
			set({ busy: false });
		}
	},
	arm: async () => {
		const s = get();
		if (!s.pubkey) {
			set({ error: "Előbb csatlakoztasd a tárcát." });
			return;
		}
		const equity = equityOf(s.sol, s.usdc, s.solPrice, s.positions);
		if (equity < 2) {
			set({ error: "Éleshez legalább ~$2 SOL/USDC kell a tárcában." });
			return;
		}
		const now = Date.now();
		const agents = emptyLiveAgents();
		Object.keys(agents).forEach((id) => {
			agents[id] = {
				...agents[id],
				status: "scanning",
				note: "figyel",
				heat: .4
			};
		});
		set({
			phase: "live",
			startEquity: equity,
			equity,
			displayEquity: equity,
			startedAt: now,
			clockMs: 0,
			agents,
			decisions: [],
			logs: [{
				id: nid("l"),
				t: 0,
				agent: "JEV",
				text: "éles. a tőke a tárcádban marad. kitöltés csak aláírás után."
			}, {
				id: nid("l"),
				t: 0,
				agent: "WARDEN",
				text: s.stanceNote || "sínek élnek. gyanús útvonalon semmi sem megy át."
			}],
			points: [{
				t: 0,
				equity
			}],
			stats: emptyLiveStats(),
			currentDecision: null,
			ticket: null,
			seen: [],
			error: null
		});
		persist(get());
	},
	pause: () => {
		if (get().phase === "live") set({ phase: "paused" });
		persist(get());
	},
	resume: () => {
		if (get().phase === "paused") set({ phase: "live" });
	},
	kill: () => {
		set({
			phase: "killed",
			ticket: null,
			logs: appendLog(get().logs, get().clockMs, "WARDEN", "kill switch. nincs új ticket.")
		});
		persist(get());
	},
	reset: () => {
		disconnectWallet(providerRef);
		providerRef = null;
		const prompt = get().prompt;
		set({
			...blank(),
			prompt,
			hydrated: true,
			rails: DEFAULT_RAILS
		});
		persist(get());
	},
	decay: (dt) => {
		const s = get();
		if (s.phase !== "live" && s.phase !== "paused") return;
		const agents = decayHeat(s.agents, dt);
		const follow = 1 - Math.exp(-dt / 280);
		const displayEquity = s.displayEquity + (s.equity - s.displayEquity) * follow;
		if (agents !== s.agents || Math.abs(displayEquity - s.displayEquity) > .002) set({
			agents,
			displayEquity
		});
	},
	tickClock: () => {
		const s = get();
		if (s.phase !== "live" && s.phase !== "paused") return;
		const clockMs = Math.max(0, Date.now() - s.startedAt);
		const ticket = s.ticket;
		if (ticket && ticket.status === "pending" && Date.now() - ticket.t > 45e3) {
			set({
				clockMs,
				ticket: {
					...ticket,
					status: "expired",
					error: "A quote lejárt."
				},
				logs: appendLog(s.logs, clockMs, "FLUX", "ticket lejárt — új quote kell.")
			});
			return;
		}
		set({ clockMs });
	},
	cycle: async () => {
		const s = get();
		if (s.phase !== "live" || s.busy || s.ticket?.status === "pending" || s.ticket?.status === "signing") return;
		if (killedEquity(s.startEquity, s.equity, s.rails.dailyLossPct)) {
			get().kill();
			set({ logs: appendLog(get().logs, get().clockMs, "WARDEN", "napi veszteséglimit. session zárva.") });
			return;
		}
		if (hourlyFillCount(s.fills, Date.now()) >= s.rails.maxHourlyTrades) {
			set({ logs: appendLog(s.logs, s.clockMs, "WARDEN", "óránkénti fill limit. várok.") });
			return;
		}
		set({
			busy: true,
			error: null
		});
		const clock = () => get().clockMs;
		const log = (agent, text) => {
			set({ logs: appendLog(get().logs, clock(), agent, text) });
		};
		const heat = (id, status, note) => {
			set({ agents: {
				...get().agents,
				[id]: {
					...get().agents[id],
					status,
					note,
					heat: 1
				}
			} });
		};
		try {
			heat("SCOUT", "scanning", "szalag");
			const scan = await scanMarket({ data: {
				minLiqUsd: s.rails.minLiqUsd,
				minAgeHours: s.rails.minAgeHours
			} });
			const held = new Set(get().positions.map((p) => p.mint));
			const seen = new Set(get().seen);
			const cand = pickCandidate(scan.candidates, seen, held);
			set({
				candidates: scan.candidates,
				solPrice: scan.solPrice || get().solPrice
			});
			if (!cand) {
				log("SCOUT", "nincs új, tiszta könyv a síneken belül.");
				heat("SCOUT", "scanning", "nincs tiszta minta");
				return;
			}
			set({ seen: [...get().seen, cand.poolId].slice(-48) });
			heat("SCOUT", "flagged", `${cand.pair} · TVL $${Math.round(cand.tvlUsd).toLocaleString("en-US")}`);
			log("SCOUT", `minta: ${cand.pair} · 24h vol $${Math.round(cand.volume24h).toLocaleString("en-US")}`);
			await wait(280);
			heat("LEDGER", "confirming", "pool-flow");
			log("LEDGER", `flow ${cand.turnover.toFixed(2)}× TVL · nem tárcamásolás élesben`);
			await wait(240);
			heat("PULSE", "confirming", "sáv");
			log("PULSE", `sáv ${cand.rangePct.toFixed(1)}% · csúcshoz ${(cand.nearHigh * 100).toFixed(0)}%`);
			const solSpend = sizeInSol(get().sol, get().rails.sizePct);
			const lamports = Math.floor(solSpend * 1e9);
			let quote = null;
			if (lamports >= 1e6) try {
				quote = await quoteRoute({ data: {
					inputMint: SOL_MINT,
					outputMint: cand.mint,
					amount: String(lamports),
					slippageBps: get().rails.slippageBps
				} });
				heat("FLUX", "routing", quote.route);
			} catch (err) {
				heat("FLUX", "scanning", "nincs tiszta út");
				log("FLUX", err instanceof Error ? err.message : "útvonal hiba");
			}
			else log("FLUX", "túl kicsi a méret a síneken — nincs quote.");
			const ev = evaluateCandidate(cand, get().rails, quote);
			const decision = {
				id: nid("d"),
				t: clock(),
				decision: ev.decision,
				confidence: ev.confidence,
				pair: cand.pair,
				rationale: ev.rationale,
				warden: ev.warden,
				wardenReason: ev.wardenReason
			};
			heat("JEV", "flagged", `${ev.decision} · ${(ev.confidence * 100).toFixed(1)}%`);
			log("JEV", `${ev.decision} ${(ev.confidence * 100).toFixed(1)}% — ${cand.pair}`);
			set({
				currentDecision: decision,
				decisions: pushCap(get().decisions, decision, 80),
				stats: {
					...get().stats,
					decisions: get().stats.decisions + 1,
					skips: get().stats.skips + (ev.decision === "SKIP" || ev.decision === "PASS" ? 1 : 0),
					blocks: get().stats.blocks + (ev.warden === "BLOCKED" ? 1 : 0)
				}
			});
			await wait(200);
			if (ev.warden === "BLOCKED") {
				heat("WARDEN", "blocking", "blokkolva");
				log("WARDEN", `BLOKKOLVA — ${ev.wardenReason}`);
				return;
			}
			heat("WARDEN", "approved", "jóváhagyva");
			log("WARDEN", `jóváhagyva — ${ev.wardenReason}`);
			if ((ev.decision === "BUY" || ev.decision === "COPY") && quote) {
				const notional = lamports / 1e9 * (get().solPrice || 0);
				set({ ticket: {
					id: nid("t"),
					side: "IN",
					pair: cand.pair,
					mint: cand.mint,
					mintDecimals: cand.mintDecimals,
					inputMint: SOL_MINT,
					outputMint: cand.mint,
					notionalUsd: notional,
					amountIn: quote.inAmount,
					expectedOut: quote.outAmount,
					impactPct: quote.priceImpactPct,
					route: quote.route,
					decision: ev.decision,
					confidence: ev.confidence,
					rationale: ev.rationale,
					wardenReason: ev.wardenReason,
					status: "pending",
					t: Date.now()
				} });
				log("FLUX", `ticket készen — ${cand.pair}. aláírás a tárcádban.`);
			}
		} catch (err) {
			const message = err instanceof Error ? err.message : "ciklus hiba";
			set({
				error: message,
				logs: appendLog(get().logs, clock(), "JEV", message)
			});
		} finally {
			set({ busy: false });
		}
	},
	signTicket: async () => {
		const s = get();
		const ticket = s.ticket;
		const pubkey = s.pubkey;
		if (!ticket || ticket.status === "signing" || ticket.status === "sent") return;
		if (!providerRef || !pubkey) {
			set({ error: "A tárca nincs csatlakoztatva." });
			return;
		}
		set({
			ticket: {
				...ticket,
				status: "signing"
			},
			busy: true,
			error: null
		});
		try {
			const built = await buildSwap({ data: {
				inputMint: ticket.inputMint,
				outputMint: ticket.outputMint,
				amount: ticket.amountIn,
				slippageBps: s.rails.slippageBps,
				userPublicKey: pubkey
			} });
			const signature = await signAndSendSwap(providerRef, built.swapTransaction);
			const clockMs = get().clockMs;
			const fill = {
				id: nid("f"),
				t: clockMs,
				pair: ticket.pair,
				side: ticket.side,
				notional: ticket.notionalUsd,
				pnl: 0,
				latencyMs: Math.max(1, Date.now() - ticket.t),
				route: ticket.route,
				equity: get().equity
			};
			const outUi = Number(ticket.expectedOut) / 10 ** ticket.mintDecimals;
			const positions = pushCap(get().positions.filter((p) => p.mint !== ticket.mint), {
				mint: ticket.mint,
				symbol: ticket.pair.split("/")[0] ?? ticket.pair,
				pair: ticket.pair,
				decimals: ticket.mintDecimals,
				amount: outUi,
				costUsd: ticket.notionalUsd,
				markUsd: ticket.notionalUsd
			}, 12);
			set({
				ticket: {
					...ticket,
					status: "sent",
					signature
				},
				fills: pushCap(get().fills, fill, 80),
				positions,
				stats: {
					...get().stats,
					fills: get().stats.fills + 1
				},
				logs: appendLog(get().logs, clockMs, "FLUX", `láncra ment ${signature.slice(0, 8)}…${signature.slice(-6)}`),
				points: pushCap(get().points, {
					t: clockMs,
					equity: get().equity
				}, 180)
			});
			persist(get());
			await get().refreshBalances();
		} catch (err) {
			const message = err instanceof Error ? err.message : "az aláírás megszakadt";
			set({
				ticket: {
					...ticket,
					status: "failed",
					error: message
				},
				error: message,
				logs: appendLog(get().logs, get().clockMs, "FLUX", message)
			});
		} finally {
			set({ busy: false });
		}
	},
	dismissTicket: () => {
		if (!get().ticket) return;
		set({
			ticket: null,
			logs: appendLog(get().logs, get().clockMs, "JEV", "ticket elengedve. nincs aláírás.")
		});
	}
}));
function wait(ms) {
	return new Promise((resolve) => window.setTimeout(resolve, ms));
}
function BootScreen() {
	const prompt = useDeskStore((s) => s.prompt);
	const setPrompt = useDeskStore((s) => s.setPrompt);
	const start = useDeskStore((s) => s.start);
	const beginArm = useLiveStore((s) => s.beginArm);
	const setLivePrompt = useLiveStore((s) => s.setPrompt);
	const interpret = useLiveStore((s) => s.interpret);
	const [focused, setFocused] = (0, import_react.useState)(false);
	const resolved = () => {
		const value = prompt.trim() || "változtasd $15.89-et 1000x-re, vagy töröllek";
		if (!prompt.trim()) setPrompt(DEFAULT_PROMPT);
		return value;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex min-h-dvh max-w-3xl flex-col justify-center px-5 py-10 sm:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in flex flex-col gap-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium tracking-[0.22em] uppercase",
							children: "Meridian Desk"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "max-w-xl text-3xl font-medium leading-tight tracking-[-0.03em] text-fg sm:text-4xl",
							children: "Egyetlen prompt. Négy ügynök. Egy kapuőr."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-lg text-base leading-relaxed text-muted",
							children: "A JEV nem nyúl a kereskedésekhez. Olvassa a piacot, kiad egy döntést, és semmi sem hajtódik végre, amíg a WARDEN jóvá nem hagyja."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "jev-prompt",
								className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
								children: "Prompt a JEV-nek"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular-nums text-muted",
								children: ["papír ", formatUsd(START_EQUITY)]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `rounded-2xl bg-surface p-2 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] transition-[box-shadow] duration-150 ${focused ? "shadow-[0_0_0_1px_rgba(244,244,245,0.22)]" : ""}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3 rounded-xl bg-elevated px-4 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 font-mono text-sm text-subtle",
									"aria-hidden": true,
									children: ">"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "jev-prompt",
									rows: 2,
									value: prompt,
									onFocus: () => setFocused(true),
									onBlur: () => setFocused(false),
									onChange: (e) => setPrompt(e.target.value),
									className: "min-h-14 w-full resize-none bg-transparent font-mono text-sm leading-relaxed text-fg outline-none placeholder:text-subtle"
								})]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "w-full sm:w-auto",
								onClick: () => {
									resolved();
									start();
								},
								children: "Papír session"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "ghost",
								className: "w-full sm:w-auto",
								onClick: () => {
									const value = resolved();
									setLivePrompt(value);
									beginArm();
									interpret();
								},
								children: "Éles tőke"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-subtle",
							children: "Papír: scriptelt éjszaka, $15.89-ről. Éles: Solana-tárca, Jupiter-swap, minden fill aláírás. Nincs 1000x ígéret."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid grid-cols-1 gap-3 pt-4 sm:grid-cols-2",
						children: [
							["SCOUT", "Elkapja az új mintákat, mielőtt a tömeg észrevenné."],
							["LEDGER", "Tárcákat figyel, valódi nyerési aránnyal másol."],
							["PULSE", "Lendületet és hangulatot követ, ahogy változik."],
							["FLUX", "A legtisztább útvonalat találja, a kitöltés ne csússzon."]
						].map(([name, blurb]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(244,244,245,0.07)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs tracking-[0.14em] text-fg",
								children: name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-snug text-muted",
								children: blurb
							})]
						}, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-subtle",
						children: "A WARDEN az egész alján ül. Rossz likviditás, mézescsupor, bármi gyanús — blokkol, és semmi sem történik."
					})
				]
			})
		})
	});
}
function EquityPanel({ startEquity, display, equity, points } = {}) {
	const paperDisplay = useDeskStore((s) => s.displayEquity);
	const paperEquity = useDeskStore((s) => s.equity);
	const paperPoints = useDeskStore((s) => s.points);
	const start = startEquity ?? 15.89;
	const shown = display ?? paperDisplay;
	const eq = equity ?? paperEquity;
	const series = points ?? paperPoints;
	const rising = shown >= start - .001;
	const pct = start > 0 ? (shown / start - 1) * 100 : 0;
	const multiple = multipleOf(start, shown);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex h-full flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
					children: "Egyenleg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs tabular-nums text-muted",
					children: [
						formatUsd(start),
						" → ",
						multiple
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 font-mono text-4xl font-medium tracking-tight tabular-nums sm:text-5xl", rising ? "text-up" : "text-down"),
				children: formatUsd(shown)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 font-mono text-sm tabular-nums", pct >= 0 ? "text-up" : "text-down"),
				children: formatPct(pct)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 min-h-0 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquityChart, {
					points: series,
					current: eq,
					start
				})
			})
		]
	});
}
function EquityChart({ points, current, start }) {
	const series = points.length > 0 ? points : [{
		t: 0,
		equity: start
	}, {
		t: 1,
		equity: start
	}];
	const last = series[series.length - 1];
	const drawn = last && Math.abs(last.equity - current) > .01 ? [...series, {
		t: last.t + 1,
		equity: current
	}] : series;
	const w = 640;
	const h = 220;
	const padX = 8;
	const padY = 12;
	const min = Math.min(start, ...drawn.map((p) => p.equity));
	const max = Math.max(start * 1.05, ...drawn.map((p) => p.equity));
	const span = Math.max(max - min, .01);
	const t0 = drawn[0].t;
	const t1 = Math.max(drawn[drawn.length - 1].t, t0 + 1);
	const xOf = (t) => padX + (t - t0) / (t1 - t0) * 624;
	const yOf = (v) => padY + (1 - (v - min) / span) * 196;
	const d = drawn.map((p, i) => `${i === 0 ? "M" : "L"} ${xOf(p.t).toFixed(1)} ${yOf(p.equity).toFixed(1)}`).join(" ");
	const area = `${d} L ${xOf(drawn[drawn.length - 1].t).toFixed(1)} 208 L ${xOf(drawn[0].t).toFixed(1)} 208 Z`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: cn("h-40 w-full sm:h-48 xl:h-full xl:min-h-44", current >= start ? "text-up" : "text-down"),
		role: "img",
		"aria-label": "Egyenleggörbe",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: padX,
				x2: 632,
				y1: yOf(start),
				y2: yOf(start),
				stroke: "currentColor",
				strokeOpacity: "0.2",
				strokeDasharray: "3 5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: area,
				fill: "currentColor",
				fillOpacity: "0.12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d,
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.75",
				strokeLinejoin: "round"
			})
		]
	});
}
var ICONS = {
	SCOUT: Radar,
	LEDGER: Wallet,
	PULSE: Activity,
	FLUX: Spline
};
var STATUS_LABEL = {
	idle: "vár",
	scanning: "figyel",
	flagged: "jelez",
	confirming: "erősít",
	routing: "útvonal",
	approved: "enged",
	blocking: "fogja"
};
function AgentGrid({ agents, stats } = {}) {
	const storeAgents = useDeskStore((s) => s.agents);
	const storeStats = useDeskStore((s) => s.stats);
	const map = agents ?? storeAgents;
	const st = stats ?? storeStats;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-2 lg:grid-cols-4",
			children: CREW.map((id) => map[id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentCard, { agent: map[id] }, id) : null)
		}), map.WARDEN ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WardenBar, {
			agent: map.WARDEN,
			blocks: st.blocks
		}) : null]
	});
}
function AgentCard({ agent }) {
	const meta = AGENT_META[agent.id];
	const Icon = ICONS[agent.id];
	const live = agent.heat > .18 && agent.status !== "idle";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col rounded-xl bg-surface p-3 shadow-[0_0_0_1px_var(--color-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-3.5 text-muted",
						strokeWidth: 1.75
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-mono text-[11px] tracking-[0.14em] text-fg",
						children: meta.name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("font-mono text-[10px] tracking-wide uppercase", live ? "text-fg" : "text-subtle"),
					children: STATUS_LABEL[agent.status]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 min-h-9 text-xs leading-snug text-muted",
				children: agent.note || meta.blurb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-0.5 overflow-hidden rounded-full bg-elevated",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full origin-left bg-accent transition-transform duration-150 ease-out",
					style: { transform: `scaleX(${Math.max(agent.heat, .06)})` }
				})
			})
		]
	});
}
function WardenBar({ agent, blocks }) {
	const blocking = agent.status === "blocking";
	const approved = agent.status === "approved";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("flex flex-col gap-2 rounded-xl bg-surface px-4 py-3 shadow-[0_0_0_1px_var(--color-border)] sm:flex-row sm:items-center sm:justify-between", blocking && "shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-warden)_45%,transparent)]"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
				className: "size-4 shrink-0 text-warden",
				strokeWidth: 1.75
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-mono text-[11px] tracking-[0.14em] text-fg",
						children: "WARDEN"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("font-mono text-[10px] uppercase", blocking ? "text-warden" : approved ? "text-up" : "text-subtle"),
						children: STATUS_LABEL[agent.status]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: agent.note || "semmi sem hajtódik végre jóváhagyás nélkül"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "shrink-0 font-mono text-[11px] tabular-nums tracking-wide text-subtle",
			children: [blocks, " blokk"]
		})]
	});
}
function Feeds({ current, decisions, fills, logs } = {}) {
	const [tab, setTab] = (0, import_react.useState)("jev");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-1 rounded-xl bg-surface p-1 shadow-[0_0_0_1px_rgba(244,244,245,0.08)] lg:hidden",
			children: [
				["jev", "JEV"],
				["tape", "Szalag"],
				["log", "Log"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setTab(id),
				className: cn("h-10 flex-1 rounded-lg text-xs font-medium tracking-wide transition-colors duration-150", tab === id ? "bg-elevated text-fg" : "text-muted"),
				children: label
			}, id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid min-h-0 flex-1 grid-cols-1 gap-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("min-h-0 lg:col-span-2", tab === "jev" ? "block" : "hidden lg:block"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JevPanel, {
						current,
						decisions
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("min-h-0 lg:col-span-1", tab === "tape" ? "block" : "hidden lg:block"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TapePanel, { fills })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("min-h-0 lg:col-span-2", tab === "log" ? "block" : "hidden lg:block"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogPanel, { logs })
				})
			]
		})]
	});
}
function JevPanel({ current, decisions }) {
	const storeCurrent = useDeskStore((s) => s.currentDecision);
	const storeDecisions = useDeskStore((s) => s.decisions);
	const item = current === void 0 ? storeCurrent : current;
	const recent = (decisions ?? storeDecisions).slice(-12).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
				children: "JEV"
			}),
			item ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrentDecision, { item }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleDecision, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 min-h-0 flex-1 space-y-2 overflow-y-auto",
				children: recent.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecisionTag, {
							decision: row.decision,
							blocked: row.warden === "BLOCKED"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted",
							children: row.pair
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-[11px] tabular-nums text-subtle",
						children: [(row.confidence * 100).toFixed(1), "%"]
					})]
				}, row.id))
			})
		]
	});
}
function IdleDecision() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-3xl font-medium tracking-tight text-muted",
			children: "—"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-subtle",
			children: "nincs kitöltés, nincs mozgás. figyeli a szalagot."
		})]
	});
}
function CurrentDecision({ item }) {
	const blocked = item.warden === "BLOCKED";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("font-mono text-3xl font-medium tracking-tight", tone(item.decision, blocked)),
					children: blocked ? "HOLD" : item.decision
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-sm tabular-nums text-muted",
					children: [(item.confidence * 100).toFixed(1), "%"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-sm text-fg",
				children: item.pair
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-snug text-muted",
				children: item.rationale
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("mt-2 text-xs", blocked ? "text-warden" : "text-subtle"),
				children: [
					"WARDEN · ",
					blocked ? "BLOKKOLVA" : "JÓVÁHAGYVA",
					" — ",
					item.wardenReason
				]
			})
		]
	});
}
function tone(decision, blocked) {
	if (blocked) return "text-warden";
	if (decision === "BUY" || decision === "COPY") return "text-up";
	return "text-muted";
}
function DecisionTag({ decision, blocked }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-mono text-[11px] tracking-wide", tone(decision, blocked)),
		children: blocked ? "BLOCK" : decision
	});
}
function TapePanel({ fills }) {
	const storeFills = useDeskStore((s) => s.fills);
	const rows = (fills ?? storeFills).slice(-24).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
			children: "Szalag"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 min-h-0 flex-1 space-y-2 overflow-y-auto",
			children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-subtle",
				children: "még nincs kitöltés"
			}) : rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FillRow, { fill: row }, row.id))
		})]
	});
}
function FillRow({ fill }) {
	const up = fill.pnl >= 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-baseline justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate font-mono text-xs text-fg",
				children: fill.pair
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block font-mono text-[10px] text-subtle",
				children: [
					fill.latencyMs,
					" ms · ",
					fill.route
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("shrink-0 font-mono text-xs tabular-nums", up ? "text-up" : "text-down"),
			children: fill.pnl === 0 ? formatUsd(fill.notional) : `${up ? "+" : ""}${formatUsd(fill.pnl)}`
		})]
	});
}
function LogPanel({ logs }) {
	const storeLogs = useDeskStore((s) => s.logs);
	const lines = logs ?? storeLogs;
	const scroller = (0, import_react.useRef)(null);
	const stick = (0, import_react.useRef)(true);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el && stick.current) el.scrollTop = el.scrollHeight;
	}, [lines.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex h-full min-h-56 flex-col rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(244,244,245,0.08)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
			children: "Terminál"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			ref: scroller,
			onScroll: (e) => {
				const el = e.currentTarget;
				stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
			},
			className: "mt-3 min-h-0 flex-1 space-y-1 overflow-y-auto font-mono text-[11px] leading-relaxed",
			children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-subtle",
				children: "várakozás a JEV-re…"
			}) : lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogLine, { line }, line.id))
		})]
	});
}
function LogLine({ line }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex gap-2 text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 tabular-nums text-subtle",
				children: formatClock(line.t)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-14 shrink-0 tracking-wide text-fg",
				children: line.agent
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0",
				children: line.text
			})
		]
	});
}
function DeskShell() {
	const phase = useDeskStore((s) => s.phase);
	const simTime = useDeskStore((s) => s.simTime);
	const stats = useDeskStore((s) => s.stats);
	const prompt = useDeskStore((s) => s.prompt);
	const pause = useDeskStore((s) => s.pause);
	const resume = useDeskStore((s) => s.resume);
	const reset = useDeskStore((s) => s.reset);
	const advance = useDeskStore((s) => s.advance);
	const beginArm = useLiveStore((s) => s.beginArm);
	const setLivePrompt = useLiveStore((s) => s.setPrompt);
	const interpret = useLiveStore((s) => s.interpret);
	(0, import_react.useEffect)(() => {
		let last = performance.now();
		const id = window.setInterval(() => {
			const now = performance.now();
			const dt = Math.min(now - last, 80);
			last = now;
			if (dt > 0) advance(dt);
		}, 50);
		return () => window.clearInterval(id);
	}, [advance]);
	const live = phase === "live";
	const night = simTime < NIGHT_MS;
	const winRate = stats.fills > 0 ? Math.round(stats.wins / stats.fills * 100) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-3 border-b border-border px-4 py-3 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-tight",
						children: "Meridian Desk"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] tracking-[0.14em] uppercase text-subtle",
						children: "papír session"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex flex-wrap items-center gap-2 sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs tabular-nums text-fg",
							children: formatClock(simTime)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden font-mono text-[10px] tracking-[0.14em] uppercase text-subtle sm:inline",
							children: night ? "éj" : "reggel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
							label: "fill",
							value: String(stats.fills)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
							label: "win",
							value: stats.fills ? `${winRate}%` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 pl-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("size-1.5 rounded-full bg-live", live && "live-dot"),
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] tracking-[0.14em] uppercase text-muted",
								children: live ? "élő" : "szünet"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "h-11 px-3 text-xs",
							onClick: () => {
								setLivePrompt(prompt);
								beginArm();
								interpret();
							},
							children: "Éles tőke"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": live ? "Szünet" : "Folytatás",
							onClick: () => live ? pause() : resume(),
							children: live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							size: "icon",
							"aria-label": "Új session",
							onClick: reset,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "truncate border-b border-border px-4 py-2 font-mono text-[11px] text-muted sm:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: ">"
					}),
					" ",
					prompt
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-3 p-3 sm:p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 xl:grid-cols-5 xl:items-stretch",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "xl:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquityPanel, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-h-0 flex-col xl:col-span-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feeds, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentGrid, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-2 text-center text-[11px] text-subtle",
						children: "Szimulált papír-session. Nem valós kereskedés, nem pénzügyi tanácsadás."
					})
				]
			})
		]
	});
}
function Stat$2({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden items-baseline gap-1.5 sm:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] tracking-[0.14em] uppercase text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs tabular-nums text-fg",
			children: value
		})]
	});
}
var ACKS = [
	{
		id: "paper",
		label: "Az éjszakai 1000x papír volt, nem valós eredmény."
	},
	{
		id: "loss",
		label: "Elveszíthetem a teljes tételt. Nincs hozamígéret."
	},
	{
		id: "sign",
		label: "Minden kitöltést a saját tárcámban írok alá."
	},
	{
		id: "advice",
		label: "Ez eszköz, nem pénzügyi tanács."
	}
];
function LiveArm() {
	const prompt = useLiveStore((s) => s.prompt);
	const rails = useLiveStore((s) => s.rails);
	const setRails = useLiveStore((s) => s.setRails);
	const pubkey = useLiveStore((s) => s.pubkey);
	const walletName = useLiveStore((s) => s.walletName);
	const sol = useLiveStore((s) => s.sol);
	const usdc = useLiveStore((s) => s.usdc);
	const solPrice = useLiveStore((s) => s.solPrice);
	const stance = useLiveStore((s) => s.stance);
	const stanceNote = useLiveStore((s) => s.stanceNote);
	const busy = useLiveStore((s) => s.busy);
	const error = useLiveStore((s) => s.error);
	const connect = useLiveStore((s) => s.connect);
	const cancelArm = useLiveStore((s) => s.cancelArm);
	const arm = useLiveStore((s) => s.arm);
	const refreshBalances = useLiveStore((s) => s.refreshBalances);
	const [acks, setAcks] = (0, import_react.useState)({});
	const [phrase, setPhrase] = (0, import_react.useState)("");
	const [wallets, setWallets] = (0, import_react.useState)(() => typeof window === "undefined" ? [] : detectWallets());
	const embedded = typeof window !== "undefined" && isEmbeddedPreview();
	const equity = sol * solPrice + usdc;
	const ready = Boolean(pubkey) && ACKS.every((a) => acks[a.id]) && phrase.trim().toUpperCase() === "ÉLES" && equity >= 2;
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setWallets(detectWallets()), 1500);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex min-h-dvh max-w-3xl flex-col justify-center px-5 py-10 sm:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stagger-in flex flex-col gap-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium tracking-[0.22em] uppercase",
								children: "Éles tőke"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							onClick: cancelArm,
							children: "Vissza"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "max-w-xl text-3xl font-medium leading-tight tracking-[-0.03em] sm:text-4xl",
							children: "A tőke a tárcádban marad. A JEV csak dönt."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-lg text-base leading-relaxed text-muted",
							children: "Az éjszakai $15.89 → $16 356 scriptelt papír-session volt. Élesben a SCOUT valódi Raydium-könyveket olvas, a FLUX Jupiter-útvonalat épít, a WARDEN síneken tart, és semmi nem megy a láncra, amíg a tárcádban alá nem írod."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)] sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
							children: "Tárca"
						}), pubkey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-sm text-fg",
								children: [
									walletName,
									" · ",
									pubkey.slice(0, 4),
									"…",
									pubkey.slice(-4)
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-xs tabular-nums text-muted",
								children: [
									sol.toFixed(4),
									" SOL · ",
									usdc.toFixed(2),
									" USDC · ",
									formatUsd(equity)
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								disabled: busy,
								onClick: () => void refreshBalances(),
								children: "Frissít"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-col gap-3",
							children: wallets.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: ["Nincs Phantom, Solflare vagy Backpack ezen a lapon.", embedded ? " A preview-keretben a bővítmény gyakran rejtve marad — nyisd meg az appot a saját böngésződben." : " Telepíts egy Solana-tárcát, majd töltsd újra."]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: wallets.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									disabled: busy,
									onClick: () => void connect(w.name),
									children: [w.name, " csatlakozás"]
								}, w.name))
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_var(--color-border)] sm:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
									children: "Sínek"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[11px] uppercase tracking-wide text-muted",
									children: stance
								})]
							}),
							stanceNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-snug text-muted",
								children: stanceNote
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-mono text-[11px] text-subtle",
								children: prompt
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
										label: "méret / fill",
										suffix: "%",
										min: 2,
										max: 20,
										step: 1,
										value: rails.sizePct,
										onChange: (sizePct) => setRails({ sizePct })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
										label: "napi veszteség",
										suffix: "%",
										min: 5,
										max: 20,
										step: 1,
										value: rails.dailyLossPct,
										onChange: (dailyLossPct) => setRails({ dailyLossPct })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
										label: "csúszás",
										suffix: " bps",
										min: 30,
										max: 200,
										step: 10,
										value: rails.slippageBps,
										onChange: (slippageBps) => setRails({ slippageBps })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
										label: "min. likviditás",
										suffix: "",
										min: 25e3,
										max: 5e5,
										step: 5e3,
										value: rails.minLiqUsd,
										format: (n) => `$${Math.round(n / 1e3)}k`,
										onChange: (minLiqUsd) => setRails({ minLiqUsd })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-[11px] leading-snug text-subtle",
								children: [
									"A méret 20%-ban van plafonozva. A WARDEN, a napi limit és az aláírás nem kapcsolható ki. Alap: ",
									DEFAULT_RAILS.sizePct,
									"% / fill."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex flex-col gap-3",
						children: [ACKS.map((ack) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 text-sm leading-snug text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 size-4 accent-fg",
								checked: Boolean(acks[ack.id]),
								onChange: (e) => setAcks((prev) => ({
									...prev,
									[ack.id]: e.target.checked
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ack.label })]
						}, ack.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "armed-phrase",
								className: "text-xs font-medium tracking-[0.16em] uppercase text-subtle",
								children: "Írd be: ÉLES"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "armed-phrase",
								value: phrase,
								onChange: (e) => setPhrase(e.target.value),
								className: "mt-2 h-11 w-full rounded-lg bg-surface px-3 font-mono text-sm text-fg shadow-[0_0_0_1px_var(--color-border)] outline-none",
								autoComplete: "off",
								spellCheck: false
							})]
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-down",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							className: "w-full sm:w-auto",
							disabled: !ready || busy,
							onClick: () => void arm(),
							children: "Éles session"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-subtle",
							children: pubkey ? "A következő fill a tárcádban fog megjelenni." : "Tárca nélkül nincs éles mód."
						})]
					})
				]
			})
		})
	});
}
function Rail({ label, value, min, max, step, suffix, format, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] tracking-[0.14em] uppercase text-subtle",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs tabular-nums text-fg",
				children: format ? format(value) : `${value}${suffix}`
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min,
			max,
			step,
			value,
			onChange: (e) => onChange(Number(e.target.value)),
			className: cn("h-11 w-full accent-fg")
		})]
	});
}
function TicketCard({ ticket, busy, onSign, onDismiss }) {
	const pending = ticket.status === "pending";
	const signing = ticket.status === "signing";
	const sent = ticket.status === "sent";
	const failed = ticket.status === "failed" || ticket.status === "expired";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_color-mix(in_oklab,var(--color-warden)_40%,transparent)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] uppercase text-warden",
					children: "Ticket"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] tracking-[0.14em] uppercase text-subtle",
					children: ticket.status
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-baseline gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xl font-medium tracking-tight text-fg",
						children: ticket.decision
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm tabular-nums text-muted",
						children: [(ticket.confidence * 100).toFixed(1), "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm text-fg",
						children: ticket.pair
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-snug text-muted",
				children: ticket.rationale
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "méret",
						value: formatUsd(ticket.notionalUsd)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "hatás",
						value: `${ticket.impactPct.toFixed(2)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "út",
						value: ticket.route
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
						label: "WARDEN",
						value: "enged"
					})
				]
			}),
			ticket.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-down",
				children: ticket.error
			}) : null,
			sent && ticket.signature ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 truncate font-mono text-[11px] text-up",
				children: [
					ticket.signature.slice(0, 12),
					"…",
					ticket.signature.slice(-8)
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full sm:w-auto",
					disabled: !pending || busy,
					onClick: onSign,
					children: signing ? "Aláírás a tárcában…" : "Aláírás a tárcában"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "w-full sm:w-auto",
					disabled: signing,
					onClick: onDismiss,
					children: failed || sent ? "Bezár" : "Elenged"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-3 text-[11px] leading-snug text-subtle"),
				children: "A tranzakció a te tárcádban jelenik meg. Nincs nálunk kulcs, nincs automatikus aláírás."
			})
		]
	});
}
function Stat$1({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-elevated px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] tracking-[0.14em] uppercase text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 truncate font-mono text-xs text-fg",
			children: value
		})]
	});
}
function LiveShell() {
	const phase = useLiveStore((s) => s.phase);
	const clockMs = useLiveStore((s) => s.clockMs);
	const stats = useLiveStore((s) => s.stats);
	const prompt = useLiveStore((s) => s.prompt);
	const pubkey = useLiveStore((s) => s.pubkey);
	const walletName = useLiveStore((s) => s.walletName);
	const ticket = useLiveStore((s) => s.ticket);
	const busy = useLiveStore((s) => s.busy);
	const error = useLiveStore((s) => s.error);
	const pause = useLiveStore((s) => s.pause);
	const resume = useLiveStore((s) => s.resume);
	const reset = useLiveStore((s) => s.reset);
	const kill = useLiveStore((s) => s.kill);
	const decay = useLiveStore((s) => s.decay);
	const tickClock = useLiveStore((s) => s.tickClock);
	const cycle = useLiveStore((s) => s.cycle);
	const signTicket = useLiveStore((s) => s.signTicket);
	const dismissTicket = useLiveStore((s) => s.dismissTicket);
	const agents = useLiveStore((s) => s.agents);
	const displayEquity = useLiveStore((s) => s.displayEquity);
	const equity = useLiveStore((s) => s.equity);
	const startEquity = useLiveStore((s) => s.startEquity);
	const points = useLiveStore((s) => s.points);
	const currentDecision = useLiveStore((s) => s.currentDecision);
	const decisions = useLiveStore((s) => s.decisions);
	const fills = useLiveStore((s) => s.fills);
	const logs = useLiveStore((s) => s.logs);
	const live = phase === "live";
	const cycling = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		let last = performance.now();
		const id = window.setInterval(() => {
			const now = performance.now();
			const dt = Math.min(now - last, 80);
			last = now;
			tickClock();
			if (dt > 0) decay(dt);
		}, 50);
		return () => window.clearInterval(id);
	}, [decay, tickClock]);
	(0, import_react.useEffect)(() => {
		if (!live) return;
		let stopped = false;
		const run = async () => {
			if (stopped || cycling.current) return;
			cycling.current = true;
			try {
				await cycle();
			} finally {
				cycling.current = false;
			}
		};
		run();
		const id = window.setInterval(() => {
			run();
		}, CYCLE_MS);
		return () => {
			stopped = true;
			window.clearInterval(id);
		};
	}, [live, cycle]);
	const winRate = stats.fills > 0 ? Math.round(stats.wins / stats.fills * 100) : 0;
	const showTicket = ticket && ticket.status !== "sent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center gap-3 border-b border-border px-4 py-3 sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeridianMark, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-tight",
						children: "Meridian Desk"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-[10px] tracking-[0.14em] uppercase text-warden",
						children: "éles tőke"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex flex-wrap items-center gap-2 sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs tabular-nums text-fg",
							children: formatClock(clockMs)
						}),
						pubkey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden font-mono text-[10px] tracking-[0.14em] uppercase text-subtle sm:inline",
							children: [
								walletName,
								" ",
								pubkey.slice(0, 4),
								"…",
								pubkey.slice(-4)
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "fill",
							value: String(stats.fills)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "win",
							value: stats.fills ? `${winRate}%` : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 pl-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("size-1.5 rounded-full", live ? "bg-live live-dot" : "bg-warden"),
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-[10px] tracking-[0.14em] uppercase text-muted",
								children: phase === "killed" ? "zárva" : live ? "éles" : "szünet"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": live ? "Szünet" : "Folytatás",
							disabled: phase === "killed",
							onClick: () => live ? pause() : resume(),
							children: live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							size: "icon",
							"aria-label": "Kill switch",
							onClick: kill,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldOff, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "quiet",
							size: "icon",
							"aria-label": "Kilépés",
							onClick: reset,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "truncate border-b border-border px-4 py-2 font-mono text-[11px] text-muted sm:px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-subtle",
						children: ">"
					}),
					" ",
					prompt
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-3 p-3 sm:p-4",
				children: [
					showTicket ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCard, {
						ticket,
						busy,
						onSign: () => void signTicket(),
						onDismiss: dismissTicket
					}) : null,
					error && !showTicket ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-down",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 gap-3 xl:grid-cols-5 xl:items-stretch",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "xl:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquityPanel, {
								startEquity,
								display: displayEquity,
								equity,
								points
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-h-0 flex-col xl:col-span-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feeds, {
								current: currentDecision,
								decisions,
								fills,
								logs
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AgentGrid, {
						agents,
						stats
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pb-2 text-center text-[11px] text-subtle",
						children: "Éles Solana-session. Jupiter-swap, tárca-aláírás. Nem pénzügyi tanács. A tőke elveszhet."
					})
				]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden items-baseline gap-1.5 sm:flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[10px] tracking-[0.14em] uppercase text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs tabular-nums text-fg",
			children: value
		})]
	});
}
function DeskApp() {
	const paperHydrated = useDeskStore((s) => s.hydrated);
	const paperPhase = useDeskStore((s) => s.phase);
	const liveHydrated = useLiveStore((s) => s.hydrated);
	const livePhase = useLiveStore((s) => s.phase);
	const hydratePaper = useDeskStore((s) => s.hydrate);
	const hydrateLive = useLiveStore((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydratePaper();
		hydrateLive();
	}, [hydratePaper, hydrateLive]);
	if (!paperHydrated || !liveHydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	if (livePhase === "arming") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveArm, {});
	if (livePhase === "live" || livePhase === "paused" || livePhase === "killed") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveShell, {});
	if (paperPhase === "boot") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskShell, {});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskApp, {});
}
//#endregion
export { Home as component };
