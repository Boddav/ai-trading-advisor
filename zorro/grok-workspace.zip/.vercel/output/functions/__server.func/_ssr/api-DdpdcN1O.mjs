import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as SOL_SYMBOLS, c as USDC_MINT, i as SOL_MINT, l as clampRails, n as DEFAULT_RAILS, o as STABLE_MINTS, s as STABLE_SYMBOLS } from "./types-DI03e0Tf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DdpdcN1O.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var RAYDIUM_POOLS = "https://api-v3.raydium.io/pools/info/list?poolType=all&poolSortField=volume24h&sortType=desc&pageSize=40&page=1";
var JUP_QUOTE = "https://lite-api.jup.ag/swap/v1/quote";
var JUP_SWAP = "https://lite-api.jup.ag/swap/v1/swap";
var RPCS = ["https://solana-rpc.publicnode.com", "https://api.mainnet-beta.solana.com"];
async function getJson(url, init, timeoutMs = 8e3) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), timeoutMs);
	try {
		const res = await fetch(url, {
			...init,
			signal: ctrl.signal,
			headers: {
				accept: "application/json",
				...init?.headers ?? {}
			}
		});
		if (!res.ok) throw new Error(`HTTP ${res.status}`);
		return await res.json();
	} finally {
		clearTimeout(timer);
	}
}
async function rpc(method, params) {
	let last = "RPC hiba";
	for (const url of RPCS) try {
		const parsed = await getJson(url, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				jsonrpc: "2.0",
				id: 1,
				method,
				params
			})
		}, 7e3);
		if (parsed.error) throw new Error(parsed.error.message ?? "rpc error");
		return parsed.result;
	} catch (err) {
		last = err instanceof Error ? err.message : "rpc error";
	}
	throw new Error(last);
}
function asNum(v) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : 0;
}
function isSolSymbol(sym) {
	return SOL_SYMBOLS.has(sym.toUpperCase());
}
function isStableSymbol(sym) {
	return STABLE_SYMBOLS.has(sym.toUpperCase());
}
function isStableMint(mint) {
	return STABLE_MINTS.has(mint) || mint === "So11111111111111111111111111111111111111112";
}
function mapPool(p) {
	const a = p.mintA;
	const b = p.mintB;
	if (!a?.address || !b?.address || !p.id) return null;
	const aSol = isSolSymbol(a.symbol ?? "") || a.address === "So11111111111111111111111111111111111111112";
	const bSol = isSolSymbol(b.symbol ?? "") || b.address === "So11111111111111111111111111111111111111112";
	const aSt = isStableSymbol(a.symbol ?? "") || STABLE_MINTS.has(a.address);
	const bSt = isStableSymbol(b.symbol ?? "") || STABLE_MINTS.has(b.address);
	if ((aSol || aSt) && (bSol || bSt)) return null;
	let base = a;
	let quote = b;
	let quoteMint = b.address;
	if (aSol || aSt) {
		base = b;
		quote = a;
		quoteMint = a.address;
	} else if (!(bSol || bSt)) return null;
	if (!base.address || isStableMint(base.address)) return null;
	const tvlUsd = asNum(p.tvl);
	const volume24h = asNum(p.day?.volume);
	const priceMin = asNum(p.day?.priceMin);
	const priceMax = asNum(p.day?.priceMax);
	const rangePct = priceMin > 0 ? (priceMax - priceMin) / priceMin * 100 : 0;
	const price = asNum(p.price);
	const nearHigh = priceMax > 0 ? clamp(price / priceMax, 0, 1) : .5;
	const open = asNum(p.openTime);
	const ageHours = open > 1e9 ? Math.max(0, (Date.now() / 1e3 - open) / 3600) : 8760;
	return {
		poolId: p.id,
		pair: `${base.symbol ?? "TOKEN"}/${quote.symbol === "WSOL" ? "SOL" : quote.symbol ?? "USDC"}`,
		mint: base.address,
		mintDecimals: Math.min(18, Math.max(0, Math.round(asNum(base.decimals) || 6))),
		quoteMint,
		quoteSymbol: quote.symbol === "WSOL" ? "SOL" : quote.symbol ?? "USDC",
		symbol: base.symbol ?? "TOKEN",
		name: base.name ?? base.symbol ?? "token",
		tvlUsd,
		volume24h,
		turnover: tvlUsd > 0 ? volume24h / tvlUsd : 0,
		priceUsd: 0,
		rangePct,
		nearHigh,
		ageHours,
		feeApr: asNum(p.day?.feeApr ?? p.day?.apr),
		dex: p.type === "Concentrated" ? "Raydium CLMM" : "Raydium"
	};
}
function clamp(n, lo, hi) {
	return Math.min(hi, Math.max(lo, n));
}
async function solPriceUsd() {
	try {
		const n = asNum((await getJson(`${JUP_QUOTE}?inputMint=${SOL_MINT}&outputMint=${USDC_MINT}&amount=1000000000&slippageBps=50`, void 0, 6e3)).outAmount) / 10 ** 6;
		if (n > 10 && n < 1e4) return n;
	} catch {}
	try {
		const n = asNum((await getJson("https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd", void 0, 5e3)).solana?.usd);
		if (n > 0) return n;
	} catch {}
	return 0;
}
var scanMarket_createServerFn_handler = createServerRpc({
	id: "f7fe41062c885f97cb4c3ac3c3f5ddc6f379d45c2cf24d03a5c61cf12135cb37",
	name: "scanMarket",
	filename: "src/lib/live/api.ts"
}, (opts) => scanMarket.__executeServer(opts));
var scanMarket = createServerFn({ method: "POST" }).validator((input) => input).handler(scanMarket_createServerFn_handler, async ({ data }) => {
	const minLiq = data.minLiqUsd ?? DEFAULT_RAILS.minLiqUsd;
	const minAge = data.minAgeHours ?? DEFAULT_RAILS.minAgeHours;
	const pools = (await getJson(RAYDIUM_POOLS, void 0, 9e3)).data?.data ?? [];
	const solPrice = await solPriceUsd();
	const mapped = [];
	const seenMint = /* @__PURE__ */ new Set();
	for (const pool of pools) {
		const c = mapPool(pool);
		if (!c) continue;
		if (c.tvlUsd < minLiq * .6) continue;
		if (c.ageHours < Math.min(1, minAge * .25)) continue;
		if (seenMint.has(c.mint)) continue;
		seenMint.add(c.mint);
		if (c.quoteMint === "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" || c.quoteSymbol === "USDC") c.priceUsd = asNum(pool.price);
		else if (solPrice > 0) c.priceUsd = asNum(pool.price) > 0 ? solPrice / asNum(pool.price) : 0;
		mapped.push(c);
		if (mapped.length >= 16) break;
	}
	mapped.sort((a, b) => b.volume24h - a.volume24h);
	return {
		solPrice,
		candidates: mapped,
		at: Date.now()
	};
});
var quoteRoute_createServerFn_handler = createServerRpc({
	id: "218be6308109ed9a05a374f2ce7028946820b61da51877a003c012cd97605705",
	name: "quoteRoute",
	filename: "src/lib/live/api.ts"
}, (opts) => quoteRoute.__executeServer(opts));
var quoteRoute = createServerFn({ method: "POST" }).validator((input) => input).handler(quoteRoute_createServerFn_handler, async ({ data }) => {
	const quote = await getJson(`${JUP_QUOTE}?${new URLSearchParams({
		inputMint: data.inputMint,
		outputMint: data.outputMint,
		amount: data.amount,
		slippageBps: String(data.slippageBps),
		swapMode: "ExactIn"
	}).toString()}`, void 0, 8e3);
	if (!quote?.outAmount) throw new Error(quote?.error || "Nincs Jupiter-útvonal.");
	const labels = (quote.routePlan ?? []).map((hop) => hop.swapInfo?.label).filter((x) => Boolean(x));
	const unique = [...new Set(labels)];
	return {
		inputMint: quote.inputMint ?? data.inputMint,
		outputMint: quote.outputMint ?? data.outputMint,
		inAmount: quote.inAmount ?? data.amount,
		outAmount: quote.outAmount,
		priceImpactPct: Math.abs(asNum(quote.priceImpactPct)) * (Math.abs(asNum(quote.priceImpactPct)) <= 1 ? 100 : 1),
		route: unique.slice(0, 3).join(" → ") || "Jupiter"
	};
});
var buildSwap_createServerFn_handler = createServerRpc({
	id: "c00b9951b68f3bbef4903fa4c2f450cde7d97e6d8e6e24672e0c469386f7cb07",
	name: "buildSwap",
	filename: "src/lib/live/api.ts"
}, (opts) => buildSwap.__executeServer(opts));
var buildSwap = createServerFn({ method: "POST" }).validator((input) => input).handler(buildSwap_createServerFn_handler, async ({ data }) => {
	const quote = await getJson(`${JUP_QUOTE}?${new URLSearchParams({
		inputMint: data.inputMint,
		outputMint: data.outputMint,
		amount: data.amount,
		slippageBps: String(data.slippageBps),
		swapMode: "ExactIn"
	}).toString()}`, void 0, 8e3);
	const swap = await getJson(JUP_SWAP, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			quoteResponse: quote,
			userPublicKey: data.userPublicKey,
			wrapAndUnwrapSol: true,
			dynamicComputeUnitLimit: true,
			dynamicSlippage: true,
			prioritizationFeeLamports: { priorityLevelWithMaxLamports: {
				maxLamports: 4e5,
				priorityLevel: "high"
			} }
		})
	}, 1e4);
	if (!swap.swapTransaction) throw new Error(swap.error || "A Jupiter nem épített tranzakciót.");
	return { swapTransaction: swap.swapTransaction };
});
var readBalances_createServerFn_handler = createServerRpc({
	id: "3cae019a50427c37bbd0175907f5f372d7d545ab9f95ce23ba25504854a3bf52",
	name: "readBalances",
	filename: "src/lib/live/api.ts"
}, (opts) => readBalances.__executeServer(opts));
var readBalances = createServerFn({ method: "POST" }).validator((input) => input).handler(readBalances_createServerFn_handler, async ({ data }) => {
	const pubkey = data.pubkey.trim();
	if (pubkey.length < 32) throw new Error("Érvénytelen cím.");
	const lamports = asNum(await rpc("getBalance", [pubkey]));
	const usdc = ((await rpc("getTokenAccountsByOwner", [
		pubkey,
		{ mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" },
		{ encoding: "jsonParsed" }
	])).value ?? []).reduce((sum, acc) => {
		return sum + asNum(acc.account?.data?.parsed?.info?.tokenAmount?.uiAmount);
	}, 0);
	const solPrice = await solPriceUsd();
	return {
		sol: lamports / 1e9,
		usdc,
		solPrice
	};
});
var interpretPrompt_createServerFn_handler = createServerRpc({
	id: "1d84443c4636e90fc981785c6728194845158715e901209b0bad5a5c986b43fe",
	name: "interpretPrompt",
	filename: "src/lib/live/api.ts"
}, (opts) => interpretPrompt.__executeServer(opts));
var interpretPrompt = createServerFn({ method: "POST" }).validator((input) => input).handler(interpretPrompt_createServerFn_handler, async ({ data }) => {
	const fallback = {
		rails: DEFAULT_RAILS,
		stance: "balanced",
		note: "Alap sínek. A WARDEN nem kapcsolható ki."
	};
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return fallback;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 280,
				temperature: 0,
				messages: [{
					role: "system",
					content: "You configure risk rails for a live Solana desk. Never disable WARDEN. Never chase 1000x. JSON only."
				}, {
					role: "user",
					content: `Operator prompt: ${data.prompt.slice(0, 500)}
Return JSON: {"stance":"defensive"|"balanced"|"aggressive","sizePct":2-20,"dailyLossPct":5-20,"slippageBps":30-200,"minLiqUsd":25000-2000000,"minAgeHours":1-168,"maxImpactPct":0.3-4,"maxHourlyTrades":1-12,"note":"one Hungarian sentence"}
If they demand huge returns, stay defensive and say so in note.`
				}]
			})
		});
		if (!res.ok) return fallback;
		const match = ((await res.json()).choices?.[0]?.message?.content ?? "").match(/\{[\s\S]*\}/);
		if (!match) return fallback;
		const parsed = JSON.parse(match[0]);
		return {
			rails: clampRails(parsed),
			stance: parsed.stance === "aggressive" || parsed.stance === "defensive" ? parsed.stance : "balanced",
			note: (parsed.note ?? fallback.note).slice(0, 220)
		};
	} catch {
		return fallback;
	}
});
//#endregion
export { buildSwap_createServerFn_handler, interpretPrompt_createServerFn_handler, quoteRoute_createServerFn_handler, readBalances_createServerFn_handler, scanMarket_createServerFn_handler };
