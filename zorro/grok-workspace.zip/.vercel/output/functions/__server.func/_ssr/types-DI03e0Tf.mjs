//#region node_modules/.nitro/vite/services/ssr/assets/types-DI03e0Tf.js
var SOL_MINT = "So11111111111111111111111111111111111111112";
var USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
var FEE_BUFFER_SOL = .02;
var CYCLE_MS = 14e3;
var STABLE_MINTS = /* @__PURE__ */ new Set([
	USDC_MINT,
	"Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11MCCe8BenwNYB",
	"USD1ttGY1N17NEEHLmELoaybftRBUSErhqYiQzvEmuB",
	"2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo"
]);
var STABLE_SYMBOLS = /* @__PURE__ */ new Set([
	"USDC",
	"USDT",
	"USD1",
	"PYUSD",
	"USDS",
	"DAI"
]);
var SOL_SYMBOLS = /* @__PURE__ */ new Set(["SOL", "WSOL"]);
var DEFAULT_RAILS = {
	sizePct: 6,
	dailyLossPct: 10,
	slippageBps: 80,
	minLiqUsd: 8e4,
	minAgeHours: 24,
	maxImpactPct: 1.5,
	maxHourlyTrades: 6
};
function clampRails(input) {
	const n = (v, lo, hi, fallback) => {
		const x = Number(v);
		if (!Number.isFinite(x)) return fallback;
		return Math.min(hi, Math.max(lo, x));
	};
	return {
		sizePct: n(input.sizePct, 2, 20, DEFAULT_RAILS.sizePct),
		dailyLossPct: n(input.dailyLossPct, 5, 20, DEFAULT_RAILS.dailyLossPct),
		slippageBps: n(input.slippageBps, 30, 200, DEFAULT_RAILS.slippageBps),
		minLiqUsd: n(input.minLiqUsd, 25e3, 2e6, DEFAULT_RAILS.minLiqUsd),
		minAgeHours: n(input.minAgeHours, 1, 168, DEFAULT_RAILS.minAgeHours),
		maxImpactPct: n(input.maxImpactPct, .3, 4, DEFAULT_RAILS.maxImpactPct),
		maxHourlyTrades: n(input.maxHourlyTrades, 1, 12, DEFAULT_RAILS.maxHourlyTrades)
	};
}
//#endregion
export { SOL_SYMBOLS as a, USDC_MINT as c, SOL_MINT as i, clampRails as l, DEFAULT_RAILS as n, STABLE_MINTS as o, FEE_BUFFER_SOL as r, STABLE_SYMBOLS as s, CYCLE_MS as t };
