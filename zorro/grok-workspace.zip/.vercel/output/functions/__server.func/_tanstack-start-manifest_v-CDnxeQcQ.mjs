//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CDnxeQcQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CGThp4TH.js", "/assets/rolldown-runtime-B0Z9INg1.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CGThp4TH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DQpii6Li.js"]
	}
} });
//#endregion
export { tsrStartManifest };
